const CACHE = 'm11-anderson-v1.0.0-inicio-limpio';
const FILES = [
  './','./index.html','./styles.css','./m11-premium.css','./liga.css','./lab-hub.css','./ai-admin.css','./app.js','./m11-premium.js',
  './js/theme.js','./js/auth-local.js','./js/sonidos.js','./js/notifications.js?v=s33','./js/android.js','./js/m11-engine.js',
  './js/calendar.js?v=s24','./js/sports-api.js?v=220','./js/league-service.js?v=220','./js/state.js?v=s37','./js/operaciones.js','./js/audit.js',
  './js/libro.js?v=s34','./js/real-sync.js?v=s37','./js/libro-ui.js?v=s24','./js/evaluacion.js','./js/evaluacion-ui.js','./js/scenario.js?v=s24','./js/scenario-ui.js?v=s24','./js/countdown.js?v=s24',
  './js/liga-ui.js?v=s34','./js/operaciones-ui.js','./js/casas-ui.js','./js/vendor/jspdf.umd.min.js',
  './js/pdf-share.js','./js/ui.js?v=s37','./js/onboarding.js','./js/events.js?v=s37','./js/lab-hub.js?v=s29','./js/ai-admin.js?v=228','./js/ai-actions.js?v=228','./manifest.webmanifest',
  './data/bookmakers.json','./data/bookmakers-datos.js','./assets/icon-192.svg','./assets/icon-512.svg','./assets/apple-touch-icon.png'
];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))));
self.addEventListener('fetch', event => event.respondWith(caches.match(event.request).then(response => response || fetch(event.request))));
