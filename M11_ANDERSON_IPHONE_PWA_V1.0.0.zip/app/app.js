/* =========================================================
   Asistente Oficial M11 — punto de entrada
   -----------------------------------------------------------
   Antes de este archivo se cargan (ver index.html), en orden:
   js/theme.js, js/sonidos.js, js/android.js, js/m11-engine.js,
   js/calendar.js, js/sports-api.js, js/league-service.js,
   js/state.js, js/operaciones.js, js/audit.js, js/libro.js,
   js/libro-ui.js, js/evaluacion.js, js/evaluacion-ui.js,
   js/countdown.js, js/liga-ui.js, js/ui.js, js/onboarding.js,
   js/events.js. Todos comparten el namespace window.M11.
   (js/exportar.js y js/lamina.js quedaron retirados de producción —
   ver skills/ y experimental/laminas/ en la raíz del proyecto.)
   ========================================================= */
// V2.2.2: el acceso se activa antes de tocar datos operativos. Aunque una
// migración o un campeonato tengan un registro defectuoso, el login nunca
// vuelve a quedar convertido en una pantalla inmóvil.
if (window.M11.Events && window.M11.Events.initAuth) window.M11.Events.initAuth();

function iniciarModuloSeguro(nombre, iniciar) {
  try { return iniciar(); }
  catch (error) {
    console.error(`[M11] ${nombre} no pudo iniciar`, error);
    try {
      localStorage.setItem('m11_ultimo_error_arranque_v222', JSON.stringify({
        modulo: nombre, mensaje: String(error && error.message || error), fecha: new Date().toISOString()
      }));
    } catch (_) {}
    return null;
  }
}

if (window.M11.Theme) iniciarModuloSeguro('tema', () => window.M11.Theme.init());
if (window.M11.Android) iniciarModuloSeguro('android', () => window.M11.Android.init());
if (window.M11.Notifications) iniciarModuloSeguro('notificaciones', () => window.M11.Notifications.init());
if (window.M11.OnboardingUI) iniciarModuloSeguro('configuracion', () => window.M11.OnboardingUI.aplicarConfiguracionGuardada());
if (window.M11.Operaciones) iniciarModuloSeguro('operaciones', () => window.M11.Operaciones.inicializar());
// Laboratorio V2.0.2 inicia su Historia limpia. V2.0.1 heredaba registros
// de demostración del proyecto anterior (por ejemplo Coppa Italia Women).
// La limpieza ocurre una sola vez y nunca afecta la historia ficticia.
if (!localStorage.getItem('m11_lab_history_clean_v202')) {
  Object.keys(localStorage).filter(k=>/^m11Libro/.test(k)).forEach(k=>localStorage.removeItem(k));
  localStorage.setItem('m11_lab_history_clean_v202','done');
}
// V2.1.8: reparar capital y paridad ANTES de que Events/UI lean y pinten
// niveles. La reparación actualiza también la caché viva de state.js.
if (!localStorage.getItem('m11_reparacion_v218_ejecutada') &&
    window.M11.Libro && window.M11.Libro.repararTodasOperaciones) {
  iniciarModuloSeguro('reparacion_v218', () => {
    const reparacion = window.M11.Libro.repararTodasOperaciones();
    localStorage.setItem('m11_reparacion_v218_ejecutada', JSON.stringify({
      fecha: new Date().toISOString(), reparadas: reparacion.reparadas, omitidas: reparacion.omitidas
    }));
  });
}
// Se pone al día con bloques de 20 ya completos en los datos existentes
// (por ejemplo, tras migrar un historial con muchos partidos previos).
if (window.M11.Evaluacion) iniciarModuloSeguro('evaluacion', () => window.M11.Evaluacion.verificarYRegistrar());
iniciarModuloSeguro('interfaz', () => window.M11.Events.init());
if (window.M11.RealSync) iniciarModuloSeguro('sincronizacion_real', () => window.M11.RealSync.init());
if (window.M11.ScenarioUI) iniciarModuloSeguro('escenarios', () => window.M11.ScenarioUI.init());
if (window.M11.LabHub) iniciarModuloSeguro('laboratorio', () => window.M11.LabHub.init());
if (window.M11.AIAdmin) iniciarModuloSeguro('herramientas_locales', () => window.M11.AIAdmin.initLocalTools());
if (window.M11.AIActions) iniciarModuloSeguro('acciones_ia', () => window.M11.AIActions.init());

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  });
}
