// lamina.js — Generador de la Lámina Oficial M11, versión de navegador.
// Mismo diseño, misma lógica de colisiones y de zonas que el generador
// verificado en Node (generar.js); solo cambia CÓMO se dibuja (Canvas
// nativo del navegador) y CÓMO se cargan imágenes y fuentes (rutas
// relativas dentro de la propia app, sin depender de ningún entorno
// externo). Los datos vienen siempre de M11.Libro / M11.Store /
// M11.Evaluacion — nunca de un ejemplo.

(function () {
  const ASSETS_BASE = 'assets/lamina/';
  let fontsReady = null;
  function asegurarFuentes() {
    if (fontsReady) return fontsReady;
    const rutas = [
      ['Space Grotesk', '500', ASSETS_BASE + 'fonts/SpaceGrotesk-500.woff2'],
      ['Space Grotesk', '700 800', ASSETS_BASE + 'fonts/SpaceGrotesk-700.woff2'],
      ['IBM Plex Sans', '400', ASSETS_BASE + 'fonts/IBMPlexSans-400.woff2'],
      ['IBM Plex Sans', '500', ASSETS_BASE + 'fonts/IBMPlexSans-500.woff2'],
      ['IBM Plex Sans', '600', ASSETS_BASE + 'fonts/IBMPlexSans-600.woff2'],
      ['IBM Plex Sans', '700', ASSETS_BASE + 'fonts/IBMPlexSans-700.woff2']
    ];
    const cargas = rutas.map(([fam, weight, url]) => {
      const ff = new FontFace(fam, `url(${url})`, { weight });
      document.fonts.add(ff);
      return ff.load();
    });
    fontsReady = Promise.all(cargas);
    return fontsReady;
  }
  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('No se pudo cargar ' + src));
      img.src = src;
    });
  }
  function createCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

const T = {
  navy950: '#050B14', navy900: '#081426', navy800: '#0E2340',
  blue: '#2D8CFF', cyan: '#3AD8FF', green: '#43E58A', gold: '#F4C14E',
  amber: '#FF9D2E', red: '#FF5A63', purple: '#A96BFF',
  white: '#F7FAFF', silver: '#B9C5D6', muted: '#72839A'
};
const L = ASSETS_BASE;
const W = 1080, H = 1350;

// ============================================================
// ZONAS — contenedores reales con límites propios (punto 6 y 11)
// ============================================================
const ZONES = {
  header:      { y0: 0,    y1: 220,  pad: 20 },
  profit:      { y0: 220,  y1: 420,  pad: 16 },
  strategies:  { y0: 420,  y1: 790,  pad: 12 },
  indicators:  { y0: 790,  y1: 930,  pad: 12 },
  evaluation:  { y0: 930,  y1: 1165, pad: 14 },
  footer:      { y0: 1165, y1: 1350, pad: 16 }
};
const MARGIN = 48;      // margen exterior mínimo
const GAP_SECTION = 18; // separación mínima entre secciones
const PAD_CARD = 20;    // padding interno mínimo de tarjetas
const GAP_ICON_TEXT = 12;
const GAP_TITLE_CONTENT = 14;
const GAP_LINE = 6;

function fmtCOP(n) {
  const neg = n < 0; n = Math.round(Math.abs(n));
  const s = n.toString().split('').reverse().join('').match(/.{1,3}/g).join('.').split('').reverse().join('');
  return (neg ? '-$' : '$') + s;
}

// ============================================================
// SISTEMA DE CAJAS Y VALIDACIÓN (puntos 4 y 5) — reconstruido:
// ya no hay exención en bloque para "decorativo". Cada caja declara
// su tipo real:
//   'text'  -> lleva zona de protección de 8px horizontal / 6px vertical
//   'line'  -> línea o borde decorativo (divisores, líneas del marco)
//   'icon'  -> ícono o escudo funcional
//   'image' -> imagen que no es fondo (p. ej. un ícono suelto)
//   'bg'    -> relleno de fondo de un panel/tarjeta/franja — solo se
//              exime cuando NO está marcada como "hazard" (peligrosa,
//              p. ej. el fondo del estadio trae líneas y un rótulo
//              propio que si pueden interferir con la lectura)
//   'shield'-> placa oscura que el propio código coloca a propósito
//              para tapar una zona peligrosa del fondo; si cubre por
//              completo la intersección, cancela esa colisión puntual
// Un elemento con el mismo `container` que otro nunca colisiona con
// él (es su propio grupo: el marco de una tarjeta con su propio texto).
// ============================================================
let BOXES, COLLISIONS, SHIELDS;
function resetLayout() { BOXES = []; COLLISIONS = []; SHIELDS = []; }

function expandForText(box) {
  return { x: box.x - 8, y: box.y - 6, x2: box.x2 + 8, y2: box.y2 + 6 };
}
function rectsOverlap(a, b) {
  return a.x < b.x2 - 0.01 && a.x2 > b.x + 0.01 && a.y < b.y2 - 0.01 && a.y2 > b.y + 0.01;
}
function intersection(a, b) {
  const x = Math.max(a.x, b.x), y = Math.max(a.y, b.y), x2 = Math.min(a.x2, b.x2), y2 = Math.min(a.y2, b.y2);
  if (x2 <= x || y2 <= y) return null;
  return { x, y, x2, y2 };
}
function shieldCovers(rect) {
  return SHIELDS.some(s => s.x <= rect.x + 0.5 && s.y <= rect.y + 0.5 && s.x2 >= rect.x2 - 0.5 && s.y2 >= rect.y2 - 0.5);
}

function registerBox(id, x, y, w, h, opts = {}) {
  const kind = opts.kind || (opts.decorative ? 'bg' : 'generic');
  const container = opts.container || null;
  const hazard = !!opts.hazard;
  const box = { id, x, y, w, h, x2: x + w, y2: y + h, kind, container, hazard, zoneCheck: opts.zoneCheck };

  if (kind === 'shield') { SHIELDS.push(box); BOXES.push(box); return box; }

  for (const other of BOXES) {
    if (other.kind === 'shield') continue;
    const sameContainer = container && other.container && container === other.container;
    const bgExento = (kind === 'bg' && !hazard) || (other.kind === 'bg' && !other.hazard);
    if (sameContainer || bgExento) continue;

    const a = kind === 'text' ? expandForText(box) : box;
    const b = other.kind === 'text' ? expandForText(other) : other;
    if (!rectsOverlap(a, b)) continue;

    // Una línea peligrosa del fondo (arco del estadio, campo, rótulo) solo
    // puede "competir visualmente" con texto — una imagen u ícono opaco
    // pintado encima ya la tapa por completo, así que eso no es colisión.
    const hazardVsOpaco = (kind === 'line' && box.hazard && other.kind !== 'text') ||
                           (other.kind === 'line' && other.hazard && kind !== 'text');
    if (hazardVsOpaco) continue;

    // Si el cruce está totalmente cubierto por una placa opaca puesta a
    // propósito (p.ej. detrás del texto, tapando una línea del estadio),
    // no cuenta como colisión: visualmente ya no compite con nada.
    const inter = intersection(a, b);
    if (inter && shieldCovers(inter)) continue;

    COLLISIONS.push(`COLISIÓN: "${id}" (${kind}) invade la zona de "${other.id}" (${other.kind})`);
  }
  BOXES.push(box);
  return box;
}
function validatePosterLayout() {
  BOXES.forEach(b => {
    if (b.kind === 'shield') return;
    if (b.x < -0.5 || b.y < -0.5 || b.x2 > W + 0.5 || b.y2 > H + 0.5) {
      COLLISIONS.push(`DESBORDE: "${b.id}" se sale del lienzo (x:${b.x.toFixed(0)} y:${b.y.toFixed(0)} w:${b.w.toFixed(0)} h:${b.h.toFixed(0)})`);
    }
  });
  return COLLISIONS.length === 0;
}

// ============================================================
// MEDICIÓN Y DIBUJO DE TEXTO (con caja real vía actualBoundingBox)
// ============================================================
function makeTextTools(ctx) {
  function metrics(str, font) {
    ctx.font = font;
    const m = ctx.measureText(str);
    return { width: m.width, ascent: m.actualBoundingBoxAscent, descent: m.actualBoundingBoxDescent };
  }
  // Reduce el tamaño dentro de [minPx,maxPx] hasta que el ancho quepa en maxWidth.
  function fitSize(str, family, weight, minPx, maxPx, maxWidth) {
    for (let px = maxPx; px >= minPx; px -= 1) {
      const w = metrics(str, `${weight} ${px}px "${family}"`).width;
      if (w <= maxWidth) return px;
    }
    return minPx;
  }
  function draw(id, str, x, y, font, color, align, opts = {}) {
    const m = metrics(str, font);
    let boxX = x;
    if (align === 'center') boxX = x - m.width / 2;
    if (align === 'right') boxX = x - m.width;
    const box = registerBox(id, boxX, y - m.ascent, m.width, m.ascent + m.descent, { kind: 'text', ...opts });
    if (opts.draw !== false) {
      ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align || 'left'; ctx.textBaseline = 'alphabetic';
      if (opts.shadow) { ctx.shadowColor = opts.shadow; ctx.shadowBlur = opts.shadowBlur || 18; }
      ctx.fillText(str, x, y);
      ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0;
    }
    return box;
  }
  return { metrics, fitSize, draw };
}

// Los datos NO se definen acá: siempre vienen de M11.Libro / M11.Store /
// M11.Evaluacion en el momento de generar (ver M11.Lamina.generarDesdeLibro
// al final de este archivo). No hay dataset de ejemplo en la app real.

function estadoColor(estado) {
  const e = estado.toLowerCase();
  if (e.includes('crítico') || e.includes('critico') || e.includes('cerrada') || e.includes('agotad') || e.includes('insuficiente')) return T.red;
  return T.green;
}

// ============================================================
// GENERACIÓN COMPLETA (medir+registrar; dibuja solo si draw=true)
// ============================================================
async function construir(data, ctx, draw, assets) {
  resetLayout();
  const { bg, marco, brand, ic } = assets;
  const cx = W / 2;
  const tt = makeTextTools(ctx);
  function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function imgBox(id, img, x, y, w, h, opts = {}) { const b = registerBox(id, x, y, w, h, opts); if (draw) ctx.drawImage(img, x, y, w, h); return b; }

  if (draw) {
    ctx.drawImage(bg, 0, 0, W, H);
    let atm = ctx.createLinearGradient(0, 0, 0, H);
    atm.addColorStop(0, 'rgba(5,11,20,.30)'); atm.addColorStop(0.55, 'rgba(5,11,20,.18)'); atm.addColorStop(1, 'rgba(5,11,20,.42)');
    ctx.fillStyle = atm; ctx.fillRect(0, 0, W, H);
  }
  // El fondo trae, dibujado dentro de la propia imagen, un arco y haces de
  // luz que ocupan la franja superior del lienzo. Se registra como zona
  // peligrosa real (punto 5): cualquier texto que caiga ahí necesita su
  // propia placa para no quedar atravesado por esas líneas.
  registerBox('fondo-arco-superior', 0, 0, W, 380, { kind: 'line', hazard: true });

  function placaDetrasDeTexto(id, cxTxt, yTop, wTxt, hTxt, pad) {
    const x = cxTxt - wTxt / 2 - pad, y = yTop - pad, w = wTxt + pad * 2, h = hTxt + pad * 2;
    registerBox(id, x, y, w, h, { kind: 'shield' });
    if (draw) {
      rr(x, y, w, h, 14);
      let g = ctx.createRadialGradient(cxTxt, yTop + hTxt / 2, 4, cxTxt, yTop + hTxt / 2, w / 1.6);
      g.addColorStop(0, 'rgba(5,11,20,.72)'); g.addColorStop(1, 'rgba(5,11,20,0)');
      ctx.fillStyle = g; ctx.fill();
    }
  }

  // ============= ZONA HEADER (0–220) =============
  const hz = ZONES.header;
  {
    const mF = tt.metrics(data.fechaCorte, '600 18px "IBM Plex Sans"');
    placaDetrasDeTexto('placa-esquina-fecha', MARGIN + mF.width / 2, hz.y0 + 34 - mF.ascent, mF.width, mF.ascent + mF.descent, 12);
    const mB = tt.metrics(data.bloqueEstado, '600 18px "IBM Plex Sans"');
    placaDetrasDeTexto('placa-esquina-bloque', W - MARGIN - mB.width / 2, hz.y0 + 34 - mB.ascent, mB.width, mB.ascent + mB.descent, 12);
  }
  tt.draw('esquina-fecha', data.fechaCorte, MARGIN, hz.y0 + 34, '600 18px "IBM Plex Sans"', T.silver, 'left', { draw, zoneCheck: 'header' });
  tt.draw('esquina-bloque', data.bloqueEstado, W - MARGIN, hz.y0 + 34, '600 18px "IBM Plex Sans"', T.silver, 'right', { draw, zoneCheck: 'header' });

  const crestH = 78, crestW = brand.m11.width * (crestH / brand.m11.height);
  imgBox('escudo-m11', brand.m11, cx - crestW / 2, hz.y0 + 6, crestW, crestH, { draw, zoneCheck: 'header' });
  if (draw) { ctx.save(); ctx.shadowColor = 'rgba(244,193,78,.55)'; ctx.shadowBlur = 26; ctx.drawImage(brand.m11, cx - crestW / 2, hz.y0 + 6, crestW, crestH); ctx.restore(); }

  const torneoTxt = data.torneo.toUpperCase();
  ctx.font = '800 58px "Space Grotesk"';
  const cabeEnUnaLinea = ctx.measureText(torneoTxt).width <= W - MARGIN * 2 - 40;
  let titleGrad = ctx.createLinearGradient(cx - 340, 0, cx + 340, 0);
  titleGrad.addColorStop(0, T.gold); titleGrad.addColorStop(0.5, '#fff8e6'); titleGrad.addColorStop(1, T.gold);
  let subY;
  if (cabeEnUnaLinea) {
    const tituloY = hz.y0 + 2 + crestH + GAP_TITLE_CONTENT + 50;
    const tituloPx = tt.fitSize(torneoTxt, 'Space Grotesk', 800, 58, 68, W - MARGIN * 2 - 40);
    {
      const mT = tt.metrics(torneoTxt, `800 ${tituloPx}px "Space Grotesk"`);
      placaDetrasDeTexto('placa-titulo', cx, tituloY - mT.ascent, mT.width, mT.ascent + mT.descent, 16);
    }
    tt.draw('titulo-torneo', torneoTxt, cx, tituloY, `800 ${tituloPx}px "Space Grotesk"`, titleGrad, 'center', { draw, zoneCheck: 'header', shadow: draw ? 'rgba(244,193,78,.4)' : null, shadowBlur: 16 });
    subY = tituloY + GAP_LINE + 14;
  } else {
    // No cabe ni al tamaño mínimo en una línea: se parte en dos por
    // palabras (nunca se reduce por debajo del mínimo del rango).
    const palabrasT = torneoTxt.split(' ');
    let mejorCorte = Math.ceil(palabrasT.length / 2), mejorDif = Infinity;
    for (let corte = 1; corte < palabrasT.length; corte++) {
      const l1 = palabrasT.slice(0, corte).join(' '), l2 = palabrasT.slice(corte).join(' ');
      const w1 = ctx.measureText(l1).width, w2 = ctx.measureText(l2).width;
      const dif = Math.abs(w1 - w2) + Math.max(0, w1 - (W - MARGIN * 2 - 40)) * 5 + Math.max(0, w2 - (W - MARGIN * 2 - 40)) * 5;
      if (dif < mejorDif) { mejorDif = dif; mejorCorte = corte; }
    }
    const l1 = palabrasT.slice(0, mejorCorte).join(' '), l2 = palabrasT.slice(mejorCorte).join(' ');
    const maxWT = W - MARGIN * 2 - 40;
    const px1 = tt.fitSize(l1, 'Space Grotesk', 800, 58, 58, maxWT);
    const px2 = tt.fitSize(l2, 'Space Grotesk', 800, 58, 58, maxWT);
    const pxT = Math.min(px1, px2);
    let m1 = tt.metrics(l1, `800 ${pxT}px "Space Grotesk"`);
    const y1 = hz.y0 + 2 + crestH + GAP_TITLE_CONTENT + m1.ascent;
    let m2 = tt.metrics(l2, `800 ${pxT}px "Space Grotesk"`);
    const y2 = y1 + m1.descent + 12 + m2.ascent;
    placaDetrasDeTexto('placa-titulo-l1', cx, y1 - m1.ascent, m1.width, m1.ascent + m1.descent, 16);
    placaDetrasDeTexto('placa-titulo-l2', cx, y2 - m2.ascent, m2.width, m2.ascent + m2.descent, 16);
    tt.draw('titulo-torneo-l1', l1, cx, y1, `800 ${pxT}px "Space Grotesk"`, titleGrad, 'center', { draw, zoneCheck: 'header', shadow: draw ? 'rgba(244,193,78,.4)' : null, shadowBlur: 16 });
    tt.draw('titulo-torneo-l2', l2, cx, y2, `800 ${pxT}px "Space Grotesk"`, titleGrad, 'center', { draw, zoneCheck: 'header', shadow: draw ? 'rgba(244,193,78,.4)' : null, shadowBlur: 16 });
    subY = y2 + m2.descent + 14;
  }
  {
    const mSub = tt.metrics('REGISTRO CRONOLÓGICO, FINANCIERO Y AUDITABLE', '500 18px "IBM Plex Sans"');
    placaDetrasDeTexto('placa-subtitulo', cx, subY - mSub.ascent, mSub.width, mSub.ascent + mSub.descent, 18);
  }
  tt.draw('subtitulo', 'REGISTRO CRONOLÓGICO, FINANCIERO Y AUDITABLE', cx, subY, '500 18px "IBM Plex Sans"', T.silver, 'center', { draw, zoneCheck: 'header' });

  // ============= ZONA PROFIT (220–420) =============
  const pz = ZONES.profit;
  const labelY = subY + 18;
  {
    const mLbl = tt.metrics('GANANCIA ACUMULADA', '700 20px "IBM Plex Sans"');
    placaDetrasDeTexto('placa-ganancia-label', cx, labelY - mLbl.ascent, mLbl.width, mLbl.ascent + mLbl.descent, 18);
  }
  tt.draw('ganancia-label', 'GANANCIA ACUMULADA', cx, labelY, '700 20px "IBM Plex Sans"', T.white, 'center', { draw, zoneCheck: 'profit' });

  const gananciaTxt = (data.gananciaAcumulada >= 0 ? '+' : '') + fmtCOP(data.gananciaAcumulada);
  const gIconSz = 70, gGap = 16;
  const gNumY = labelY + 18 + 82;
  const gPx = tt.fitSize(gananciaTxt, 'Space Grotesk', 800, 100, 100, W - MARGIN * 2 - gIconSz - gGap - 40);
  const gW = tt.metrics(gananciaTxt, `800 ${gPx}px "Space Grotesk"`).width;
  const gGroupW = gIconSz + gGap + gW;
  const gLeft = cx - gGroupW / 2;
  imgBox('icono-ganancia', ic.ganancia, gLeft, gNumY - gIconSz * 0.72, gIconSz, gIconSz, { draw, zoneCheck: 'profit' });
  {
    const mC = tt.metrics(gananciaTxt, `800 ${gPx}px "Space Grotesk"`);
    placaDetrasDeTexto('placa-cifra-ganancia', gLeft + gIconSz + gGap + mC.width / 2, gNumY - mC.ascent, mC.width, mC.ascent + mC.descent, 16);
  }
  tt.draw('cifra-ganancia', gananciaTxt, gLeft + gIconSz + gGap, gNumY, `800 ${gPx}px "Space Grotesk"`, data.gananciaAcumulada >= 0 ? T.green : T.red, 'left', { draw, zoneCheck: 'profit', shadow: draw ? 'rgba(67,229,138,.55)' : null, shadowBlur: 30 });

  const subGY = gNumY + 20;
  {
    const mCap = tt.metrics(`Sobre un capital inicial de ${fmtCOP(data.capitalInicial)}`, '500 19px "IBM Plex Sans"');
    placaDetrasDeTexto('placa-ganancia-sub', cx, subGY - mCap.ascent, mCap.width, mCap.ascent + mCap.descent, 16);
  }
  tt.draw('ganancia-sub', `Sobre un capital inicial de ${fmtCOP(data.capitalInicial)}`, cx, subGY, '500 19px "IBM Plex Sans"', T.white, 'center', { draw, zoneCheck: 'profit' });

  // ============= ZONA STRATEGIES (420–790) — proporciones exactas del punto 7 =============
  const sz = ZONES.strategies;
  const strats = [data.estrategias.general, data.estrategias.pares, data.estrategias.impares];
  const brandImgs = [brand.general, brand.pares, brand.impares];
  const stW = 296, stGap = 18;
  const rowW = stW * 3 + stGap * 2, rowX = cx - rowW / 2;

  // Medición pura (sin dibujar) de cuánto alto pide cada tarjeta, para fijar
  // un cardH único ANTES de pintar nada — así el marco nunca queda más
  // chico que su propio contenido.
  function medirAlturaPilar(s, innerW, shH) {
    let h = PAD_CARD + shH + GAP_TITLE_CONTENT;
    const nombrePx = tt.fitSize(s.nombre, 'IBM Plex Sans', 700, 28, 34, innerW);
    let mm = tt.metrics(s.nombre, `700 ${nombrePx}px "IBM Plex Sans"`);
    h += mm.ascent + mm.descent + GAP_TITLE_CONTENT;
    const nivelTxt = 'Nivel ' + s.nivel;
    const nivelPx = tt.fitSize(nivelTxt, 'Space Grotesk', 800, 64, 78, innerW);
    mm = tt.metrics(nivelTxt, `800 ${nivelPx}px "Space Grotesk"`);
    h += mm.ascent + mm.descent + GAP_TITLE_CONTENT;
    h += 16 + GAP_TITLE_CONTENT; // barra
    const capitalTxt = fmtCOP(s.capital);
    const capitalPx = tt.fitSize(capitalTxt, 'Space Grotesk', 700, 26, 32, innerW);
    mm = tt.metrics(capitalTxt, `700 ${capitalPx}px "Space Grotesk"`);
    h += mm.ascent + mm.descent + GAP_TITLE_CONTENT;
    const estadoTxt = s.estado.toUpperCase();
    ctx.font = '700 22px "IBM Plex Sans"';
    const oneLine = ctx.measureText(estadoTxt).width <= innerW - 22 - GAP_ICON_TEXT;
    if (oneLine) { mm = tt.metrics(estadoTxt, '700 18px "IBM Plex Sans"'); h += Math.max(mm.ascent + mm.descent, 22); }
    else { mm = tt.metrics(estadoTxt.split(' ').slice(0, Math.ceil(estadoTxt.split(' ').length / 2)).join(' '), '700 18px "IBM Plex Sans"'); const row1H = Math.max(22, mm.ascent + mm.descent); h += row1H + 12 + (mm.ascent + mm.descent); }
    return h + PAD_CARD;
  }
  const innerWmedida = stW - PAD_CARD * 2;
  const alturasPedidas = strats.map(s => medirAlturaPilar(s, innerWmedida, (sz.y1 - sz.y0 - 20) * 0.28));
  const cardTop = subGY + GAP_SECTION + 14;
  const cardH = Math.max(...alturasPedidas); // puramente por contenido real, sin piso de zona fija
  const pEscudo = 0.28;

  strats.forEach((s, i) => {
    const sx = rowX + i * (stW + stGap), scx = sx + stW / 2;
    const innerW = stW - PAD_CARD * 2;

    imgBox(`marco-${s.nombre}`, marco[s.frame], sx, cardTop, stW, cardH, { draw, zoneCheck: 'strategies', decorative: true });
    if (draw) {
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 10;
      ctx.drawImage(marco[s.frame], sx, cardTop, stW, cardH); ctx.restore();
    }

    const color = { azul: T.blue, verde: T.green, dorado: T.gold }[s.frame];
    let cy = cardTop + PAD_CARD; // cursor = borde SUPERIOR del próximo elemento

    // -- Escudo (≈28% de la tarjeta) --
    const shH = (cardH - PAD_CARD * 2) * pEscudo, realW = brandImgs[i].width * (shH / brandImgs[i].height);
    if (draw) {
      let g = ctx.createRadialGradient(scx, cy + shH * 0.5, 8, scx, cy + shH * 0.5, shH * 0.68);
      g.addColorStop(0, color + '30'); g.addColorStop(1, color + '00');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(scx, cy + shH * 0.5, shH * 0.68, 0, Math.PI * 2); ctx.fill();
      ctx.save(); ctx.shadowColor = color; ctx.shadowBlur = 30; ctx.drawImage(brandImgs[i], scx - realW / 2, cy, realW, shH); ctx.restore();
    }
    imgBox(`escudo-${s.nombre}`, brandImgs[i], scx - realW / 2, cy, realW, shH, { zoneCheck: 'strategies' });
    cy += shH + GAP_TITLE_CONTENT;

    // -- Nombre --
    const nombrePx = tt.fitSize(s.nombre, 'IBM Plex Sans', 700, 28, 34, innerW);
    let m = tt.metrics(s.nombre, `700 ${nombrePx}px "IBM Plex Sans"`);
    let baseline = cy + m.ascent;
    tt.draw(`nombre-${s.nombre}`, s.nombre, scx, baseline, `700 ${nombrePx}px "IBM Plex Sans"`, '#fff', 'center', { draw, zoneCheck: 'strategies', spacing: 1.2 });
    cy = baseline + m.descent + GAP_TITLE_CONTENT;

    // -- Nivel (protagonista visual del centro de la tarjeta) --
    const nivelTxt = 'Nivel ' + s.nivel;
    const nivelPx = tt.fitSize(nivelTxt, 'Space Grotesk', 800, 64, 78, innerW);
    m = tt.metrics(nivelTxt, `800 ${nivelPx}px "Space Grotesk"`);
    baseline = cy + m.ascent;
    tt.draw(`nivel-${s.nombre}`, nivelTxt, scx, baseline, `800 ${nivelPx}px "Space Grotesk"`, '#fff', 'center', { draw, zoneCheck: 'strategies', shadow: draw ? color : null, shadowBlur: 18 });
    cy = baseline + m.descent + GAP_TITLE_CONTENT;

    // -- Barra de 11 segmentos, pegada al nivel --
    const barH = 16, barW = Math.max(220, innerW - 20), segGap = 4, segN = 11;
    const segW = (barW - segGap * (segN - 1)) / segN;
    const barsX = scx - barW / 2, barsY = cy;
    for (let b = 0; b < segN; b++) {
      ctx.fillStyle = draw ? (b < s.bars ? color : 'rgba(255,255,255,.16)') : '#000';
      if (draw) { rr(barsX + b * (segW + segGap), barsY, segW, barH, 3); ctx.fill(); }
    }
    registerBox(`barra-${s.nombre}`, barsX, barsY, barW, barH, { zoneCheck: 'strategies' });
    cy += barH + GAP_TITLE_CONTENT;

    // -- Capital --
    const capitalTxt = fmtCOP(s.capital);
    const capitalPx = tt.fitSize(capitalTxt, 'Space Grotesk', 700, 26, 32, innerW);
    m = tt.metrics(capitalTxt, `700 ${capitalPx}px "Space Grotesk"`);
    baseline = cy + m.ascent;
    tt.draw(`capital-${s.nombre}`, capitalTxt, scx, baseline, `700 ${capitalPx}px "Space Grotesk"`, '#fff', 'center', { draw, zoneCheck: 'strategies' });
    cy = baseline + m.descent + GAP_TITLE_CONTENT;

    // -- Estado: ícono + texto, en una o dos líneas según el ancho real --
    const estadoTxt = s.estado.toUpperCase();
    const estadoColorFinal = estadoColor(s.estado);
    const estW = 18;
    const estadoPx = 18;
    ctx.font = `700 ${estadoPx}px "IBM Plex Sans"`;
    const oneLine = ctx.measureText(estadoTxt).width <= innerW - estW - GAP_ICON_TEXT;
    if (oneLine) {
      m = tt.metrics(estadoTxt, `700 ${estadoPx}px "IBM Plex Sans"`);
      const grupoW = estW + GAP_ICON_TEXT + m.width;
      const gx = scx - grupoW / 2;
      baseline = cy + Math.max(m.ascent, estW * 0.8);
      imgBox(`estado-icono-${s.nombre}`, ic.activo, gx, baseline - estW * 0.78, estW, estW, { draw, zoneCheck: 'strategies' });
      tt.draw(`estado-${s.nombre}`, estadoTxt, gx + estW + GAP_ICON_TEXT, baseline, `700 ${estadoPx}px "IBM Plex Sans"`, estadoColorFinal, 'left', { draw, zoneCheck: 'strategies', spacing: 0.6 });
      cy = baseline + m.descent;
    } else {
      const palabras = estadoTxt.split(' ');
      const mitad = Math.ceil(palabras.length / 2);
      const l1 = palabras.slice(0, mitad).join(' '), l2 = palabras.slice(mitad).join(' ');
      let m1 = tt.metrics(l1, `700 ${estadoPx}px "IBM Plex Sans"`);
      const row1H = Math.max(estW, m1.ascent + m1.descent);
      const grupo1W = estW + GAP_ICON_TEXT + m1.width, grupo1Left = scx - grupo1W / 2;
      baseline = cy + row1H / 2 + m1.ascent / 2 - m1.descent / 2;
      imgBox(`estado-icono-${s.nombre}`, ic.activo, grupo1Left, cy + row1H / 2 - estW / 2, estW, estW, { draw, zoneCheck: 'strategies' });
      tt.draw(`estado-${s.nombre}-l1`, l1, grupo1Left + estW + GAP_ICON_TEXT, baseline, `700 ${estadoPx}px "IBM Plex Sans"`, estadoColorFinal, 'left', { draw, zoneCheck: 'strategies', spacing: 0.6 });
      cy += row1H + 12;
      let m2 = tt.metrics(l2, `700 ${estadoPx}px "IBM Plex Sans"`);
      baseline = cy + m2.ascent;
      tt.draw(`estado-${s.nombre}-l2`, l2, scx, baseline, `700 ${estadoPx}px "IBM Plex Sans"`, estadoColorFinal, 'center', { draw, zoneCheck: 'strategies', spacing: 0.6 });
      cy = baseline + m2.descent;
    }

  });
  const strategiesBottom = cardTop + cardH;

  // ============= ZONA INDICATORS (790–930) =============
  const iz = ZONES.indicators;
  const bandTop = strategiesBottom + GAP_SECTION;
  const bandIconSz = 66;
  const bandPadV = 12; // relleno vertical arriba/abajo, dentro de la franja
  const valMetricsRef = tt.metrics('$0', '700 52px "Space Grotesk"'); const valAscentMax = valMetricsRef.ascent, valDescentMax = valMetricsRef.descent; // referencia: incluye "$" (sube y baja más que un dígito solo)
  const lblRef = tt.metrics('Ag', '600 20px "IBM Plex Sans"');
  const tickTextStackH = valAscentMax + valDescentMax + 18 + lblRef.ascent + lblRef.descent;
  const bandH = Math.max(bandIconSz, tickTextStackH) + bandPadV * 2;
  registerBox('franja-indicadores', MARGIN, bandTop, W - MARGIN * 2, bandH, { decorative: true });
  if (draw) {
    rr(MARGIN, bandTop, W - MARGIN * 2, bandH, 24);
    let pg = ctx.createLinearGradient(0, bandTop, 0, bandTop + bandH);
    pg.addColorStop(0, 'rgba(8,20,38,.66)'); pg.addColorStop(1, 'rgba(8,20,38,.5)');
    ctx.fillStyle = pg; ctx.fill(); ctx.strokeStyle = 'rgba(244,193,78,.35)'; ctx.lineWidth = 1.3; ctx.stroke();
  }
  const items = [
    { ic: ic.partidos, val: String(data.partidos), lbl: 'PARTIDOS' },
    { ic: ic.empates, val: String(data.empates), lbl: 'EMPATES' },
    { ic: ic.noEmpates, val: String(data.noEmpates), lbl: 'NO EMPATES' },
    { ic: ic.apostado, val: fmtCOP(data.totalApostado), lbl: 'APOSTADO' }
  ];
  const iconSz = 66, gap = 16, segPad = 16;
  const groupWs = items.map(it => {
    let valPx = 52, valW;
    do {
      valW = tt.metrics(it.val, `700 ${valPx}px "Space Grotesk"`).width;
      ctx.font = `600 20px "IBM Plex Sans"`;
      const lblW = ctx.measureText(it.lbl).width + it.lbl.length * 0.6;
      if (iconSz + gap + Math.max(valW, lblW) <= 400) break;
      valPx -= 1;
    } while (valPx >= 42);
    ctx.font = `600 20px "IBM Plex Sans"`;
    const lblW = ctx.measureText(it.lbl).width + it.lbl.length * 0.6;
    return { valPx, w: iconSz + gap + Math.max(valW, lblW) + segPad * 2 };
  });
  const totalNeeded = groupWs.reduce((a, b) => a + b.w, 0);
  const totalDisponible = W - MARGIN * 2;
  const factor = totalNeeded > totalDisponible ? totalDisponible / totalNeeded : 1;
  // Si sobra espacio tras darle a cada quien lo que pide, se reparte el
  // sobrante proporcionalmente para que ninguna columna quede angosta.
  const extra = Math.max(0, totalDisponible - totalNeeded) / items.length;

  let segLeft = MARGIN;
  const tickStackTop = bandTop + bandH / 2 - tickTextStackH / 2;
  const tickValBaseline = tickStackTop + valAscentMax;
  const tickLblBaseline = tickValBaseline + valDescentMax + 18 + lblRef.ascent;

  items.forEach((it, i) => {
    const segW = groupWs[i].w * factor + extra;
    const valPx = groupWs[i].valPx;
    const scx = segLeft + segW / 2;
    const valW = tt.metrics(it.val, `700 ${valPx}px "Space Grotesk"`).width;
    ctx.font = `600 20px "IBM Plex Sans"`;
    const lblW = ctx.measureText(it.lbl).width + it.lbl.length * 0.6;
    const groupW = iconSz + gap + Math.max(valW, lblW);
    const groupLeft = scx - groupW / 2;
    imgBox(`ind-icono-${it.lbl}`, it.ic, groupLeft, bandTop + bandH / 2 - iconSz / 2, iconSz, iconSz, { draw, zoneCheck: null });
    tt.draw(`ind-valor-${it.lbl}`, it.val, groupLeft + iconSz + gap, tickValBaseline, `700 ${valPx}px "Space Grotesk"`, '#fff', 'left', { draw, zoneCheck: null });
    tt.draw(`ind-etq-${it.lbl}`, it.lbl, groupLeft + iconSz + gap, tickLblBaseline, `600 20px "IBM Plex Sans"`, T.silver, 'left', { draw, zoneCheck: null, spacing: 0.6 });
    if (i > 0 && draw) { ctx.strokeStyle = 'rgba(255,255,255,.15)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(segLeft, bandTop + 20); ctx.lineTo(segLeft, bandTop + bandH - 20); ctx.stroke(); }
    segLeft += segW;
  });

  // ============= ZONA EVALUATION (930–1165, con alto calculado por contenido real) =============
  const ez = ZONES.evaluation;
  const evTop = bandTop + bandH + GAP_SECTION;
  const evx = MARGIN + 28;
  const evRight = W - MARGIN - 28;
  const ev = data.evaluacion;

  // -- Paso 1: calcular todas las posiciones (solo medición, nada se pinta ni se registra todavía) --
  const evIconTop = evTop + 12; // 12px mínimos entre ícono y marco (punto 2)
  let ecy = evIconTop + 24;
  const mTit = tt.metrics('EVALUACIÓN DE RECORRIDO M11', '700 23px "IBM Plex Sans"');
  let tituloBaseline = evIconTop + 34 / 2 + mTit.ascent / 2 - 2;
  const subTxt = `Bloque ${ev.bloque} · Partidos ${ev.desde}–${ev.hasta} · ${ev.registrados} registrados`;
  const mSub = tt.metrics(subTxt, '500 18px "IBM Plex Sans"');
  let subBaseline = tituloBaseline + mTit.descent + 12 + mSub.ascent;
  ecy = Math.max(evIconTop + 34, subBaseline + mSub.descent) + 10; // 10px mínimos entre texto y línea (punto 2)
  const lineaY = ecy;
  ecy += 10;

  const leftW = (evRight - evx) * 0.36;
  const scoreCX = evx + leftW / 2;
  const scoreTxt = `${ev.cumplidas} DE ${ev.total}`;
  m = tt.metrics(scoreTxt, '800 68px "Space Grotesk"');
  const scoreBaseline = ecy + m.ascent;
  let scy = scoreBaseline + m.descent + 12;
  m = tt.metrics('CONDICIONES FAVORABLES', '700 20px "IBM Plex Sans"');
  scy += m.ascent; const l1Baseline = scy; scy += m.descent;
  const leftColBottom = scy;

  const rx = evx + leftW + 32;
  const condW = evRight - rx - 4;
  let rcy = ecy;
  const filas = ev.condiciones.map((c, i) => {
    const rowTop = rcy;
    const estIconSz = 26;
    const lPx = tt.fitSize(c.l, 'IBM Plex Sans', 700, 20, 20, condW - estIconSz - GAP_ICON_TEXT);
    const dPx = tt.fitSize(c.d, 'IBM Plex Sans', 400, 17, 17, condW - estIconSz - GAP_ICON_TEXT);
    let mL = tt.metrics(c.l, `700 ${lPx}px "IBM Plex Sans"`);
    let textCy = rowTop + mL.ascent; const lBaseline = textCy; textCy += mL.descent + 12;
    let mD = tt.metrics(c.d, `400 ${dPx}px "IBM Plex Sans"`);
    textCy += mD.ascent; const dBaseline = textCy; textCy += mD.descent;
    const rowH = Math.max(estIconSz, textCy - rowTop);
    const iconY = rowTop + rowH / 2 - estIconSz / 2;
    rcy = rowTop + rowH + (i < ev.condiciones.length - 1 ? 12 : 0);
    return { c, lPx, dPx, lBaseline, dBaseline, iconY, estIconSz };
  });
  const rightColBottom = rcy;

  const lineaY2 = Math.max(leftColBottom, rightColBottom) + 6;

  const notaTxt = 'Corresponde únicamente a este bloque — no garantiza el resultado futuro del torneo.';
  m = tt.metrics(notaTxt, '400 16px "IBM Plex Sans"');
  const notaBaseline = lineaY2 + 10 + m.ascent;
  const ecyFinal = notaBaseline + m.descent;

  const evH = ecyFinal + 20 - evTop;

  // -- Paso 2: pintar el marco con el alto ya definitivo, ANTES que el contenido --
  imgBox('marco-evaluacion', marco.morado, MARGIN, evTop, W - MARGIN * 2, evH, { draw, decorative: true });
  if (draw) { ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 10; ctx.drawImage(marco.morado, MARGIN, evTop, W - MARGIN * 2, evH); ctx.restore(); }

  // -- Paso 3: pintar el contenido encima, usando las posiciones ya calculadas --
  imgBox('eval-icono', ic.auditoria, evx, evIconTop, 34, 34, { draw, kind: 'icon', zoneCheck: 'evaluation' });
  const tituloBox = tt.draw('eval-titulo', 'EVALUACIÓN DE RECORRIDO M11', evx + 48, tituloBaseline, '700 23px "IBM Plex Sans"', '#fff', 'left', { draw, zoneCheck: 'evaluation', spacing: 0.4 });
  tt.draw('eval-sub', subTxt, evx + 48, subBaseline, '500 18px "IBM Plex Sans"', T.silver, 'left', { draw, zoneCheck: 'evaluation' });

  // La línea se corta de verdad detrás del bloque de título/subtítulo,
  // en vez de pasar por debajo como una sola línea continua.
  const corteIzq = evx + 48 - 10, corteDer = Math.max(tituloBox.x2, evx + 48 + tt.metrics(subTxt, '500 18px "IBM Plex Sans"').width) + 10;
  registerBox('eval-linea-izq', evx, lineaY, Math.max(0, corteIzq - evx), 1, { kind: 'line' });
  registerBox('eval-linea-der', corteDer, lineaY, Math.max(0, evRight - corteDer), 1, { kind: 'line' });
  if (draw) {
    ctx.strokeStyle = 'rgba(169,107,255,.4)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(evx, lineaY); ctx.lineTo(corteIzq, lineaY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(corteDer, lineaY); ctx.lineTo(evRight, lineaY); ctx.stroke();
  }

  tt.draw('eval-score', scoreTxt, scoreCX, scoreBaseline, '800 68px "Space Grotesk"', T.gold, 'center', { draw, zoneCheck: 'evaluation', shadow: draw ? 'rgba(244,193,78,.5)' : null, shadowBlur: 24 });
  tt.draw('eval-score-l1', 'CONDICIONES FAVORABLES', scoreCX, l1Baseline, '700 20px "IBM Plex Sans"', '#fff', 'center', { draw, zoneCheck: 'evaluation', spacing: 1.2 });

  const divX = evx + leftW;
  registerBox('eval-divisor', divX, lineaY + 10, 1, leftColBottom - (lineaY + 10), { kind: 'line' });
  if (draw) { ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(divX, lineaY + 10); ctx.lineTo(divX, ecy - 20); ctx.stroke(); }

  filas.forEach((f, i) => {
    if (f.c.on) { imgBox(`cond-icono-${i}`, ic.activo, rx, f.iconY, f.estIconSz, f.estIconSz, { draw, zoneCheck: 'evaluation' }); }
    else {
      registerBox(`cond-icono-${i}`, rx, f.iconY, f.estIconSz, f.estIconSz, { zoneCheck: 'evaluation' });
      if (draw) {
        ctx.beginPath(); ctx.arc(rx + f.estIconSz / 2, f.iconY + f.estIconSz / 2, f.estIconSz / 2, 0, Math.PI * 2);
        ctx.fillStyle = T.gold; ctx.globalAlpha = .22; ctx.fill(); ctx.globalAlpha = 1;
        ctx.strokeStyle = T.gold; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(rx + 8, f.iconY + f.estIconSz / 2); ctx.lineTo(rx + f.estIconSz - 8, f.iconY + f.estIconSz / 2); ctx.stroke();
      }
    }
    tt.draw(`cond-l-${i}`, f.c.l, rx + f.estIconSz + GAP_ICON_TEXT, f.lBaseline, `700 ${f.lPx}px "IBM Plex Sans"`, '#fff', 'left', { draw, zoneCheck: 'evaluation' });
    tt.draw(`cond-d-${i}`, f.c.d, rx + f.estIconSz + GAP_ICON_TEXT, f.dBaseline, `400 ${f.dPx}px "IBM Plex Sans"`, T.silver, 'left', { draw, zoneCheck: 'evaluation' });
  });

  registerBox('eval-linea-2', evx, lineaY2, evRight - evx, 1, { kind: 'line' });
  if (draw) { ctx.strokeStyle = 'rgba(169,107,255,.28)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(evx, lineaY2); ctx.lineTo(evRight, lineaY2); ctx.stroke(); }
  tt.draw('eval-nota', notaTxt, evx, notaBaseline, '400 16px "IBM Plex Sans"', T.muted, 'left', { draw, zoneCheck: 'evaluation' });

  // ============= ZONA FOOTER — tres franjas separadas + placa real contra el fondo =============
  const fz = ZONES.footer;
  const fraseFont = 24; // mínimo del rango 24-30px
  ctx.font = `600 ${fraseFont}px "Space Grotesk"`;
  const maxMsgW = W - MARGIN * 2 - 60;
  const palabras = data.mensaje.split(' ');
  let lineas = [], cur = '';
  palabras.forEach(w => { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxMsgW && cur) { lineas.push(cur); cur = w; } else cur = t; });
  if (cur) lineas.push(cur);
  // Nunca más de 3 líneas (punto 10): si no alcanza, se reparten las
  // palabras en 3 líneas más equilibradas sin bajar del tamaño mínimo.
  if (lineas.length > 3) {
    const porLinea = Math.ceil(palabras.length / 3);
    lineas = [0, 1, 2].map(i => palabras.slice(i * porLinea, (i + 1) * porLinea).join(' ')).filter(Boolean);
  }

  const fraseY0 = Math.max(fz.y0 + 26, evTop + evH + GAP_SECTION);
  let fm = tt.metrics('Ag', `600 ${fraseFont}px "Space Grotesk"`);
  const fraseLH = fm.ascent + fm.descent + GAP_LINE + 4;

  // Franja 2: etapa del torneo — propia, separada de la frase institucional
  let fy = fraseY0 + (lineas.length - 1) * fraseLH + fm.descent + 12;
  const etapaTxt = (data.etapa || '').toUpperCase();
  let mE = tt.metrics(etapaTxt, '700 18px "IBM Plex Sans"');
  const etapaBaseline = fy + mE.ascent;
  fy = etapaBaseline + mE.descent + 12;

  // Franja 3: firma + versión
  let m2 = tt.metrics('ASISTENTE OFICIAL M11', '700 18px "IBM Plex Sans"');
  const firmaY = fy + m2.ascent;
  fy = firmaY + m2.descent + 8;
  let m3 = tt.metrics('BIBLIOTECA VISUAL OFICIAL M11 v1.0', '500 18px "IBM Plex Sans"');
  const versionY = fy + m3.ascent;
  const pieBottom = versionY + m3.descent;

  // -- Placa real detrás de todo el pie: tapa por completo el campo, el
  // círculo central y cualquier rótulo propio del fondo en esa franja.
  // Se registra ANTES que el resto para que cubra las cajas que vengan.
  const shieldTop = fraseY0 - fm.ascent - 14, shieldBottom = pieBottom + 14;
  registerBox('pie-placa', 0, shieldTop, W, shieldBottom - shieldTop, { kind: 'shield' });
  if (draw) {
    let pg2 = ctx.createLinearGradient(0, shieldTop, 0, shieldBottom);
    pg2.addColorStop(0, 'rgba(5,11,20,0)'); pg2.addColorStop(0.12, 'rgba(5,11,20,.86)'); pg2.addColorStop(1, 'rgba(5,11,20,.9)');
    ctx.fillStyle = pg2; ctx.fillRect(0, shieldTop, W, shieldBottom - shieldTop);
  }
  // Zona conocida como peligrosa: el fondo trae ahí su propio rótulo y el
  // gráfico de cancha — se registra igual que cualquier línea, y queda
  // cancelada porque la placa de arriba ya la cubre por completo.
  registerBox('fondo-campo-y-rotulo', 0, Math.max(0, shieldTop), W, H - Math.max(0, shieldTop), { kind: 'line', hazard: true });

  lineas.forEach((ln, i) => {
    const txt = `"${lineas.length === 1 ? ln : (i === 0 ? ln : (i === lineas.length - 1 ? ln + '"' : ln))}${lineas.length === 1 ? '"' : ''}`;
    tt.draw(`frase-${i}`, txt, cx, fraseY0 + i * fraseLH, `600 ${fraseFont}px "Space Grotesk"`, '#fff', 'center', { draw, zoneCheck: 'footer' });
  });
  tt.draw('etapa', etapaTxt, cx, etapaBaseline, '700 18px "IBM Plex Sans"', T.gold, 'center', { draw, zoneCheck: 'footer', spacing: 2.2 });
  tt.draw('firma', 'ASISTENTE OFICIAL M11', cx, firmaY, '700 18px "IBM Plex Sans"', T.gold, 'center', { draw, zoneCheck: 'footer', spacing: 1.6 });
  tt.draw('version', 'BIBLIOTECA VISUAL OFICIAL M11 v1.0', cx, versionY, '500 18px "IBM Plex Sans"', T.silver, 'center', { draw, zoneCheck: 'footer', spacing: 1.2 });

  // margen inferior del pie: mínimo 24px, medido con el descenso real de la última línea
  console.log(`  margen inferior real: ${(H - pieBottom).toFixed(1)}px`);
  if (H - pieBottom < 24) COLLISIONS.push(`PIE: margen inferior insuficiente (${(H - pieBottom).toFixed(1)}px, mínimo 24px)`);

  return { strategiesBottom, bandTop, bandH, evTop, evH, cardTop, cardH, subY, gNumY, subGY };
}

async function generarLamina(data) {
  await asegurarFuentes();
  const bg = await loadImage(L + 'backgrounds/estadio_desarrollo.jpg');
  const marco = {
    azul: await loadImage(L + 'frames/marco_azul.png'), verde: await loadImage(L + 'frames/marco_verde.png'),
    dorado: await loadImage(L + 'frames/marco_dorado.png'), morado: await loadImage(L + 'frames/marco_morado.png'),
    gris: await loadImage(L + 'frames/marco_gris.png')
  };
  const brand = { m11: await loadImage(L + 'brand/m11_principal.png'), general: await loadImage(L + 'brand/estrategia_general.png'), pares: await loadImage(L + 'brand/estrategia_pares.png'), impares: await loadImage(L + 'brand/estrategia_impares.png') };
  const ic = {};
  for (const n of ['partidos_totales', 'empates', 'no_empates', 'ganancia', 'total_apostado', 'activo', 'auditoria']) {
    const key = { partidos_totales: 'partidos', empates: 'empates', no_empates: 'noEmpates', ganancia: 'ganancia', total_apostado: 'apostado', activo: 'activo', auditoria: 'auditoria' }[n];
    ic[key] = await loadImage(L + `icons/${n}.png`);
  }
  const assets = { bg, marco, brand, ic };

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // PASE 1: medir y registrar, sin dibujar
  await construir(data, ctx, false, assets);
  const ok = validatePosterLayout();

  if (!ok) {
    console.error(`Lámina M11: ${COLLISIONS.length} problema(s) detectado(s), no se genera:`);
    COLLISIONS.forEach(c => console.error(' - ' + c));
    return { ok: false, collisions: COLLISIONS.slice() };
  }

  // PASE 2: dibujar de verdad (mismas posiciones, ya validadas)
  await construir(data, ctx, true, assets);
  return { ok: true, canvas, elementos: BOXES.length };
}

function descargarCanvas(canvas, nombreArchivo) {
  return new Promise(resolve => {
    canvas.toBlob(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = nombreArchivo;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      resolve();
    }, 'image/png');
  });
}

// ============================================================
// Adaptador real: M11.Libro / M11.Store / M11.Evaluacion -> laminaData
// (misma lógica verificada del Sprint V1.1, portada a este mismo archivo
// para que la app no dependa de ningún script externo)
// ============================================================
const NOMBRE_ESTRATEGIA_L = { general: 'GENERAL', pares: 'PARES', impares: 'IMPARES' };
const FRAME_ESTRATEGIA_L = { general: 'azul', pares: 'verde', impares: 'dorado' };

function estadoTextoDeEstrategiaL(est) {
  if (est.bloqueada) return 'Cerrada definitivamente';
  if (est.nivel >= 9) return 'Nivel crítico';
  return 'Activa';
}

function evaluarBloqueEnCursoL(registrosDelBloque, numeroBloque, desde) {
  const posicionesEmpate = [];
  registrosDelBloque.forEach((r, i) => { if (r.resultado === 'empate') posicionesEmpate.push(i + 1); });
  const empates = posicionesEmpate.length;
  const porcentajeEmpates = Math.round((empates / 20) * 1000) / 10;
  const cumpleC1 = empates >= 5;
  const primerEmpatePosicion = posicionesEmpate.length ? posicionesEmpate[0] : null;
  const cumpleC2 = primerEmpatePosicion !== null && primerEmpatePosicion < 12;
  let cumpleC3 = false;
  for (let p = 16; p <= 19; p++) { if (posicionesEmpate.includes(p) && posicionesEmpate.includes(p + 1)) { cumpleC3 = true; break; } }
  const condicionesCumplidas = [cumpleC1, cumpleC2, cumpleC3].filter(Boolean).length;
  return {
    bloque: numeroBloque, desde, hasta: desde + 19, registrados: registrosDelBloque.length,
    cumplidas: condicionesCumplidas, total: 3,
    condiciones: [
      { on: cumpleC1, l: 'C1 · Empates', d: `${empates} de 20 registrados (${porcentajeEmpates}%)` },
      { on: cumpleC2, l: 'C2 · Primer empate', d: primerEmpatePosicion ? `Se presentó en el partido ${primerEmpatePosicion}` : 'Todavía no se presenta' },
      { on: cumpleC3, l: 'C3 · Consecutivos', d: registrosDelBloque.length < 16 ? 'Se define entre partidos 16 y 20' : (cumpleC3 ? 'Se presentó entre partidos 16 y 20' : 'No se presentó') }
    ]
  };
}

function pad2(n) { return String(n).padStart(2, '0'); }
function formatearFechaHoraL(d) { return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()} · ${pad2(d.getHours())}:${pad2(d.getMinutes())}`; }

function libroToLaminaData() {
  const resumen = M11.Libro.resumenGeneral();
  const est = M11.Store.getEstrategias();
  const registros = M11.Libro.listar();

  const ultimaCerrada = M11.Evaluacion.ultima();
  const bloqueActualNum = Math.floor(resumen.totalPartidos / 20) + (resumen.totalPartidos % 20 === 0 && resumen.totalPartidos > 0 ? 0 : 1);
  let evaluacion;
  if (ultimaCerrada && resumen.totalPartidos % 20 === 0 && resumen.totalPartidos > 0 && ultimaCerrada.hasta === resumen.totalPartidos) {
    evaluacion = {
      bloque: ultimaCerrada.bloque, desde: ultimaCerrada.desde, hasta: ultimaCerrada.hasta,
      registrados: ultimaCerrada.hasta - ultimaCerrada.desde + 1, cumplidas: ultimaCerrada.condicionesCumplidas, total: 3,
      condiciones: [
        { on: ultimaCerrada.cumpleC1, l: 'C1 · Empates', d: `${ultimaCerrada.empates} de 20 registrados (${ultimaCerrada.porcentajeEmpates}%)` },
        { on: ultimaCerrada.cumpleC2, l: 'C2 · Primer empate', d: ultimaCerrada.primerEmpatePosicion ? `Se presentó en el partido ${ultimaCerrada.primerEmpatePosicion}` : 'No se presentó' },
        { on: ultimaCerrada.cumpleC3, l: 'C3 · Consecutivos', d: ultimaCerrada.cumpleC3 ? 'Se presentó entre partidos 16 y 20' : 'No se presentó' }
      ]
    };
  } else {
    const desdeBloqueActual = (bloqueActualNum - 1) * 20 + 1;
    const registrosBloqueActual = registros.filter(r => r.numero >= desdeBloqueActual && r.numero <= desdeBloqueActual + 19);
    evaluacion = evaluarBloqueEnCursoL(registrosBloqueActual, bloqueActualNum, desdeBloqueActual);
  }

  const estrategias = {};
  ['general', 'pares', 'impares'].forEach(n => {
    estrategias[n] = {
      nombre: NOMBRE_ESTRATEGIA_L[n], nivel: est[n].nivel, bars: Math.min(11, est[n].nivel),
      capital: est[n].disponible, estado: estadoTextoDeEstrategiaL(est[n]), frame: FRAME_ESTRATEGIA_L[n]
    };
  });

  return {
    torneo: resumen.torneo || 'Torneo M11',
    fechaCorte: formatearFechaHoraL(new Date()),
    bloqueEstado: `Bloque ${evaluacion.bloque} de 20 · ${evaluacion.registrados < 20 ? 'en curso' : 'cerrado'}`,
    etapa: 'Desarrollo del torneo',
    partidos: resumen.totalPartidos, empates: resumen.empates, noEmpates: resumen.noEmpates,
    totalApostado: resumen.totalApostadoAcum, gananciaAcumulada: resumen.gananciaAcumulada, capitalInicial: resumen.capitalInicial,
    capitalDisponible: resumen.capitalDisponible,
    estrategias, evaluacion,
    mensaje: 'El Modelo M11 no predice el próximo empate. Acompaña la disciplina de calcular, registrar, respetar las reglas y saber cuándo detenerse.'
  };
}

// ============================================================
// API pública: botón real de la app
// ============================================================
window.M11 = window.M11 || {};
window.M11.Lamina = {
  async generarDesdeLibro() {
    if (!M11.Libro || !M11.Store) throw new Error('El Libro de Operaciones todavía no está disponible.');
    const data = libroToLaminaData();
    const resultado = await generarLamina(data);
    if (resultado.ok) {
      const nombre = `Lamina_Oficial_M11_${data.partidos}partidos_${Date.now()}.png`;
      await descargarCanvas(resultado.canvas, nombre);
    }
    return resultado;
  }
};

})();
