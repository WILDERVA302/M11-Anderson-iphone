/* =========================================================
   M11 · exportar.js — Exportar imagen (Sprint V1.0 consolidado)
   -----------------------------------------------------------
   Genera una o varias imágenes PNG verticales con el resumen de
   la operación en Vista Resumida, para compartir o guardar como
   evidencia del avance del torneo. Se dibuja con <canvas> nativo
   — sin librerías externas, porque esta app corre local
   (INICIAR_M11.bat) y muchas veces sin internet.

   No es una captura de pantalla: se construye a partir de los
   mismos datos y funciones de interpretación que ya usa
   libro-ui.js (M11.LibroUI.registrosFiltradosActuales, etc.) —
   nunca se recalcula ni se reinterpreta nada por separado. La
   misma fuente de datos sirve tanto para Operación Real como
   para el Centro de Pruebas: ambos leen del mismo M11.Libro.

   Decisión de arquitectura (Sprint V1.0 consolidado):
   - En computador NUNCA se usa navigator.share(): se genera el
     PNG, se descarga automáticamente, y se avisa con claridad
     dónde quedó el archivo. El usuario nunca debe preguntarse
     "¿pasó algo?".
   - En celular, si el navegador admite compartir archivos de
     verdad (canShare + share con el archivo real), se abre el
     menú Compartir del sistema. Si no, mismo comportamiento que
     computador.
   - Nunca se elimina información sin avisar: si la selección
     visible supera el máximo razonable por imagen, se generan
     varias imágenes consecutivas (nunca se recorta en silencio).

   La selección de partidos SIEMPRE es la que el operador tiene
   activa (misma vista y mismos filtros que en pantalla). Nunca se
   cambia en silencio.

   Ninguna excepción queda sin capturar: el flujo nunca termina
   sin una salida visible (compartir, descargar, o un mensaje de
   error claro).
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const ANCHO = 1080;
  const MARGEN = 56;
  const NOMBRE_ESTRATEGIA = { general: 'General', pares: 'Pares', impares: 'Impares' };
  const TIMEOUT_TOBLOB_MS = 8000;

  function log(...args) { console.log('[M11.Exportar]', ...args); }

  // ---- Detección de dispositivo (única función de toda la app) -----------
  // Ningún método es 100% infalible sin depender de librerías externas;
  // se usa el estándar moderno (userAgentData.mobile) cuando existe, con
  // respaldo por userAgent. Esto decide ÚNICAMENTE si se intenta
  // compartir — en computador jamás se llama a navigator.share().
  function esDispositivoMovil() {
    try {
      if (navigator.userAgentData && typeof navigator.userAgentData.mobile === 'boolean') {
        return navigator.userAgentData.mobile;
      }
    } catch (e) { /* sigue con el respaldo */ }
    const ua = (navigator.userAgent || '').toLowerCase();
    return /android|iphone|ipad|ipod|mobile/.test(ua);
  }

  // ---- Preparación de datos (sin <canvas>, fácil de probar) ---------------

  function limpiarParaNombreArchivo(txt) {
    const limpio = (txt || '')
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quita tildes
      .replace(/[^a-zA-Z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '');
    return limpio || 'Torneo';
  }

  function fechaCorteTexto(fecha) {
    const d = fecha || new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
  }

  function horaCorteTexto(fecha) {
    const d = fecha || new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  // Una sola imagen: Clausura_2026_M11_29-07-2026.png
  // Varias imágenes: Clausura_2026_M11_29-07-2026_01_de_03.png
  function nombreArchivo(torneo, fecha, pagina, totalPaginas) {
    const base = `${limpiarParaNombreArchivo(torneo)}_M11_${fechaCorteTexto(fecha)}`;
    if (!totalPaginas || totalPaginas <= 1) return `${base}.png`;
    const pad = n => String(n).padStart(2, '0');
    return `${base}_${pad(pagina)}_de_${pad(totalPaginas)}.png`;
  }

  const MAX_PARTIDOS_POR_PAGINA = 8; // en las páginas de partidos (la página 1 es siempre el resumen)
  const ALTO_PAGINA = 1350;

  // Exactamente la selección visible del operador en Vista Resumida
  // (mismo orden, mismos filtros que la pantalla). La página 1 siempre
  // es el resumen completo; los partidos se reparten en páginas de 8 —
  // nunca se descarta nada ni se cambia la selección en silencio.
  function prepararSeleccionParaImagen() {
    const seleccionados = M11.LibroUI.registrosFiltradosActuales();
    const total = seleccionados.length;
    const paginasPartidos = [];
    for (let p = 0; p * MAX_PARTIDOS_POR_PAGINA < total; p++) {
      paginasPartidos.push(seleccionados.slice(p * MAX_PARTIDOS_POR_PAGINA, (p + 1) * MAX_PARTIDOS_POR_PAGINA));
    }
    const totalPaginas = 1 + paginasPartidos.length; // 1 (resumen) + páginas de partidos
    return { total, paginasPartidos, totalPaginas };
  }

  // ---- Dibujo (usa <canvas>) ------------------------------------------------
  // Cinco bloques en la página de resumen (Resultado general, Estado
  // financiero, Estrategias, Evaluación de recorrido) más una página por
  // cada tanda de partidos — todo sale de M11.Libro.resumenGeneral(),
  // M11.Evaluacion.ultima() y cada registro completo del Libro: los
  // mismos datos que ya muestra Plantillas M11 (la fuente del PDF).
  // Ninguna cifra se recalcula aparte.

  function truncarTexto(ctx, texto, anchoMax) {
    if (ctx.measureText(texto).width <= anchoMax) return texto;
    let t = texto;
    while (t.length > 1 && ctx.measureText(t + '…').width > anchoMax) t = t.slice(0, -1);
    return t + '…';
  }

  // Reparte un texto largo en varias líneas que quepan en anchoMax (para
  // el mensaje de la Evaluación de recorrido, que puede ser un párrafo).
  function envolverTexto(ctx, texto, anchoMax) {
    const palabras = String(texto).split(' ');
    const lineas = [];
    let actual = '';
    palabras.forEach(palabra => {
      const prueba = actual ? actual + ' ' + palabra : palabra;
      if (ctx.measureText(prueba).width > anchoMax && actual) {
        lineas.push(actual);
        actual = palabra;
      } else {
        actual = prueba;
      }
    });
    if (actual) lineas.push(actual);
    return lineas;
  }

  function formatearFechaSimple(f) {
    if (!f) return 'No disponible';
    const d = new Date(f);
    if (isNaN(d.getTime())) return String(f);
    const pad = n => String(n).padStart(2, '0');
    return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
  }

  function rectRedondeado(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  const TONOS = {
    verde: ['#dcfce7', '#15803d'],
    rojo: ['#fee2e2', '#991b1b'],
    naranja: ['#ffedd5', '#9a3412'],
    gris: ['#e2e8f0', '#475569']
  };

  // Insignia pequeña (resultado de un partido, C1/C2/C3). Devuelve el
  // ancho ocupado, para poder encadenar varias en la misma fila.
  function dibujarPill(ctx, x, y, texto, tono) {
    const [fondo, letra] = TONOS[tono] || TONOS.gris;
    ctx.font = '800 13px sans-serif';
    const w = ctx.measureText(texto).width + 24;
    const h = 27;
    rectRedondeado(ctx, x, y, w, h, h / 2);
    ctx.fillStyle = fondo;
    ctx.fill();
    ctx.textAlign = 'left';
    ctx.fillStyle = letra;
    ctx.fillText(texto, x + 12, y + 18);
    return w;
  }

  function dibujarLinea(ctx, y) {
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(MARGEN, y);
    ctx.lineTo(ANCHO - MARGEN, y);
    ctx.stroke();
  }

  function dibujarTituloSeccion(ctx, texto, y) {
    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f172a';
    ctx.font = '800 21px sans-serif';
    ctx.fillText(texto, MARGEN, y);
    return y + 32;
  }

  function dibujarEncabezadoPagina(ctx, datos) {
    const { torneo, fechaInicio, fechaCorte, horaCorte, pagina, totalPaginas, compacto } = datos;
    let y = 56;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#1d4ed8';
    ctx.font = '800 16px sans-serif';
    ctx.fillText(`LIBRO DE OPERACIONES M11 · PÁGINA ${pagina} DE ${totalPaginas}`, MARGEN, y);
    y += compacto ? 40 : 48;
    ctx.fillStyle = '#0f172a';
    ctx.font = `900 ${compacto ? 30 : 38}px sans-serif`;
    ctx.fillText(truncarTexto(ctx, torneo || 'Torneo M11', ANCHO - MARGEN * 2), MARGEN, y);
    y += compacto ? 28 : 32;
    ctx.fillStyle = '#64748b';
    ctx.font = '600 16px sans-serif';
    ctx.fillText(`Fecha y hora de corte: ${fechaCorte}, ${horaCorte}`, MARGEN, y);
    y += 22;
    if (!compacto) {
      ctx.font = '500 13px sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(`Inicio del torneo: ${formatearFechaSimple(fechaInicio)}`, MARGEN, y);
      y += 18;
    }
    return y + 12;
  }

  function dibujarPie(ctx, canvas) {
    const y = canvas.height - 34;
    dibujarLinea(ctx, y - 22);
    ctx.textAlign = 'center';
    ctx.font = '700 14px sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText('Asistente Oficial M11', ANCHO / 2, y);
  }

  function dibujarKpiGrande(ctx, x, y, w, h, etiqueta, valor, tono) {
    rectRedondeado(ctx, x, y, w, h, 16);
    const fondos = { verde: '#f0fdf4', rojo: '#fef2f2' };
    ctx.fillStyle = tono ? fondos[tono] : '#f1f5f9';
    ctx.fill();
    ctx.textAlign = 'left';
    const colores = { verde: '#15803d', rojo: '#b91c1c' };
    ctx.fillStyle = tono ? colores[tono] : '#0f172a';
    ctx.font = `900 ${String(valor).length > 9 ? 22 : 27}px sans-serif`;
    ctx.fillText(truncarTexto(ctx, String(valor), w - 28), x + 18, y + h - 46);
    ctx.fillStyle = tono ? colores[tono] : '#64748b';
    ctx.font = '700 12px sans-serif';
    ctx.fillText(etiqueta.toUpperCase(), x + 18, y + h - 18);
  }

  // Bloque 1 — Resultado general: partidos totales, empates, no empates,
  // ganancia/pérdida acumulada (con color según signo) + desglose de
  // apostados/no apostados/cancelados.
  function dibujarResultadoGeneral(ctx, y, resumen) {
    y = dibujarTituloSeccion(ctx, 'Resultado general', y);
    const anchoCard = (ANCHO - MARGEN * 2 - 3 * 14) / 4;
    const altoCard = 118;
    const ganancia = resumen.gananciaAcumulada;
    const tonoGanancia = ganancia === null ? null : (ganancia >= 0 ? 'verde' : 'rojo');
    const datos = [
      { etiqueta: 'Partidos totales', valor: resumen.totalPartidos, tono: null },
      { etiqueta: 'Empates', valor: resumen.empates, tono: null },
      { etiqueta: 'No empates', valor: resumen.noEmpates, tono: null },
      { etiqueta: 'Ganancia/Pérdida', valor: ganancia === null ? 'No disp.' : (ganancia >= 0 ? '+' : '−') + M11.Libro.fmt(Math.abs(ganancia)), tono: tonoGanancia }
    ];
    datos.forEach((d, i) => {
      const x = MARGEN + i * (anchoCard + 14);
      dibujarKpiGrande(ctx, x, y, anchoCard, altoCard, d.etiqueta, d.valor, d.tono);
    });
    y += altoCard + 20;
    ctx.textAlign = 'left';
    ctx.font = '600 14px sans-serif';
    ctx.fillStyle = '#475569';
    ctx.fillText(`Apostados: ${resumen.apostados}   ·   No apostados: ${resumen.noApostados}   ·   Cancelados: ${resumen.cancelados}`, MARGEN, y);
    return y + 24;
  }

  // Bloque 2 — Estado financiero.
  function dibujarEstadoFinanciero(ctx, y, resumen) {
    y = dibujarTituloSeccion(ctx, 'Estado financiero', y);
    const items = [
      ['Capital inicial', resumen.capitalInicial],
      ['Capital disponible', resumen.capitalDisponible],
      ['Capital en juego', resumen.capitalComprometido],
      ['Total apostado', resumen.totalApostadoAcum],
      ['Total retornado', resumen.totalRetornadoAcum]
    ];
    const anchoCard = (ANCHO - MARGEN * 2 - 4 * 12) / 5;
    const altoCard = 100;
    items.forEach((it, i) => {
      const x = MARGEN + i * (anchoCard + 12);
      rectRedondeado(ctx, x, y, anchoCard, altoCard, 14);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.strokeStyle = '#e2e8f0';
      ctx.stroke();
      ctx.textAlign = 'left';
      ctx.fillStyle = '#0f172a';
      ctx.font = '800 14px sans-serif';
      ctx.fillText(truncarTexto(ctx, M11.Libro.fmt(it[1] || 0), anchoCard - 18), x + 10, y + altoCard - 46);
      ctx.fillStyle = '#64748b';
      ctx.font = '700 10px sans-serif';
      const lineasEtiqueta = envolverTexto(ctx, it[0].toUpperCase(), anchoCard - 18);
      lineasEtiqueta.slice(0, 2).forEach((l, li) => ctx.fillText(l, x + 10, y + altoCard - 26 + li * 13));
    });
    return y + altoCard + 20;
  }

  // Bloque 3 — Estrategias: nivel, saldo y estado de cada una.
  function dibujarEstrategiasBloque(ctx, y) {
    y = dibujarTituloSeccion(ctx, 'Estrategias', y);
    const est = M11.Store.getEstrategias();
    const anchoCol = (ANCHO - MARGEN * 2 - 2 * 14) / 3;
    const altoCard = 130;
    ['general', 'pares', 'impares'].forEach((n, i) => {
      const x = MARGEN + i * (anchoCol + 14);
      const activa = !est[n].bloqueada;
      rectRedondeado(ctx, x, y, anchoCol, altoCard, 14);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.strokeStyle = '#e2e8f0';
      ctx.stroke();
      ctx.textAlign = 'center';
      const cx = x + anchoCol / 2;
      ctx.fillStyle = '#0f172a';
      ctx.font = '800 17px sans-serif';
      ctx.fillText(NOMBRE_ESTRATEGIA[n], cx, y + 30);
      ctx.font = '900 25px sans-serif';
      ctx.fillText(`Nivel ${est[n].nivel}`, cx, y + 65);
      ctx.font = '600 14px sans-serif';
      ctx.fillStyle = '#334155';
      ctx.fillText(truncarTexto(ctx, M11.Libro.fmt(est[n].disponible), anchoCol - 20), cx, y + 91);
      ctx.fillStyle = activa ? '#15803d' : '#991b1b';
      ctx.font = '800 12px sans-serif';
      ctx.fillText(activa ? 'ACTIVA' : 'FINALIZADA', cx, y + 114);
    });
    return y + altoCard + 16;
  }

  // Bloque 5 — Evaluación de recorrido M11.
  function dibujarEvaluacion(ctx, y, evaluacion) {
    y = dibujarTituloSeccion(ctx, 'Evaluación de recorrido M11', y);
    if (!evaluacion) {
      ctx.textAlign = 'left';
      ctx.font = '600 15px sans-serif';
      ctx.fillStyle = '#475569';
      ctx.fillText('Todavía no se completó el primer bloque de 20 partidos.', MARGEN, y + 6);
      return y + 40;
    }
    ctx.textAlign = 'left';
    ctx.font = '700 15px sans-serif';
    ctx.fillStyle = '#0f172a';
    ctx.fillText(`Bloque ${evaluacion.bloque} · Partidos ${evaluacion.desde}–${evaluacion.hasta}`, MARGEN, y + 4);
    y += 32;
    let x = MARGEN;
    x += dibujarPill(ctx, x, y, `${evaluacion.cumpleC1 ? '✓' : '—'} C1 · ${evaluacion.empates} empates (${evaluacion.porcentajeEmpates}%)`, evaluacion.cumpleC1 ? 'verde' : 'gris') + 10;
    x += dibujarPill(ctx, x, y, `${evaluacion.cumpleC2 ? '✓' : '—'} C2 · 1er empate`, evaluacion.cumpleC2 ? 'verde' : 'gris') + 10;
    dibujarPill(ctx, x, y, `${evaluacion.cumpleC3 ? '✓' : '—'} C3 · consecutivos`, evaluacion.cumpleC3 ? 'verde' : 'gris');
    y += 42;
    ctx.font = '800 15px sans-serif';
    ctx.fillStyle = '#0f172a';
    ctx.fillText(`${evaluacion.condicionesCumplidas} de 3 condiciones favorables`, MARGEN, y);
    y += 24;
    ctx.font = '500 13px sans-serif';
    ctx.fillStyle = '#64748b';
    const lineas = envolverTexto(ctx, evaluacion.mensaje, ANCHO - MARGEN * 2);
    lineas.forEach(l => { ctx.fillText(l, MARGEN, y); y += 18; });
    return y + 8;
  }

  // Bloque 4 — una tarjeta ancha por partido (nunca tabla comprimida):
  // número, fecha, equipos, resultado, movimiento de cada estrategia,
  // apostado, retorno y saldo total después.
  function dibujarTarjetaPartido(ctx, y, r, alto) {
    rectRedondeado(ctx, MARGEN, y, ANCHO - MARGEN * 2, alto, 12);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = '#e2e8f0';
    ctx.stroke();

    const padX = 18;
    let ty = y + 27;
    ctx.textAlign = 'left';
    ctx.font = '800 15px sans-serif';
    ctx.fillStyle = '#0f172a';
    const fecha = M11.LibroUI.formatearFecha(r.fechaHora);
    const encabezado = `#${r.numero}   ${fecha}   ${r.equipoLocal || '—'} vs ${r.equipoVisitante || '—'}`;
    ctx.fillText(truncarTexto(ctx, encabezado, ANCHO - MARGEN * 2 - padX * 2 - 140), MARGEN + padX, ty);

    const resultado = M11.LibroUI.resultadoTexto(r);
    const tonoResultado = r.resultado === 'empate' ? 'verde' : (r.resultado === 'no_empate' ? 'rojo' : 'gris');
    dibujarPill(ctx, ANCHO - MARGEN - padX - 120, y + 13, resultado, tonoResultado);

    ty += 29;
    ctx.font = '600 13px sans-serif';
    ctx.fillStyle = '#334155';
    const etiquetasMov = { general: 'General', pares: 'Pares', impares: 'Impares' };
    const movs = ['general', 'pares', 'impares'].map(n => `${etiquetasMov[n]}: ${M11.LibroUI.resumenCompactoEstrategia(r.estrategias[n])}`).join('     ');
    ctx.fillText(truncarTexto(ctx, movs, ANCHO - MARGEN * 2 - padX * 2), MARGEN + padX, ty);

    ty += 28;
    ctx.font = '600 13px sans-serif';
    ctx.fillStyle = '#475569';
    const saldoTxt = (r.capitalTotalDespues !== null && r.capitalTotalDespues !== undefined) ? M11.Libro.fmt(r.capitalTotalDespues) : 'No disponible';
    const fin = `Apostado: ${M11.Libro.fmt(r.totalApostado || 0)}     Retorno: ${M11.Libro.fmt(r.retornoTotal || 0)}     Saldo total: ${saldoTxt}`;
    ctx.fillText(truncarTexto(ctx, fin, ANCHO - MARGEN * 2 - padX * 2), MARGEN + padX, ty);

    return y + alto;
  }

  function construirCanvas() {
    const canvas = document.createElement('canvas');
    canvas.width = ANCHO;
    canvas.height = ALTO_PAGINA;
    return canvas;
  }

  // Página 1: encabezado + los 4 bloques de resumen. Siempre existe,
  // incluso sin partidos todavía.
  function dibujarPaginaResumen(ctx, canvas, resumen, evaluacion, meta, fechaCorte, horaCorte) {
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let y = dibujarEncabezadoPagina(ctx, { torneo: resumen.torneo, fechaInicio: resumen.fechaInicio, fechaCorte, horaCorte, pagina: meta.pagina, totalPaginas: meta.totalPaginas, compacto: false });
    dibujarLinea(ctx, y); y += 26;
    y = dibujarResultadoGeneral(ctx, y, resumen);
    dibujarLinea(ctx, y); y += 26;
    y = dibujarEstadoFinanciero(ctx, y, resumen);
    dibujarLinea(ctx, y); y += 26;
    y = dibujarEstrategiasBloque(ctx, y);
    dibujarLinea(ctx, y); y += 26;
    y = dibujarEvaluacion(ctx, y, evaluacion);
    dibujarPie(ctx, canvas);
    return y;
  }

  // Páginas 2 en adelante: hasta 8 tarjetas de partido cada una.
  function dibujarPaginaPartidos(ctx, canvas, resumen, datosPagina, meta, fechaCorte, horaCorte) {
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let y = dibujarEncabezadoPagina(ctx, { torneo: resumen.torneo, fechaCorte, horaCorte, pagina: meta.pagina, totalPaginas: meta.totalPaginas, compacto: true });
    dibujarLinea(ctx, y); y += 22;
    ctx.textAlign = 'left';
    ctx.font = '800 18px sans-serif';
    ctx.fillStyle = '#0f172a';
    ctx.fillText(`Partidos registrados (${datosPagina.desde}–${datosPagina.hasta} de ${datosPagina.total})`, MARGEN, y);
    y += 26;
    const altoTarjeta = 118, gap = 13;
    datosPagina.incluidos.forEach(r => { y = dibujarTarjetaPartido(ctx, y, r, altoTarjeta) + gap; });
    dibujarPie(ctx, canvas);
    return y;
  }


  // canvas.toBlob(), envuelto en una Promesa con un tope de tiempo: si el
  // navegador nunca llama al callback (puede pasar en algunos casos), no
  // se queda esperando para siempre — se trata como un fallo real.
  function canvasToBlobPromise(canvas, tipo, timeoutMs) {
    return new Promise((resolve, reject) => {
      let terminado = false;
      const temporizador = setTimeout(() => {
        if (terminado) return;
        terminado = true;
        reject(new Error('canvas.toBlob no respondió a tiempo.'));
      }, timeoutMs);
      try {
        canvas.toBlob(blob => {
          if (terminado) return;
          terminado = true;
          clearTimeout(temporizador);
          if (blob) resolve(blob);
          else reject(new Error('canvas.toBlob devolvió un blob vacío.'));
        }, tipo);
      } catch (err) {
        if (terminado) return;
        terminado = true;
        clearTimeout(temporizador);
        reject(err);
      }
    });
  }

  // ---- Estado visible del botón y mensajes -------------------------------

  function botonExportar() { return document.getElementById('libroCompartirBtn'); }

  function fijarEstadoBoton(cargando, textoOriginal) {
    const boton = botonExportar();
    if (!boton) return;
    boton.disabled = cargando;
    boton.textContent = cargando ? 'Generando imagen…' : textoOriginal;
  }

  function mostrarMensaje(texto, tipo) {
    const el = document.getElementById('compartirEstadoMsg');
    if (!el) { if (texto) log('mensaje (sin elemento visible en esta pantalla):', texto); return; }
    if (!texto) { el.classList.add('hidden'); el.textContent = ''; el.className = 'hidden'; return; }
    el.textContent = texto;
    el.className = tipo === 'exito' ? 'mensaje-exito' : 'mensaje-error';
  }

  function mostrarMensajeExito(archivos) {
    if (archivos.length === 1) {
      mostrarMensaje(`Imagen generada correctamente. Archivo: ${archivos[0].nombre}. Revisa la carpeta Descargas.`, 'exito');
    } else {
      mostrarMensaje(`Se generaron ${archivos.length} imágenes correctamente. Revisa la carpeta Descargas.`, 'exito');
    }
  }

  // ---- Compartir (solo móvil con soporte real) o descarga (comportamiento por defecto y respaldo obligatorio) ----

  async function compartirODescargarTodas(archivos) {
    const movil = esDispositivoMovil();
    log('dispositivo móvil:', movil);

    if (movil) {
      const puedeIntentar = !!(navigator.share && navigator.canShare);
      log('canShare disponible:', puedeIntentar);
      if (puedeIntentar) {
        try {
          const files = archivos.map(a => new File([a.blob], a.nombre, { type: 'image/png' }));
          if (navigator.canShare({ files })) {
            log('inicio de navigator.share');
            await navigator.share({ files, title: archivos[0].nombre });
            log('compartido correctamente');
            return;
          }
          log('canShare no admite estos archivos; se descarga como respaldo');
        } catch (err) {
          if (err && err.name === 'AbortError') {
            log('el usuario canceló el diálogo de compartir (no es un error)');
            return;
          }
          log('fallo técnico al compartir, se descarga como respaldo:', err && err.message ? err.message : err);
        }
      }
    } else {
      log('computador detectado: no se usa navigator.share, se descarga directamente');
    }

    log('descarga alternativa');
    archivos.forEach(a => descargar(a.blob, a.nombre));
    mostrarMensajeExito(archivos);
  }

  function descargar(blob, archivo) {
    if (typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') {
      throw new Error('Este navegador no admite generar el archivo de descarga.');
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = archivo;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  // ---- Punto de entrada -------------------------------------------------------
  // Nunca termina en silencio: comparte, descarga, o muestra un mensaje
  // de error claro. Ninguna excepción queda sin capturar. Funciona igual
  // en Operación Real y en Centro de Pruebas (misma fuente de datos:
  // M11.Libro).
  async function generarImagenResumen() {
    const boton = botonExportar();
    const textoOriginal = boton ? boton.textContent : '🖼 Exportar imagen';
    log('inicio de exportación');
    mostrarMensaje('');
    fijarEstadoBoton(true, textoOriginal);

    try {
      if (!M11.LibroUI || !M11.Libro || !M11.Store) {
        throw new Error('El módulo del Libro de Operaciones no está disponible todavía.');
      }
      const resumen = M11.Libro.resumenGeneral();
      const evaluacion = M11.Evaluacion ? M11.Evaluacion.ultima() : null;
      const seleccion = prepararSeleccionParaImagen();
      log('datos recibidos:', { total: seleccion.total, totalPaginas: seleccion.totalPaginas });

      const fecha = new Date();
      const fechaCorte = fechaCorteTexto(fecha);
      const horaCorte = horaCorteTexto(fecha);
      const archivos = [];

      async function generarPagina(pagina, dibujarFn) {
        const canvas = construirCanvas();
        log(`canvas creado (página ${pagina}/${seleccion.totalPaginas}):`, canvas.width + 'x' + canvas.height);
        if (!(canvas.width > 0 && canvas.height > 0)) {
          throw new Error('El canvas generado no tiene dimensiones válidas.');
        }
        const ctx = canvas.getContext && canvas.getContext('2d');
        if (!ctx) throw new Error('Este navegador no admite dibujar sobre <canvas>.');

        dibujarFn(ctx, canvas);
        log(`dibujo terminado (página ${pagina})`);

        const blob = await canvasToBlobPromise(canvas, 'image/png', TIMEOUT_TOBLOB_MS);
        log(`blob generado (página ${pagina}):`, blob.type, blob.size + ' bytes');
        if (!blob.size) throw new Error('La imagen generada está vacía.');

        const archivo = nombreArchivo(resumen.torneo, fecha, pagina, seleccion.totalPaginas);
        log('archivo creado:', archivo);
        archivos.push({ blob, nombre: archivo });
      }

      // Página 1: resumen completo (siempre existe, incluso sin partidos).
      await generarPagina(1, (ctx, canvas) => {
        dibujarPaginaResumen(ctx, canvas, resumen, evaluacion, { pagina: 1, totalPaginas: seleccion.totalPaginas }, fechaCorte, horaCorte);
      });

      // Páginas 2 en adelante: hasta 8 partidos cada una.
      for (let i = 0; i < seleccion.paginasPartidos.length; i++) {
        const incluidos = seleccion.paginasPartidos[i];
        const pagina = i + 2;
        const desde = i * MAX_PARTIDOS_POR_PAGINA + 1;
        const hasta = desde + incluidos.length - 1;
        await generarPagina(pagina, (ctx, canvas) => {
          dibujarPaginaPartidos(ctx, canvas, resumen, { incluidos, desde, hasta, total: seleccion.total }, { pagina, totalPaginas: seleccion.totalPaginas }, fechaCorte, horaCorte);
        });
      }

      await compartirODescargarTodas(archivos);
    } catch (err) {
      log('error capturado:', err && err.message ? err.message : err);
      mostrarMensaje('No fue posible generar la imagen. Revisa la consola técnica e inténtalo nuevamente.', 'error');
    } finally {
      fijarEstadoBoton(false, textoOriginal);
    }
  }

  M11.Exportar = {
    generarImagenResumen,
    esDispositivoMovil,
    MAX_PARTIDOS_POR_PAGINA,
    // Expuestas para pruebas automatizadas (no dependen de <canvas>,
    // así se pueden verificar sin un navegador real).
    _prepararSeleccionParaImagen: prepararSeleccionParaImagen,
    _nombreArchivo: nombreArchivo,
    _limpiarParaNombreArchivo: limpiarParaNombreArchivo,
    _fechaCorteTexto: fechaCorteTexto,
    _construirCanvas: construirCanvas,
    _dibujarPaginaResumen: dibujarPaginaResumen,
    _dibujarPaginaPartidos: dibujarPaginaPartidos,
    _canvasToBlobPromise: canvasToBlobPromise
  };

})(window.M11);
