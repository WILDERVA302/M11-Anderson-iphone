/* =========================================================
   M11 · bookmakers-datos.js  (Sprint V1.0.5 — corrección file://)
   -----------------------------------------------------------
   Respaldo incorporado del catálogo de casas de apuestas. Existe
   porque fetch("data/bookmakers.json") NO funciona cuando la
   aplicación se abre directamente como archivo local
   (file:///C:/...) — los navegadores bloquean fetch() a archivos
   locales por seguridad (política del mismo origen), aunque el
   archivo exista y sea válido. Un <script> normal, en cambio, SÍ se
   carga sin problema bajo file://, localhost y dentro de Capacitor
   — por eso el catálogo también vive acá, como una variable
   JavaScript común y corriente.

   app/data/bookmakers.json sigue siendo la fuente PRINCIPAL y
   editable (js/casas-ui.js siempre intenta cargarla primero, y la
   usa si lo logra — funciona en localhost y dentro de Capacitor).
   Este archivo es el respaldo para cuando ese fetch no es posible.

   IMPORTANTE PARA MANTENIMIENTO: si edita app/data/bookmakers.json
   (agregar, quitar o corregir una casa), copie el mismo cambio acá
   — de lo contrario, alguien que abra la app como archivo local
   (file://) seguirá viendo el catálogo viejo. Debe ser exactamente
   el mismo contenido en las dos partes, solo que uno es .json y este
   es una variable de JavaScript.
   ========================================================= */
window.M11_BOOKMAKERS = {
  "version": 1,
  "paises": {
    "Colombia": {
      "fuente": "Coljuegos (coljuegos.gov.co), lista oficial de operadores autorizados, consultada el 10/08/2026",
      "casas": [
        { "nombre": "Wplay", "enlace": "https://www.wplay.co", "activo": true },
        { "nombre": "Rushbet", "enlace": "https://www.rushbet.co", "activo": true },
        { "nombre": "Stake Colombia", "enlace": "https://www.stake.com.co", "activo": true },
        { "nombre": "Betplay", "enlace": "https://www.betplay.com.co", "activo": true },
        { "nombre": "Luckia", "enlace": "https://www.luckia.co", "activo": true },
        { "nombre": "Betsson", "enlace": "https://www.betsson.com.co", "activo": true },
        { "nombre": "Yajuego", "enlace": "https://www.yajuego.com.co", "activo": true },
        { "nombre": "Rivalo", "enlace": "https://www.rivalo.co", "activo": true },
        { "nombre": "Bwin Colombia", "enlace": "https://www.bwin.com.co", "activo": true },
        { "nombre": "Zamba", "enlace": "https://www.zamba.co", "activo": true }
      ]
    },
    "Argentina": { "fuente": null, "casas": [] },
    "México": { "fuente": null, "casas": [] },
    "España": { "fuente": null, "casas": [] },
    "Estados Unidos": { "fuente": null, "casas": [] },
    "Otro país": { "fuente": null, "casas": [] }
  }
};
