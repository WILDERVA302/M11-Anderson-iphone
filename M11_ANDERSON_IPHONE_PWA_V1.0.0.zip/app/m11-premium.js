(function(){
  'use strict';
  const $=(s,r=document)=>r.querySelector(s);
  const txt=(id,f='—')=>$(id)?.textContent?.trim()||f;
  const pctNumber=s=>{const n=parseFloat(String(s).replace(/[^0-9,.-]/g,'').replace(',','.'));return Number.isFinite(n)?n:0};

  function build(){
    const home=$('#homeView'); if(!home || home.dataset.premiumBuilt) return;
    home.dataset.premiumBuilt='1'; document.body.classList.add('premium-m11');

    const header=document.createElement('section'); header.className='premium-header';
    header.innerHTML='<div><h1>Panel del Director M11</h1><p>Información inmediata para actuar, controlar y decidir.</p></div><div class="premium-live"><i></i> OPERACIÓN ACTIVA</div>';
    home.prepend(header);

    const kpis=document.createElement('section'); kpis.className='premium-kpis';
    kpis.innerHTML=`
      <article class="premium-kpi"><div class="kpi-icon">↗</div><div class="kpi-label">Rentabilidad actual</div><div id="pkRent" class="kpi-value">—</div><div class="kpi-sub">Sobre capital inicial · Meta 5,00 %</div><div class="kpi-track"><i id="pkRentBar"></i></div></article>
      <article class="premium-kpi"><div class="kpi-icon">▰</div><div class="kpi-label">Capital actual</div><div id="pkCapital" class="kpi-value">—</div><div class="kpi-sub">Disponible para operar</div></article>
      <article class="premium-kpi green"><div class="kpi-icon">✓</div><div class="kpi-label">Riesgo actual</div><div id="pkRiesgo" class="kpi-value">—</div><div id="pkRiesgoSub" class="kpi-sub">Estado auditable</div></article>`;
    header.after(kpis);

    const status=document.createElement('section'); status.className='premium-status-row';
    status.innerHTML=`
      <article class="premium-mini health"><div class="mini-icon">♥</div><div><span>Salud de la operación</span><strong id="pmSalud">—</strong></div></article>
      <article class="premium-mini eval"><div class="mini-icon">★</div><div><span>Evaluación M11</span><strong id="pmEval">En curso</strong></div></article>
      <article class="premium-mini state"><div class="mini-icon">✓</div><div><span>Estado de la operación</span><strong id="pmEstado">Activa</strong></div></article>`;
    kpis.after(status);

    const next=$('.next-match',home), decision=$('#decisionCenter');
    const stage=document.createElement('section'); stage.className='premium-decision-stage';
    status.after(stage); if(next) stage.appendChild(next); if(decision) stage.appendChild(decision);

    const lower=document.createElement('section'); lower.className='premium-lower-grid';
    stage.after(lower);
    const strategies=$('.strategies-grid',home), comment=$('#comentarioAsistenteCard');
    const strategyTitle=$('.section-title',home); if(strategyTitle) strategyTitle.remove();
    if(strategies) lower.appendChild(strategies); if(comment) lower.appendChild(comment);

    ['.capital-card','.rentabilidad-card','#objetivosRentabilidadCard','#riesgoSaludCard','#logrosCard'].forEach(s=>$(s,home)?.classList.add('legacy-dashboard-source'));
    sync();
    // Corrección técnica: observar solo las fuentes reales de datos, no
    // todo #homeView. El código original observaba el subárbol completo,
    // y como sync() escribe sus propios elementos (pkRent, pkCapital...)
    // DENTRO de ese mismo subárbol, cada escritura volvía a disparar el
    // observer sobre sí misma — un bucle infinito real (confirmado: colgaba
    // el proceso de prueba). Con el observer apuntando solo a las fuentes
    // (donde escribe ui.js, nunca donde escribe este archivo), sync() deja
    // de poder auto-dispararse.
    const fuentesReales = ['#rentPctCapital', '#capDisponible', '#riesgoSaludCard', '#statusTitle', '#evaluacionContenido', '#avisoEvaluacion'];
    fuentesReales.forEach(sel => {
      const el = $(sel, home);
      if (el) new MutationObserver(sync).observe(el, { subtree: true, childList: true, characterData: true, attributes: true });
    });
  }

  function sync(){
    if(!document.body.classList.contains('premium-m11')) return;
    const rent=txt('#rentPctCapital'); $('#pkRent') && ($('#pkRent').textContent=rent);
    const p=Math.max(0,Math.min(100,pctNumber(rent)/5*100)); $('#pkRentBar') && ($('#pkRentBar').style.width=p+'%');
    $('#pkCapital') && ($('#pkCapital').textContent=txt('#capDisponible'));

    const riskCard=$('#riesgoSaludCard');
    if(riskCard){
      const strong=[...riskCard.querySelectorAll('.salud-item strong')].map(e=>e.textContent.trim());
      const small=[...riskCard.querySelectorAll('.salud-item small')].map(e=>e.textContent.trim());
      $('#pmSalud') && ($('#pmSalud').textContent=strong[0]||'Estable');
      $('#pkRiesgo') && ($('#pkRiesgo').textContent=strong[1]||'Bajo');
      $('#pkRiesgoSub') && ($('#pkRiesgoSub').textContent=small[1]||'Nivel máximo actual');
    }
    const title=txt('#statusTitle','Operación activa'); $('#pmEstado') && ($('#pmEstado').textContent=title.replace('Todo está listo','Activa'));
    const evalText=$('#evaluacionContenido')?.textContent||$('#avisoEvaluacion')?.textContent||'';
    const match=evalText.match(/(\d+)\s+de\s+3/i); $('#pmEval') && ($('#pmEval').textContent=match?match[1]+' de 3 condiciones':'Bloque en curso');
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',build); else build();
})();
