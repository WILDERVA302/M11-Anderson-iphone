/* =========================================================
   M11 · operaciones-ui.js  (Sprint V1.0.5)
   -----------------------------------------------------------
   Pinta lo que M11.Operaciones (catálogo) y M11.Libro.resumenGeneral()
   (capital/niveles/ganancia de la operación activa) ya calcularon.
   No decide nada del Modelo M11 ni cambia ninguna operación por su
   cuenta — todo botón de aquí llama a una función de M11.Operaciones
   ya existente (ver events.js para el cableado).
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);
  const fmt = n => (n === null || n === undefined) ? '—' : '$' + Math.round(n).toLocaleString('es-CO');

  const ETIQUETA_ESTADO = { activa: 'Activa', pausada: 'Pausada', finalizada: 'Finalizada' };

  function renderActiva() {
    const box = $('#operacionActivaResumen');
    if (!box) return;
    const op = M11.Operaciones.getActiva();
    const btnPausar = $('#operacionPausarBtn');
    const btnFinalizar = $('#operacionFinalizarBtn');
    if (!op) {
      box.innerHTML = '<p class="legal-note">Todavía no hay ninguna operación activa. Cree una para empezar a registrar apuestas reales.</p>';
      if (btnPausar) btnPausar.disabled = true;
      if (btnFinalizar) btnFinalizar.disabled = true;
      return;
    }
    const r = M11.Libro ? M11.Libro.resumenGeneral() : {};
    box.innerHTML = `
      <div class="dist-row"><span>Nombre</span><span>${op.nombre}</span></div>
      <div class="dist-row"><span>Estado</span><span>${ETIQUETA_ESTADO[op.estado] || op.estado}</span></div>
      <div class="dist-row"><span>Fecha de inicio</span><span>${new Date(op.fechaInicio).toLocaleDateString('es-CO')}</span></div>
      <div class="dist-row"><span>Capital inicial asignado</span><span>${op.capitalInicial !== null ? fmt(op.capitalInicial) : 'No declarado'}</span></div>
      <div class="dist-row"><span>Capital disponible</span><span>${fmt(r.capitalDisponible)}</span></div>
      <div class="dist-row"><span>Capital comprometido</span><span>${fmt(r.capitalComprometido)}</span></div>
      <div class="dist-row"><span>Ganancia / pérdida</span><span>${fmt(r.gananciaAcumulada)}</span></div>
      <div class="dist-row"><span>Partidos jugados</span><span>${r.totalPartidos ?? '—'}</span></div>
      <div class="dist-row"><span>Niveles (Gral · Pares · Impares)</span><span>${r.nivelGeneral ?? '—'} · ${r.nivelPares ?? '—'} · ${r.nivelImpares ?? '—'}</span></div>
      <div class="dist-row"><span>Estrategias agotadas</span><span>${(r.estrategiasFinalizadas && r.estrategiasFinalizadas.length) ? r.estrategiasFinalizadas.join(', ') : 'Ninguna'}</span></div>`;
    if (btnPausar) btnPausar.disabled = op.estado !== 'activa';
    if (btnFinalizar) btnFinalizar.disabled = op.estado === 'finalizada';
  }

  function tarjetaOperacion(op, activaId) {
    const esActiva = op.id === activaId;
    const accion = esActiva
      ? '<span class="pill">En uso ahora</span>'
      : `<button type="button" class="secondary operacion-cambiar-btn" data-op-id="${op.id}">Cambiar a esta</button>`;
    // Sprint V1.0.5: solo la operación migrada desde antes de que existiera
    // este sistema (datos de pruebas guardados como si fueran una
    // operación real, ej. "Liga demostrativa") muestra este botón — nunca
    // aparece en ninguna operación real genuina.
    const botonReiniciar = op.migrada
      ? `<button type="button" class="danger operacion-reiniciar-migrada-btn" data-op-id="${op.id}" data-op-nombre="${op.nombre}">Reiniciar "${op.nombre}"</button>`
      : '';
    return `<article class="partido-card">
      <div class="partido-card-head"><strong>${op.nombre}</strong><span class="pill ${esActiva ? '' : 'gris'}">${ETIQUETA_ESTADO[op.estado]}</span></div>
      <div class="dist-row"><span>Inicio</span><span>${new Date(op.fechaInicio).toLocaleDateString('es-CO')}</span></div>
      <div class="dist-row"><span>Capital asignado</span><span>${op.capitalInicial !== null ? fmt(op.capitalInicial) : 'No declarado'}</span></div>
      ${op.migrada ? '<p class="legal-note">Contiene datos heredados de antes de esta versión (posiblemente de pruebas, no una operación real). Puede reiniciarla abajo.</p>' : ''}
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">${accion}${botonReiniciar}</div>
    </article>`;
  }

  function renderListas() {
    const boxActivas = $('#operacionesListaActivas');
    const boxFinalizadas = $('#operacionesListaFinalizadas');
    if (!boxActivas || !boxFinalizadas) return;
    const todas = M11.Operaciones.listar();
    const activaId = M11.Operaciones.getActivaId();
    const noFinalizadas = todas.filter(o => o.estado !== 'finalizada');
    const finalizadas = todas.filter(o => o.estado === 'finalizada');

    boxActivas.innerHTML = noFinalizadas.length
      ? noFinalizadas.map(op => tarjetaOperacion(op, activaId)).join('')
      : '<p class="legal-note">Ninguna operación creada todavía.</p>';

    boxFinalizadas.innerHTML = finalizadas.length
      ? finalizadas.map(op => `<article class="partido-card">
          <div class="partido-card-head"><strong>${op.nombre}</strong><span class="pill gris">Finalizada</span></div>
          <div class="dist-row"><span>Finalizó</span><span>${op.fechaFinalizacion ? new Date(op.fechaFinalizacion).toLocaleDateString('es-CO') : '—'}</span></div>
          <div style="margin-top:10px"><button type="button" class="secondary operacion-reabrir-btn" data-op-id="${op.id}">Reabrir</button></div>
        </article>`).join('')
      : '<p class="legal-note">Ninguna todavía.</p>';
  }

  function render() {
    if (!M11.Operaciones) return;
    renderActiva();
    renderListas();
  }

  M11.OperacionesUI = { render };

})(window.M11);
