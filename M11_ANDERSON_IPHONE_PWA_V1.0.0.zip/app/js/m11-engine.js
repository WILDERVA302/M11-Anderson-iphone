/* =========================================================
   M11 · m11-engine.js
   -----------------------------------------------------------
   Motor de reglas del Modelo M11. Módulo aislado de la interfaz
   (pedido explícito del Director) para poder auditarlo y ampliarlo
   por separado. No toca el DOM ni depende de otros módulos de la
   app; es pura función de datos.

   Reglas implementadas (las que el Director proporcionó por
   escrito). El resto de las once reglas del Modelo M11 se
   incorporará cuando se entregue el manuscrito o la especificación
   completa — hasta entonces, este motor cubre exactamente lo
   siguiente y nada más se inventa:

   - Tres estrategias independientes: general, pares, impares. Cada
     una lleva su propia secuencia y su propio nivel (1 a 11).
   - Monto del nivel n = BASE × 2^(n-1) (BASE es configurable, ver
     ENGINE_CONFIG.BASE más abajo; con BASE=1000 el nivel 11 es
     $1.024.000).
   - Presupuesto completo de una estrategia = BASE × (2^11 - 1) =
     BASE × 2047 (con BASE=1000: $2.047.000; para las tres
     estrategias, $6.141.000).
   - Pares participa en partidos de número cronológico PAR; Impares
     en partidos de número cronológico IMPAR; General participa
     siempre. Esto se decide con el número cronológico del partido
     (ver calendar.js), nunca de forma arbitraria.
   - Resultado del partido:
       · Empate → la(s) estrategia(s) que participaron GANAN:
         retorno = monto apostado × cuota; ganancia neta = retorno −
         monto apostado. El nivel de esa estrategia vuelve a 1.
       · No empate → PIERDEN el monto apostado (no se resta como
         "ganancia negativa inventada": simplemente ese monto sale
         de disponible y no vuelve). El nivel sube uno, con tope en
         11 — nunca se crea un nivel 12. En el nivel 11 se debe
         mostrar una advertencia de máximo riesgo (lo resuelve la
         interfaz, no este motor).
       · Cancelado o suspendido → sin cambios en capital ni nivel:
         se libera lo comprometido como si la operación no hubiera
         ocurrido.
   - Una estrategia que NO participa en el partido: sin cambios.
   - Partido marcado "No apostada": sin cambios en ninguna
     estrategia (no se llama a comprometer/resolver para ninguna).

   Terminología contable que exige la interfaz (no debe mezclarse):
   capital inicial, capital disponible, capital comprometido, monto
   apostado, retorno recibido, ganancia o pérdida neta, saldo después
   de la operación. Este motor produce todos esos campos por
   separado; nunca sustituye la cuota completa por "ganancia".
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const NIVELES = 11;

  // Variable configurable del motor, tal como pidió el Director.
  // BASE es el monto apostado en el nivel 1.
  const ENGINE_CONFIG = {
    BASE: 1000
  };

  function montoPorNivel(nivel) {
    return ENGINE_CONFIG.BASE * Math.pow(2, nivel - 1);
  }

  // Suma de una progresión geométrica de razón 2 con 11 términos:
  // BASE × (2^11 - 1) = BASE × 2047.
  function presupuestoCompleto() {
    let total = 0;
    for (let n = 1; n <= NIVELES; n++) total += montoPorNivel(n);
    return total;
  }

  // Pares/Impares dependen de la posición cronológica del partido
  // dentro del torneo (número cronológico del calendario). General
  // participa siempre.
  function estrategiasParticipantes(numeroCronologico) {
    const activas = ['general'];
    if (typeof numeroCronologico === 'number' && !Number.isNaN(numeroCronologico)) {
      activas.push(numeroCronologico % 2 === 0 ? 'pares' : 'impares');
    }
    return activas;
  }

  function nuevoEstadoEstrategia() {
    return { nivel: 1, disponible: presupuestoCompleto(), comprometido: 0, bloqueada: false };
  }

  // "Iniciar una nueva secuencia" tras un cierre en nivel 11: misma
  // forma que nuevoEstadoEstrategia, nombrada aparte para que quede
  // claro en el código que es una decisión explícita del operador
  // sobre UNA estrategia bloqueada, no un reinicio general.
  function reiniciarSecuencia() {
    return nuevoEstadoEstrategia();
  }

  // Compromete un monto para una estrategia que participa y fue
  // apostada (pasa de "disponible" a "comprometido"). Si no se
  // indica un monto explícito (lo que el usuario confirmó
  // realmente), usa el monto recomendado por el nivel actual.
  function comprometer(estrategia, monto) {
    const m = (typeof monto === 'number' && !Number.isNaN(monto) && monto >= 0)
      ? monto
      : montoPorNivel(estrategia.nivel);
    return {
      nivel: estrategia.nivel,
      disponible: estrategia.disponible - m,
      comprometido: estrategia.comprometido + m,
      bloqueada: !!estrategia.bloqueada
    };
  }

  // Resuelve el resultado para UNA estrategia que participó y tenía
  // un monto comprometido. `cuota` solo se usa si gano === true.
  // Devuelve el nuevo estado de la estrategia y el detalle contable
  // completo (para auditoría), sin mezclar cuota con ganancia.
  //
  // Regla de cierre obligatorio: si la estrategia YA estaba en el
  // nivel máximo (11) y pierde, la secuencia se cierra ahí mismo.
  // Nunca se crea un nivel 12, nunca se vuelve a comprometer capital
  // para esa estrategia (se marca "bloqueada"), y por lo tanto nunca
  // puede quedar en negativo: no hay una apuesta siguiente que reste
  // más de lo que hay disponible.
  function resolver(estrategia, gano, cuota) {
    const monto = estrategia.comprometido;
    if (gano) {
      const retorno = monto * cuota;
      const gananciaNeta = retorno - monto;
      const disponibleFinal = estrategia.disponible + retorno;
      return {
        estado: { nivel: 1, disponible: disponibleFinal, comprometido: 0, bloqueada: false },
        detalle: {
          resultado: 'gano',
          montoApostado: monto,
          cuota,
          retorno,
          gananciaNeta,
          saldoDespues: disponibleFinal,
          nivelAnterior: estrategia.nivel,
          nivelNuevo: 1,
          secuenciaFinalizada: false
        }
      };
    }
    const eraNivelMaximo = estrategia.nivel === NIVELES;
    const nivelNuevo = Math.min(estrategia.nivel + 1, NIVELES);
    return {
      estado: { nivel: nivelNuevo, disponible: estrategia.disponible, comprometido: 0, bloqueada: eraNivelMaximo },
      detalle: {
        resultado: 'perdio',
        montoApostado: monto,
        cuota: null,
        retorno: 0,
        gananciaNeta: -monto,
        saldoDespues: estrategia.disponible,
        nivelAnterior: estrategia.nivel,
        nivelNuevo,
        secuenciaFinalizada: eraNivelMaximo
      }
    };
  }

  // Partido cancelado/suspendido: se libera lo comprometido sin
  // pérdida, sin retorno y sin cambio de nivel.
  function liberarSinCambios(estrategia) {
    const disponibleFinal = estrategia.disponible + estrategia.comprometido;
    return {
      estado: { nivel: estrategia.nivel, disponible: disponibleFinal, comprometido: 0, bloqueada: !!estrategia.bloqueada },
      detalle: {
        resultado: 'cancelado',
        montoApostado: estrategia.comprometido,
        cuota: null,
        retorno: estrategia.comprometido,
        gananciaNeta: 0,
        saldoDespues: disponibleFinal,
        nivelAnterior: estrategia.nivel,
        nivelNuevo: estrategia.nivel,
        secuenciaFinalizada: false
      }
    };
  }

  M11.Engine = {
    NIVELES,
    CONFIG: ENGINE_CONFIG,
    montoPorNivel,
    presupuestoCompleto,
    estrategiasParticipantes,
    nuevoEstadoEstrategia,
    reiniciarSecuencia,
    comprometer,
    resolver,
    liberarSinCambios
  };

})(window.M11);
