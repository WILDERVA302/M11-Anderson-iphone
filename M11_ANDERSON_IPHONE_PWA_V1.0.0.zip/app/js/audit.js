/* =========================================================
   M11 · audit.js
   -----------------------------------------------------------
   Historial de auditoría local. Registra tres tipos de evento:
   - "Registrada": se confirmó una apuesta (Sí), con el detalle por
     estrategia (monto y cuota que el usuario confirmó realmente).
   - "No apostada": el usuario indicó que no operó. Sin monto, sin
     cuota, sin efecto en capital ni niveles.
   - "Resultado: <Empate|No empate|Cancelado|Suspendido>": se cerró
     el ciclo del partido. Incluye, por estrategia, monto apostado,
     cuota, retorno recibido, ganancia/pérdida neta y el cambio de
     nivel — nunca se confunde la cuota con la ganancia.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_KEY = 'm11History';

  function load() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); }
    catch (e) { return []; }
  }

  let historial = load();

  function persist() {
    localStorage.setItem(LS_KEY, JSON.stringify(historial));
  }

  const RESULTADO_LABEL = {
    empate: 'Resultado: Empate',
    no_empate: 'Resultado: No empate',
    cancelado: 'Resultado: Cancelado',
    suspendido: 'Resultado: Suspendido'
  };

  M11.Audit = {
    listar() { return historial; },

    // operacion: el objeto completo guardado por confirmarApostada
    // (id, partidoId, montoRecomendado, montoApostado, cuota,
    // casaApuestas, estrategias, estado, fechaRegistroApuesta, resultado)
    registrarApuesta({ match, operacion }) {
      historial.unshift({
        tipo: 'apuesta',
        match,
        date: new Date().toLocaleString('es-CO'),
        operacion,
        status: 'Registrada'
      });
      persist();
    },

    registrarNoApostada({ match, strategies }) {
      historial.unshift({
        tipo: 'no_apostada',
        match,
        date: new Date().toLocaleString('es-CO'),
        strategies: strategies || [],
        status: 'No apostada'
      });
      persist();
    },

    // detallePorEstrategia: { general: {montoApostado,cuota,retorno,gananciaNeta,nivelAnterior,nivelNuevo}, ... }
    registrarResultado({ match, resultado, detallePorEstrategia, huboApuestaVálida }) {
      historial.unshift({
        tipo: 'resultado',
        match,
        date: new Date().toLocaleString('es-CO'),
        resultado,
        huboApuestaVálida: !!huboApuestaVálida,
        detalle: detallePorEstrategia || {},
        status: RESULTADO_LABEL[resultado] || ('Resultado: ' + resultado)
      });
      persist();
    },

    limpiar() {
      historial = [];
      persist();
    },

    // decision: 'finalizar' | 'nueva_secuencia'
    registrarDecisionSecuencia({ estrategia, decision }) {
      historial.unshift({
        tipo: 'secuencia',
        match: null,
        date: new Date().toLocaleString('es-CO'),
        estrategia,
        decisionSecuencia: decision,
        status: decision === 'nueva_secuencia'
          ? `Secuencia de ${estrategia}: nueva secuencia iniciada`
          : `Secuencia de ${estrategia}: finalizada (queda cerrada)`
      });
      persist();
    }
  };

})(window.M11);
