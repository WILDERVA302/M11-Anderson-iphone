/* M11 Laboratorio — tablero de 11 campeonatos y catálogo internacional. */
window.M11 = window.M11 || {};
(function (M11) {
  'use strict';
  const KEY='m11_lab_championships_v1';
  const MODE_KEY='m11_lab_mode_v1';
  const MAX=11;
  const WOMEN=['women','woman','femen','wsl','nwsl','damallsvenskan','toppserien','liga f'];
  const YOUTH=['youth','juven','reserve','reserva',' u23',' u21',' u20',' u19',' u18',' u17','sub-'];
  const PRESETS=[
    {name:'Colombian Liga DIMAYOR',country:'Colombia',leagueId:'4497',icon:'🇨🇴'},
    {name:'Premier League',country:'England',leagueId:'4328',icon:'🏴'},
    {name:'LaLiga España',country:'Spain',leagueId:'4335',icon:'🇪🇸'},
    {name:'Serie A Italia',country:'Italy',leagueId:'4332',icon:'🇮🇹'},
    {name:'Bundesliga',country:'Germany',leagueId:'4331',icon:'🇩🇪'},
    {name:'Ligue 1',country:'France',leagueId:'4334',icon:'🇫🇷'},
    {name:'Uruguayan Primera División',country:'Uruguay',leagueId:'4432',icon:'🇺🇾'},
    {name:'Canadian Premier League',country:'Canada',leagueId:'4820',icon:'🇨🇦'},
    {name:'MLS Estados Unidos',country:'USA',leagueId:'4346',icon:'🇺🇸'},
    {name:'Mexican Liga MX',country:'Mexico',leagueId:'4350',icon:'🇲🇽'},
    {name:'Ecuadorian Serie B · Ascenso',country:'Ecuador',leagueId:'4957',icon:'🇪🇨'}
  ];
  let selectedSlot=0;
  let mode='real';
  localStorage.setItem(MODE_KEY,'real');

  function load(){
    try{const value=JSON.parse(localStorage.getItem(KEY));if(Array.isArray(value)&&value.length===MAX){
      // 4415 pertenece a rugby: corrige únicamente el preset defectuoso de V2.0.1.
      if(String(value[0]&&value[0].leagueId)==='4415')value[0]=Object.assign({slot:1},PRESETS[0]);
      // V2.1.4: corrige únicamente los antiguos valores de fábrica. Una
      // liga elegida por el usuario nunca se reemplaza por su posición.
      const legacy={
        '4480':PRESETS[6], '4501':PRESETS[7]
      };
      value.forEach((slot,index)=>{
        const replacement=legacy[String(slot&&slot.leagueId||'')];
        if(replacement)value[index]=Object.assign({slot:index+1},replacement);
        if(slot&&slot.needsSelection&&['Noruega','Fútbol femenino'].includes(slot.name))value[index]=Object.assign({slot:index+1},PRESETS[index]);
        if(String(slot&&slot.leagueId||'')==='4957')value[index]=Object.assign({},slot,{name:'Ecuadorian Serie B · Ascenso'});
      });
      localStorage.setItem(KEY,JSON.stringify(value));return value;
    }}catch(_){}
    // Edición Anderson: los once espacios nacen realmente vacíos. Ninguna
    // liga, operación, capital ni historial se decide de fábrica; Anderson
    // configura cada campeonato desde su propio teléfono.
    const seeded=Array.from({length:MAX},(_,index)=>({
      slot:index+1,name:'Campeonato por elegir',country:'',leagueId:'',icon:'+',needsSelection:true
    }));
    localStorage.setItem(KEY,JSON.stringify(seeded));return seeded;
  }
  function save(slots){localStorage.setItem(KEY,JSON.stringify(slots));return slots;}
  function escapeHtml(v){return String(v||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function initials(name){return String(name||'?').split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase();}
  function classify(league){const n=(' '+[league.name,league.alternateName,league.gender].join(' ')).toLowerCase();if(WOMEN.some(x=>n.includes(x)))return'women';if(YOUTH.some(x=>n.includes(x)))return'youth';return'men';}
  function fictitiousFor(slot){if(!M11.ShadowStore)return null;return M11.ShadowStore.load().tournaments.find(t=>String(t.leagueId||'')===String(slot.leagueId||'')||t.labSlot===slot.slot)||null;}
  function realFor(slot){if(!M11.Operaciones)return null;return M11.Operaciones.listar().find(o=>String(o.leagueId||'')===String(slot.leagueId||'')||o.labSlot===slot.slot)||null;}
  function stateFor(slot){
    if(slot.needsSelection||!slot.leagueId)return{label:'Por elegir',kind:'empty'};
    const item=mode==='fictitious'?fictitiousFor(slot):realFor(slot);
    if(!item)return{label:mode==='fictitious'?'Sin iniciar':'No iniciada',kind:'idle'};
    if(mode==='fictitious'){
      const closed=Object.values(item.strategies||{}).filter(s=>s.closed).length;
      return{label:closed===3?'Agotada':closed?`${closed} agotada${closed>1?'s':''}`:'En seguimiento',kind:closed===3?'exhausted':'active',item};
    }
    const decision=M11.Store&&M11.Store.getDecisionDeOperacion?M11.Store.getDecisionDeOperacion(item.id):null;
    const confirmacion=M11.Store&&M11.Store.getPartidoEnConfirmacion?M11.Store.getPartidoEnConfirmacion(item.id):null;
    if(decision&&decision.estado==='PENDIENTE_RESULTADO')return{label:'APUESTA REGISTRADA',kind:'bet',item};
    if(confirmacion)return{label:'CONFIRMAR APUESTA',kind:'confirm',item};
    return{label:item.estado==='activa'?'Activa':item.estado==='finalizada'?'Finalizada':'En pausa',kind:item.estado==='activa'?'active':'idle',item};
  }
  function levels(item){
    if(!item)return'—';
    if(mode==='fictitious')return['general','pares','impares'].map(k=>(item.strategies[k]&&item.strategies[k].level)||1).join(' · ');
    if(item.id===M11.Operaciones.getActivaId()&&M11.Store)return Object.values(M11.Store.getEstrategias()).map(s=>s.nivel).join(' · ');
    return'Historial propio';
  }
  function icon(slot){return slot.badge?`<img src="${escapeHtml(slot.badge)}" alt="">`:escapeHtml(slot.icon||initials(slot.name));}
  function render(){
    const grid=document.querySelector('#labChampionshipGrid');if(!grid)return;
    const slots=load();
    document.querySelector('#labHubTitle').textContent=mode==='real'?'Operación real':'Operación ficticia';
    document.querySelector('#labHubSubtitle').textContent=mode==='real'?'Elija el campeonato donde desea operar. Cada campeonato guarda su propio capital, niveles e historial.':'Observe qué habría ocurrido al aplicar M11. El seguimiento continúa aunque una estrategia se agote.';
    const badge=document.querySelector('#labModeBadge');badge.textContent=mode==='real'?'REAL':'FICTICIA';badge.className='lab-mode-badge '+mode;
    document.querySelector('#labExplanationTitle').textContent=mode==='real'?'Operación real: usted decide cuándo empezar':'Operación ficticia: laboratorio automático';
    document.querySelector('#labExplanationText').textContent=mode==='real'?'Solo comienza cuando usted entra al campeonato y confirma su primera operación.':'Mide la rentabilidad del capital supuesto. Una estrategia agotada queda cerrada, pero las restantes y el registro del campeonato continúan.';
    let configured=0,active=0,exhausted=0;
    grid.innerHTML=slots.map(slot=>{
      const st=stateFor(slot);if(st.kind!=='empty')configured++;if(st.kind==='active')active++;if(st.kind==='exhausted')exhausted++;
      const empty=st.kind==='empty';
      return `<article class="lab-champ-card ${empty?'is-empty':''} ${st.kind==='active'?'is-active':''} ${st.kind==='exhausted'?'is-exhausted':''} ${st.kind==='bet'?'is-bet':''} ${st.kind==='confirm'?'is-confirm':''}" data-slot="${slot.slot}">
        <span class="lab-slot-number">${slot.slot}/11</span><div class="lab-champ-icon">${empty?'<span class="lab-empty-plus">+</span>':icon(slot)}</div>
        <h3>${escapeHtml(slot.name)}</h3><p>${escapeHtml(slot.country)}${slot.category==='women'?' · Femenino':''}</p>
        <div class="lab-champ-meta"><span class="lab-mini-pill ${st.kind==='active'?'on':st.kind==='bet'?'bet':st.kind==='confirm'?'confirm':st.kind==='exhausted'?'':'purple'}">${escapeHtml(st.label)}</span>${st.item?`<span class="lab-mini-pill">Niveles ${escapeHtml(levels(st.item))}</span>`:''}</div>
        <button type="button" class="lab-card-open ${mode}" data-lab-open="${slot.slot}">${empty?'CONFIGURAR':st.item?'ABRIR CAMPEONATO':mode==='real'?'INICIAR REAL':'INICIAR SEGUIMIENTO'}</button>
      </article>`;
    }).join('')+(mode==='fictitious'?`<article class="lab-champ-card lab-report-card" data-lab-report-card>
      <span class="lab-slot-number">12</span><div class="lab-champ-icon">📊</div>
      <h3>Informe general</h3><p>Los 11 campeonatos</p>
      <div class="lab-champ-meta"><span class="lab-mini-pill purple">Consolidado</span></div>
      <button type="button" class="lab-card-open fictitious" data-lab-report>ABRIR INFORME</button>
    </article>`:'');
    document.querySelector('#labSummary').innerHTML=`<div><span>Configurados</span><strong>${configured}/11</strong></div><div><span>${mode==='real'?'Operaciones':'Seguimientos'}</span><strong>${active}</strong></div><div><span>Agotados</span><strong>${exhausted}</strong></div>`;
  }
  function operationBase(){
    const initial=M11.Store&&M11.Store.getConfiguracionInicial?M11.Store.getConfiguracionInicial():null;
    const configured=Number(initial&&initial.base);
    return Number.isFinite(configured)&&configured>0?configured:1000;
  }
  function showView(id,navMode){
    document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===id));
    const shell=document.querySelector('.app-shell');if(shell)shell.dataset.activeView=id;
    document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
    const active=document.querySelector(navMode?`.nav-btn[data-lab-mode="${navMode}"]`:`.nav-btn[data-view="${id}"]`);if(active)active.classList.add('active');
    window.scrollTo(0,0);
  }
  async function ensureReal(slot){
    let op=realFor(slot);
    if(!op){
      const base=operationBase();
      op=M11.Operaciones.crear({nombre:slot.name,base,capitalInicial:base*2047*3,leagueId:slot.leagueId,country:slot.country,leagueName:slot.name,badge:slot.badge||'',activarInmediatamente:true});
      const all=JSON.parse(localStorage.getItem('m11_operaciones_v1')||'{}');if(all[op.id]){all[op.id].labSlot=slot.slot;localStorage.setItem('m11_operaciones_v1',JSON.stringify(all));}
    }else M11.Operaciones.activar(op.id);
    showView('homeView','real');
    const estado=document.querySelector('#realResultStatus');
    if(estado)estado.textContent='Actualizando este campeonato y buscando el resultado pendiente…';
    if(slot.leagueId&&M11.LeagueService){await M11.LeagueService.guardarLigaYSincronizar({country:slot.country,leagueId:slot.leagueId,leagueName:slot.name,season:slot.season||'',displayName:slot.name}).catch(()=>{});}
    // La conciliación del arranque solo conoce el campeonato que estaba
    // activo entonces. Al abrir otro, se ejecuta de nuevo ya activado.
    if(M11.RealSync){
      try{
        const out=await M11.RealSync.syncNow(true);
        const pendiente=M11.Store&&M11.Store.getDecision?M11.Store.getDecision():null;
        if(estado)estado.textContent=out&&out.settled?'Resultado encontrado. La apuesta fue cerrada y la operación quedó actualizada.':pendiente&&pendiente.estado==='PENDIENTE_RESULTADO'?'La fuente todavía no publicó un resultado final verificable. Puede volver a actualizar o ingresarlo manualmente.':'Campeonato actualizado.';
      }catch(_){if(estado)estado.textContent='No fue posible consultar la fuente ahora. La apuesta sigue protegida; puede reintentar o ingresar el resultado manualmente.';}
    }
    if(M11.UI)M11.UI.render();if(M11.LabHub)M11.LabHub.render();
  }
  function ensureFictitious(slot){
    let tournament=fictitiousFor(slot);
    if(!tournament){
      try{tournament=M11.ShadowStore.addTournament({id:'lab-'+slot.slot+'-'+slot.leagueId,name:slot.name,leagueId:slot.leagueId,country:slot.country,season:slot.season||'',base:operationBase(),experimentalQuota:3.6,targetPercent:999999});tournament.labSlot=slot.slot;M11.ShadowStore.save(M11.ShadowStore.load());}
      catch(err){alert(err.message);return;}
    }else if((tournament.history||[]).length===0&&!(tournament.processedEventIds||[]).length&&Number(tournament.base)!==operationBase()){
      // Una ficha aún sin resultados puede adoptar la base elegida en bienvenida sin alterar historia alguna.
      const fresh=M11.ShadowEngine.createTournament({id:tournament.id,name:tournament.name,leagueId:tournament.leagueId,country:tournament.country,season:tournament.season||'',base:operationBase(),experimentalQuota:tournament.experimentalQuota||3.6,targetPercent:tournament.targetPercent||999999,createdAt:tournament.createdAt});
      Object.assign(tournament,fresh,{labSlot:slot.slot});M11.ShadowStore.save(M11.ShadowStore.load());
    }
    if(M11.ShadowUI)M11.ShadowUI.showTournament(tournament.id);showView('shadowView','fictitious');
  }
  function showReport(){if(M11.ShadowUI)M11.ShadowUI.showReport();showView('shadowView','fictitious');}
  function openSlot(number){const slot=load()[Number(number)-1];if(!slot)return;if(slot.needsSelection||!slot.leagueId){selectedSlot=slot.slot-1;showView('settingsView');renderSlotPicker();document.querySelector('#labCatalogMessage').textContent=`Configure el espacio ${slot.slot}: ${slot.name}.`;return;}if(mode==='real')ensureReal(slot);else ensureFictitious(slot);}
  function renderSlotPicker(){const box=document.querySelector('#labSlotPicker');if(!box)return;box.innerHTML=load().map((s,i)=>`<button type="button" class="lab-slot-btn ${i===selectedSlot?'active':''}" data-lab-slot-pick="${i}">${i+1}</button>`).join('');}
  function selectedCountry(){const value=document.querySelector('#labCountrySelect').value;return value==='__other__'?document.querySelector('#labOtherCountry').value.trim():value;}
  async function search(){
    const country=selectedCountry(),msg=document.querySelector('#labCatalogMessage'),box=document.querySelector('#labLeagueResults');if(!country){msg.textContent='Escriba un país.';return;}
    msg.textContent='Consultando campeonatos disponibles…';box.innerHTML='';
    try{
      let leagues=country==='__international__'?await M11.LeagueService.buscarInternacionales():await M11.LeagueService.buscarLigas(country);const category=document.querySelector('#labCategorySelect').value;if(category!=='all')leagues=leagues.filter(l=>classify(l)===category);
      msg.textContent=leagues.length?`${leagues.length} campeonato(s) encontrado(s). Elija uno para el espacio ${selectedSlot+1}.`:'No se encontraron campeonatos con esos filtros.';
      box.innerHTML=leagues.map(l=>`<article class="lab-league-result">${l.badge?`<img src="${escapeHtml(l.badge)}" alt="">`:'<span class="lab-result-placeholder">⚽</span>'}<div><strong>${escapeHtml(l.name)}</strong><small>${escapeHtml(l.country||country)} · ${classify(l)==='women'?'Femenino':classify(l)==='youth'?'Juvenil/reserva':'Masculino'}</small></div><button type="button" data-lab-select-league="${escapeHtml(l.id)}">ELEGIR</button></article>`).join('');box.dataset.leagues=JSON.stringify(leagues);
    }catch(err){msg.textContent='No fue posible consultar la fuente ahora. Revise la conexión e inténtelo nuevamente.';}
  }
  function chooseLeague(id){const box=document.querySelector('#labLeagueResults'),leagues=JSON.parse(box.dataset.leagues||'[]'),league=leagues.find(l=>String(l.id)===String(id));if(!league)return;const slots=load();const duplicate=slots.find((s,i)=>i!==selectedSlot&&String(s.leagueId||'')===String(id));if(duplicate){document.querySelector('#labCatalogMessage').textContent=`${league.name} ya está configurado en el espacio ${duplicate.slot}. Elija otro campeonato.`;return;}slots[selectedSlot]=Object.assign({slot:selectedSlot+1,icon:'⚽'},slots[selectedSlot],{name:league.name,country:league.country||selectedCountry(),leagueId:String(league.id),badge:league.badge||'',category:classify(league),needsSelection:false});save(slots);document.querySelector('#labCatalogMessage').textContent=`Espacio ${selectedSlot+1} guardado: ${league.name}.`;renderSlotPicker();render();}
  function setMode(){mode='real';localStorage.setItem(MODE_KEY,mode);render();}
  function init(){
    render();renderSlotPicker();
    document.addEventListener('click',e=>{
      const modeBtn=e.target.closest('[data-lab-mode]');if(modeBtn){setMode(modeBtn.dataset.labMode);}
      const open=e.target.closest('[data-lab-open]');if(open){e.preventDefault();openSlot(open.dataset.labOpen);}
      const report=e.target.closest('[data-lab-report]');if(report){e.preventDefault();showReport();}
      const back=e.target.closest('[data-lab-back]');if(back){setMode(back.dataset.labBack==='fictitious'?'fictitious':'real');showView('labHubView',mode);}
      const pick=e.target.closest('[data-lab-slot-pick]');if(pick){selectedSlot=Number(pick.dataset.labSlotPick);renderSlotPicker();}
      const choose=e.target.closest('[data-lab-select-league]');if(choose)chooseLeague(choose.dataset.labSelectLeague);
    });
    const country=document.querySelector('#labCountrySelect');if(country)country.addEventListener('change',()=>document.querySelector('#labOtherCountryWrap').classList.toggle('hidden',country.value!=='__other__'));
    const searchBtn=document.querySelector('#labSearchLeagues');if(searchBtn)searchBtn.addEventListener('click',search);
  }
  M11.LabHub={init,render,load,save,setMode,classify,MAX};
})(window.M11);
