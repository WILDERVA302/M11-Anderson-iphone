/* Avisos locales M11: 15 y 5 minutos antes, incluso con la APK cerrada. */
window.M11=window.M11||{};
(function(M11){
  'use strict';
  const KEY='m11_notifications_v2',CHANNEL='m11-alarma-v3',SOUND='m11_alarm.wav',ACTION='M11_ALARM_ACTIONS';
  const defaults={enabled:true,at15:true,at5:true,vibration:true};
  let lastFingerprint='', syncTimer=null;
  function prefs(){try{return Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch(_){return {...defaults};}}
  function save(next){localStorage.setItem(KEY,JSON.stringify(Object.assign({},prefs(),next)));return prefs();}
  function plugin(){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.LocalNotifications;}
  function hash(value){let h=0;for(const c of String(value))h=((h<<5)-h+c.charCodeAt(0))|0;return Math.abs(h)%900000+10000;}
  async function permission(request){const p=plugin();if(!p)return typeof Notification!=='undefined'&&Notification.permission==='granted'?'granted':'browser';let status=await p.checkPermissions();if(request&&status.display!=='granted')status=await p.requestPermissions();return status.display;}
  function plans(){
    const result=[];
    if(M11.getPartidoActual){const p=M11.getPartidoActual();const decision=M11.Store&&M11.Store.getDecision?M11.Store.getDecision():null;if(p){const raw=p.timestampUTC||p.fecha&&`${p.fecha}T${p.hora||'00:00'}:00`;const at=raw?new Date(raw).getTime():NaN;if(Number.isFinite(at))result.push({key:`real-${p.id}`,title:'⏰ Es hora de revisar su acción M11',body:`${p.equipoLocal||p.local||'Local'} vs ${p.equipoVisitante||p.visitante||'Visitante'} comienza pronto${decision&&decision.estado==='PENDIENTE_RESULTADO'?' y su apuesta ya está registrada':''}.`,at,view:'homeView'});}}
    return result;
  }
  async function sync(){
    const p=plugin(),cfg=prefs();
    if(!p)return {permission:'unavailable',scheduled:0,plans:plans()};
    // Al apagar el interruptor maestro también se retiran las alarmas que
    // Android ya tenía programadas; antes quedaban activas aunque la pantalla
    // dijera que estaban deshabilitadas.
    if(!cfg.enabled){
      try{const pending=await p.getPending();const ids=(pending.notifications||[]).filter(n=>String(n.extra&&n.extra.m11||'').startsWith('m11-')).map(n=>n.id);if(ids.length)await p.cancel({notifications:ids.map(id=>({id}))});}catch(_){}
      return {permission:'disabled',scheduled:0,plans:plans()};
    }
    const permissionState=await permission(false);if(permissionState!=='granted')return {permission:permissionState,scheduled:0,plans:plans()};
    try{await p.createChannel({id:CHANNEL,name:'Alarma fuerte M11',description:'Alarma diferenciada para oportunidades M11',sound:SOUND,importance:5,visibility:1,vibration:cfg.vibration,lights:true,lightColor:'#ffb300'});}catch(_){}
    try{await p.registerActionTypes({types:[{id:ACTION,actions:[{id:'STOP',title:'DETENER ALARMA'}]}]});}catch(_){}
    const pending=await p.getPending();const ids=(pending.notifications||[]).filter(n=>String(n.extra&&n.extra.m11||'').startsWith('m11-')).map(n=>n.id);if(ids.length)await p.cancel({notifications:ids.map(id=>({id}))});
    const notifications=[],now=Date.now();
    plans().forEach(plan=>{[[15,cfg.at15],[5,cfg.at5]].forEach(([minutes,on])=>{const scheduleAt=plan.at-minutes*60000;if(on&&scheduleAt>now)notifications.push({id:hash(`${plan.key}-${minutes}`),title:'⏰ ALARMA M11: hora de actuar',body:`${plan.body} Faltan ${minutes} minutos.`,schedule:{at:new Date(scheduleAt),allowWhileIdle:true},sound:SOUND,channelId:CHANNEL,actionTypeId:ACTION,ongoing:true,autoCancel:false,foreground:true,extra:{m11:`m11-${plan.key}`,view:plan.view}});});});
    if(notifications.length)await p.schedule({notifications});
    return {permission:'granted',scheduled:notifications.length,plans:plans()};
  }
  async function enableFromUser(){const state=await permission(true);save({enabled:state==='granted'||state==='browser'});await sync();return state;}
  function syncIfChanged(){
    const fingerprint=JSON.stringify({prefs:prefs(),plans:plans().map(p=>[p.key,p.at])});
    if(fingerprint===lastFingerprint)return;
    lastFingerprint=fingerprint;
    clearTimeout(syncTimer);
    syncTimer=setTimeout(()=>sync().catch(()=>{}),250);
  }
  async function test(){const p=plugin();if(p){const state=await permission(true);if(state!=='granted')throw new Error('Android no autorizó las notificaciones.');try{await p.createChannel({id:CHANNEL,name:'Alarma fuerte M11',description:'Alarma diferenciada para oportunidades M11',sound:SOUND,importance:5,visibility:1,vibration:true,lights:true,lightColor:'#ffb300'});}catch(_){}await p.schedule({notifications:[{id:hash(`test-${Date.now()}`),title:'⏰ ALARMA M11 DE PRUEBA',body:'Este es el sonido especial para la hora de apostar.',schedule:{at:new Date(Date.now()+1500),allowWhileIdle:true},sound:SOUND,channelId:CHANNEL,actionTypeId:ACTION,ongoing:true,autoCancel:false,foreground:true,extra:{m11:'m11-test',view:'homeView'}}]});return;}try{const a=new Audio('assets/audio/m11_alarm.wav');a.volume=1;await a.play();}catch(_){if(M11.Sonidos)M11.Sonidos.probar();}if(typeof Notification!=='undefined'){if(Notification.permission==='default')await Notification.requestPermission();if(Notification.permission==='granted')new Notification('Alarma M11 activada',{body:'Los avisos de partidos están funcionando.'});}}
  function init(){const p=plugin();if(p)p.addListener('localNotificationActionPerformed',async event=>{if(event.actionId==='STOP'){try{await p.removeDeliveredNotifications({notifications:[event.notification]});}catch(_){}return;}const view=event.notification&&event.notification.extra&&event.notification.extra.view;const button=document.querySelector(`.nav-btn[data-view="${view||'homeView'}"]`);if(button)button.click();});sync().catch(()=>{});}
  M11.Notifications={prefs,save,permission,sync,syncIfChanged,enableFromUser,test,init,plans};
})(window.M11);
