/* =========================================================
   M11 · pdf-share.js  (Sprint V1.0.5, sección 10 — PRIORITARIA)
   -----------------------------------------------------------
   En Android no se puede depender de window.print() (no hay diálogo
   de impresión del sistema dentro del WebView de Capacitor). Este
   módulo genera un PDF real con jsPDF (vendido localmente en
   js/vendor/jspdf.umd.min.js, funciona sin conexión) y lo guarda o
   comparte usando @capacitor/filesystem y @capacitor/share cuando
   están disponibles; fuera de Android, ofrece la descarga normal del
   PDF (el navegador ya sabe guardarlo). En PC se conserva además la
   impresión de siempre (window.print(), ver events.js).

   No decide ninguna regla del Modelo M11 — solo lee lo que
   M11.Libro.resumenGeneral()/informeRentabilidad(),
   M11.Operaciones.getActiva(), M11.Evaluacion.ultima() y
   M11.AuthLocal.getUsuarioActual() ya calcularon.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const NOMBRE_ESTRATEGIA = { general: 'General', pares: 'Pares', impares: 'Impares' };

  function clasificarRiesgo(nivel) {
    if (nivel === null || nivel === undefined) return '—';
    if (nivel >= 11) return 'Máximo';
    if (nivel >= 9) return 'Alto';
    if (nivel >= 7) return 'Elevado';
    if (nivel >= 4) return 'Moderado';
    return 'Bajo';
  }

  // Devuelve las líneas de texto del resumen compartible — todo lo que
  // pide la sección 10: usuario, torneo, fecha de corte, capital,
  // ganancia/rentabilidad, partidos, estado de las tres estrategias,
  // riesgo/salud, diagnóstico, e identificación del Asistente.
  function construirLineasResumen() {
    const usuario = M11.AuthLocal ? M11.AuthLocal.getUsuarioActual() : null;
    const operacion = M11.Operaciones ? M11.Operaciones.getActiva() : null;
    const r = (M11.Libro ? M11.Libro.resumenGeneral() : {}) || {};
    const informe = (M11.Libro ? M11.Libro.informeRentabilidad() : {}) || {};
    const fmt = M11.Libro ? M11.Libro.fmt : (n => (n === null || n === undefined) ? '—' : String(n));
    const evalUltima = M11.Evaluacion ? M11.Evaluacion.ultima() : null;

    const nivelMax = Math.max(r.nivelGeneral || 0, r.nivelPares || 0, r.nivelImpares || 0);

    return [
      { texto: 'ASISTENTE OFICIAL M11 — RESUMEN DE OPERACIÓN', titulo: true },
      { texto: '' },
      { texto: `Usuario: ${usuario ? usuario.nombre : 'No identificado'}` },
      { texto: `Torneo: ${operacion ? operacion.nombre : 'Sin operación activa'}` },
      { texto: `Fecha y hora de corte: ${new Date().toLocaleString('es-CO')}` },
      { texto: '' },
      { texto: 'CAPITAL', titulo: true },
      { texto: `  Inicial: ${fmt(operacion ? operacion.capitalInicial : null)}` },
      { texto: `  Disponible: ${fmt(r.capitalDisponible)}` },
      { texto: `  Comprometido: ${fmt(r.capitalComprometido)}` },
      { texto: `  Patrimonio actual: ${fmt(r.patrimonioActual)}` },
      { texto: `  Retirable ahora: ${fmt(r.retirableAhora)}` },
      { texto: `  Total utilizado: ${fmt(r.totalApostadoAcum)}` },
      { texto: `  Máximo utilizado a la vez: ${fmt(r.maximoUtilizado)}` },
      { texto: `  Ganancia/pérdida: ${fmt(r.gananciaAcumulada)}` },
      { texto: `  Rentabilidad sobre capital inicial: ${(informe.rentabilidadPct !== null && informe.rentabilidadPct !== undefined) ? informe.rentabilidadPct.toFixed(2) + '%' : '—'}` },
      { texto: '' },
      { texto: 'PARTIDOS', titulo: true },
      { texto: `  Jugados: ${r.totalPartidos ?? '—'}` },
      { texto: `  Empates: ${r.empates ?? '—'}` },
      { texto: `  No empates: ${r.noEmpates ?? '—'}` },
      { texto: `  Cancelados: ${r.cancelados ?? '—'}` },
      { texto: '' },
      { texto: 'ESTRATEGIAS', titulo: true },
      { texto: `  General: Nivel ${r.nivelGeneral ?? '—'} · Riesgo ${clasificarRiesgo(r.nivelGeneral)}` },
      { texto: `  Pares: Nivel ${r.nivelPares ?? '—'} · Riesgo ${clasificarRiesgo(r.nivelPares)}` },
      { texto: `  Impares: Nivel ${r.nivelImpares ?? '—'} · Riesgo ${clasificarRiesgo(r.nivelImpares)}` },
      { texto: `  Finalizadas: ${(r.estrategiasFinalizadas && r.estrategiasFinalizadas.length) ? r.estrategiasFinalizadas.join(', ') : 'Ninguna'}` },
      { texto: '' },
      { texto: 'RIESGO Y SALUD DE LA OPERACIÓN', titulo: true },
      { texto: `  Nivel más alto entre las tres estrategias: ${nivelMax || '—'} (${clasificarRiesgo(nivelMax)})` },
      { texto: '' },
      { texto: 'DIAGNÓSTICO', titulo: true },
      evalUltima
        ? { texto: `  Bloque ${evalUltima.bloque}: ${evalUltima.mensaje || 'Ver detalle en la app.'}` }
        : { texto: '  Todavía no hay diagnóstico (se genera cada 20 partidos jugados).' },
      { texto: '' },
      { texto: 'Asistente Oficial M11 – Wilder Erley Vargas Castillo' }
    ];
  }

  function nombreArchivo() {
    return `Resumen_M11_${new Date().toISOString().slice(0, 10)}.pdf`;
  }

  // Construye el documento PDF en memoria (jsPDF, texto simple — no
  // necesita más para un resumen de este tipo).
  function construirDocumentoPdf() {
    if (!window.jspdf || !window.jspdf.jsPDF) throw new Error('jsPDF no está disponible.');
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    let y = 18;
    construirLineasResumen().forEach(linea => {
      doc.setFont('helvetica', linea.titulo ? 'bold' : 'normal');
      doc.setFontSize(linea.titulo ? 13 : 11);
      doc.text(linea.texto, 14, y);
      y += linea.titulo ? 9 : 7;
      if (y > 280) { doc.addPage(); y = 18; }
    });
    return doc;
  }

  function _filesystem() { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Filesystem; }
  function _share() { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Share; }

  // Guarda el PDF en el dispositivo. En Android usa el almacenamiento de
  // Documentos de la app vía @capacitor/filesystem; fuera de Android,
  // usa la descarga normal del navegador (doc.save ya abre el diálogo
  // de "Guardar archivo" del sistema).
  async function guardarPdf() {
    const doc = construirDocumentoPdf();
    const archivo = nombreArchivo();
    const Filesystem = _filesystem();
    if (Filesystem) {
      const base64 = doc.output('datauristring').split(',')[1];
      const res = await Filesystem.writeFile({ path: archivo, data: base64, directory: 'DOCUMENTS' });
      return { ok: true, metodo: 'dispositivo', archivo, uri: res && res.uri };
    }
    doc.save(archivo);
    return { ok: true, metodo: 'descarga', archivo };
  }

  // Comparte el PDF con otras apps (WhatsApp, correo, Drive, ...) vía
  // @capacitor/share. Fuera de Android no existe una hoja de compartir
  // nativa del sistema operativo utilizable así, así que se ofrece la
  // descarga del PDF como alternativa razonable.
  async function compartirResumen() {
    const doc = construirDocumentoPdf();
    const archivo = nombreArchivo();
    const Filesystem = _filesystem();
    const Share = _share();
    if (Filesystem && Share) {
      const base64 = doc.output('datauristring').split(',')[1];
      const res = await Filesystem.writeFile({ path: archivo, data: base64, directory: 'CACHE' });
      await Share.share({ title: 'Resumen Asistente M11', url: res.uri, dialogTitle: 'Compartir resumen M11' });
      return { ok: true, metodo: 'compartir' };
    }
    doc.save(archivo);
    return { ok: true, metodo: 'descarga' };
  }

  M11.PdfShare = { construirLineasResumen, construirDocumentoPdf, guardarPdf, compartirResumen };

})(window.M11);
