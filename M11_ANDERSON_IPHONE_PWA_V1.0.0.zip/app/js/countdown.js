/* =========================================================
   M11 · countdown.js
   -----------------------------------------------------------
   Contador real calculado contra el próximo partido del
   calendario (M11.getPartidoActual). No es un valor fijo. Cuando
   exista la API deportiva, el calendario vendrá de ahí y este
   módulo no necesitará cambios.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  function minutosRestantes() {
    const p = M11.getPartidoActual();
    if (!p) return null;
    const inicio = M11.inicioPartidoMs ? M11.inicioPartidoMs(p) : new Date(p.timestampUTC || `${p.fecha}T${p.hora}:00`).getTime();
    return (inicio - Date.now()) / 60000;
  }

  function formatear(mins) {
    if (mins === null) return 'Sin partido programado';
    if (mins <= 0) return 'Comenzó';
    const totalMin = Math.ceil(mins);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return h > 0 ? `${h} h ${m} min` : `${m} min`;
  }

  M11.Countdown = {
    minutosRestantes,
    textoActual() { return formatear(minutosRestantes()); }
  };

})(window.M11);
