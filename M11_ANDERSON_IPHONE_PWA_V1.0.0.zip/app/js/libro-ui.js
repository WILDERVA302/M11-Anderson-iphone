/* =========================================================
   M11 · libro-ui.js
   -----------------------------------------------------------
   Renderizado del Libro de Operaciones M11 (Generador Automático
   de Plantillas M11). Lee exclusivamente de M11.Libro — nunca
   reconstruye datos a partir de textos del historial antiguo.

   No se redibuja en el intervalo de un segundo de ui.js: no hay
   nada aquí que dependa del reloj, y así los filtros que el
   operador esté completando nunca se pisan solos.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);
  const NOMBRE = { general: 'General', pares: 'Pares', impares: 'Impares' };
  const RESULTADO_LABEL = { empate: 'Empate', no_empate: 'No empate', cancelado: 'Cancelado', suspendido: 'Suspendido' };

  let vista = 'resumida'; // 'resumida' | 'detallada'
  let filaExpandida = null; // número de partido expandido en la vista resumida
  // Orden por defecto: cronológico ascendente (Partido 1 -> último), tal
  // como pidió el Director, para ver la evolución del Modelo M11 desde
  // el inicio. El operador puede invertirlo con el botón de orden.
  let orden = 'ascendente'; // 'ascendente' | 'descendente'

  function fmtND(n) { return (n === null || n === undefined) ? 'Dato no disponible en esta versión del registro.' : M11.Libro.fmt(n); }
  function fmtSigno(n) {
    if (n === null || n === undefined) return 'Dato no disponible en esta versión del registro.';
    return (n >= 0 ? '+' : '−') + M11.Libro.fmt(Math.abs(n));
  }
  function formatearFecha(f) {
    if (!f) return 'Fecha no disponible';
    const d = new Date(f);
    return isNaN(d.getTime()) ? String(f) : d.toLocaleString('es-CO', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  }

  function resultadoTexto(r) {
    if (r.tipoOriginal === 'sin_accion') return 'Sin acción en app';
    if (r.tipoOriginal === 'no_apostada') return 'No apostada';
    return RESULTADO_LABEL[r.resultado] || '—';
  }
  function resultadoClase(r) {
    if (r.tipoOriginal === 'no_apostada' || r.tipoOriginal === 'sin_accion') return 'gris';
    if (r.resultado === 'empate') return 'verde';
    if (r.resultado === 'no_empate') return 'rojo';
    if (r.resultado === 'cancelado' || r.resultado === 'suspendido') return 'gris';
    return '';
  }

  // ---- Resumen compacto por estrategia (vista resumida) -------------------
  function resumenCompacto(e) {
    if (!e.participa) return e.bloqueadaAntes ? 'Bloqueada' : 'No participa';
    if (e.estadoDespues === 'secuencia_finalizada') return 'Finalizada';
    if (e.nivelAntes === null || e.nivelDespues === null) return 'Dato no disp.';
    if (e.gananciaNeta === null) return `N${e.nivelAntes} → N${e.nivelDespues}`;
    return `N${e.nivelAntes} → N${e.nivelDespues} · ${fmtSigno(e.gananciaNeta)}`;
  }

  // ---- Ficha detallada de un partido (sección 7B) -------------------------
  function filaEstrategia(nombre, e) {
    const N = NOMBRE[nombre];
    const clase = !e.participa ? 'gris' : (e.estadoDespues === 'secuencia_finalizada' ? 'rojo' : (e.estadoDespues === 'reinicia_nivel_1' ? 'verde' : (e.nivelDespues === 11 ? 'naranja' : '')));
    const badge = !e.participa ? '<span class="pill neutral">No participa</span>' : (e.estadoDespues === 'secuencia_finalizada' ? '<span class="pill rojo-pill">Secuencia finalizada</span>' : '');
    const datos = e.participa ? `
      <div class="libro-estrategia-datos">
        <span>Nivel: ${e.nivelAntes ?? '—'} → ${e.nivelDespues ?? '—'}</span>
        <span>Recomendado: ${fmtND(e.montoRecomendado)}</span>
        <span>Apostado: ${fmtND(e.montoApostado)}</span>
        <span>Cuota: ${e.cuota ?? 'No disponible'}</span>
        <span>Retorno: ${fmtND(e.retorno)}</span>
        <span>Ganancia/pérdida: ${fmtSigno(e.gananciaNeta)}</span>
        <span>Saldo: ${fmtND(e.saldoAntes)} → ${fmtND(e.saldoDespues)}</span>
      </div>` : '';
    return `<div class="libro-estrategia ${clase}">
      <div class="libro-estrategia-head"><strong>${N}</strong>${badge}</div>
      ${datos}
      <p class="libro-explicacion">${e.explicacion}</p>
    </div>`;
  }

  function construirFicha(r) {
    const titulo = r.tipoOriginal === 'apostada'
      ? `Partido M11 ${r.numeroApuestaM11 || r.numero}`
      : `Registro ${r.numero} · no consume turno M11`;
    const revision = r.revisionRequerida ? `<div class="libro-revision">⚠ Revisión requerida — ${r.motivoRevision}</div>` : '';
    const origenNota = r.origen === 'migrado' ? '<p class="legal-note">Registro migrado del historial anterior a este módulo; algunos campos pueden no estar disponibles.</p>' : '';
    return `<article class="libro-ficha ${r.revisionRequerida ? 'con-revision' : ''}" data-numero="${r.numero}">
      <div class="libro-ficha-header">
        <strong>${titulo}</strong>
        <span class="pill ${resultadoClase(r)}">${resultadoTexto(r)}</span>
      </div>
      <div class="libro-ficha-meta">
        <span>Partido: ${formatearFecha(r.fechaHoraPartido || r.fechaHora)}</span>
        <span>${r.torneo || 'Torneo no disponible'}</span>
        <span>${(r.equipoLocal || '—')} vs ${(r.equipoVisitante || '—')}</span>
        ${r.casaApuestas ? `<span>Casa: ${r.casaApuestas}</span>` : ''}
      </div>
      ${revision}
      <div class="libro-ficha-financiero">
        <div><span>Capital antes</span><strong>${fmtND(r.capitalTotalAntes)}</strong></div>
        <div><span>Apostado</span><strong>${fmtND(r.totalApostado)}</strong></div>
        <div><span>Retorno</span><strong>${fmtND(r.retornoTotal)}</strong></div>
        <div><span>Ganancia/pérdida</span><strong>${fmtSigno(r.gananciaNetaTotal)}</strong></div>
        <div><span>Capital después</span><strong>${fmtND(r.capitalTotalDespues)}</strong></div>
      </div>
      ${['general', 'pares', 'impares'].map(n => filaEstrategia(n, r.estrategias[n])).join('')}
      ${origenNota}
    </article>`;
  }

  // ---- Resumen general (sección 9) ----------------------------------------
  function pintarResumen() {
    const s = M11.Libro.resumenGeneral();
    const box = $('#libroResumenCard');
    box.innerHTML = `
      <div class="eyebrow">RESUMEN GENERAL DE LA OPERACIÓN</div>
      <div class="libro-resumen-grid">
        <div><span>Torneo</span><strong>${s.torneo || 'No disponible'}</strong></div>
        <div><span>Inicio</span><strong>${formatearFecha(s.fechaInicio)}</strong></div>
        <div><span>Partidos totales</span><strong>${s.totalPartidos}</strong></div>
        <div><span>Apostados</span><strong>${s.apostados}</strong></div>
        <div><span>No apostados</span><strong>${s.noApostados}</strong></div>
        <div><span>Empates</span><strong>${s.empates}</strong></div>
        <div><span>No empates</span><strong>${s.noEmpates}</strong></div>
        <div><span>Cancelados</span><strong>${s.cancelados}</strong></div>
        <div><span>Capital inicial</span><strong>${fmtND(s.capitalInicial)}</strong></div>
        <div><span>Capital disponible</span><strong>${fmtND(s.capitalDisponible)}</strong></div>
        <div><span>Capital comprometido</span><strong>${fmtND(s.capitalComprometido)}</strong></div>
        <div><span>Patrimonio actual</span><strong>${fmtND(s.patrimonioActual)}</strong></div>
        <div><span>Retirable ahora</span><strong>${fmtND(s.retirableAhora)}</strong></div>
        <div><span>Mayor apuesta en un partido</span><strong>${fmtND(s.maximoUtilizado)}</strong></div>
        <div><span>Dinero movilizado acumulado</span><strong>${fmtND(s.totalApostadoAcum)}</strong></div>
        <div><span>Mayor capital requerido</span><strong>${fmtND(s.maximoCapitalRequerido)}</strong></div>
        <div><span>Reserva realmente exigida</span><strong>${s.porcentajeReservaExigida===null?'—':s.porcentajeReservaExigida.toFixed(2).replace('.',',')+'%'}</strong></div>
        <div><span>Rendimiento sobre lo movilizado</span><strong>${s.rendimientoSobreMovilizado===null?'—':s.rendimientoSobreMovilizado.toFixed(2).replace('.',',')+'%'}</strong></div>
        <div><span>Total retornado</span><strong>${fmtND(s.totalRetornadoAcum)}</strong></div>
        <div><span>Ganancia/pérdida acumulada</span><strong>${fmtSigno(s.gananciaAcumulada)}</strong></div>
        <div><span>Saldo General</span><strong>${fmtND(s.saldoGeneral)} (N${s.nivelGeneral ?? '—'})</strong></div>
        <div><span>Saldo Pares</span><strong>${fmtND(s.saldoPares)} (N${s.nivelPares ?? '—'})</strong></div>
        <div><span>Saldo Impares</span><strong>${fmtND(s.saldoImpares)} (N${s.nivelImpares ?? '—'})</strong></div>
        <div><span>Estrategias activas</span><strong>${s.estrategiasActivas.join(', ') || 'Ninguna'}</strong></div>
        <div><span>Estrategias finalizadas</span><strong>${s.estrategiasFinalizadas.join(', ') || 'Ninguna'}</strong></div>
      </div>`;
  }

  // ---- Objetivos de Rentabilidad, igual al de pantalla (Sprint 1) ---------
  // Reutiliza M11.UI.objetivosHTML() sobre M11.UI.calcularObjetivos(): el
  // mismo HTML que arma la tarjeta de pantalla, sin recalcular nada.
  function pintarObjetivos() {
    const box = $('#libroObjetivosCard');
    if (!box || !M11.UI || !M11.UI.calcularObjetivos || !M11.UI.objetivosHTML) return;
    box.innerHTML = M11.UI.objetivosHTML(M11.UI.calcularObjetivos());
  }

  function pintarFechaCorte() {
    const el = $('#libroFechaCorte');
    if (!el) return;
    const ahora = new Date();
    const pad = n => String(n).padStart(2, '0');
    el.textContent = `Fecha y hora de corte: ${pad(ahora.getDate())}-${pad(ahora.getMonth() + 1)}-${ahora.getFullYear()} · ${pad(ahora.getHours())}:${pad(ahora.getMinutes())}`;
  }

  function pintarDiagnosticoImpresion() {
    const box = $('#libroDiagnosticoCard');
    if (!box || !M11.UI || !M11.UI.construirNarrativa) return;
    const lineas = M11.UI.construirNarrativa();
    box.innerHTML = `<div class="eyebrow">DIAGNÓSTICO DEL ASISTENTE</div>` +
      (lineas.length ? lineas.map(l => `<p class="comentario-asistente-bloque">${l}</p>`).join('') : `<p class="legal-note">Todavía no hay un diagnóstico para mostrar: registre el primer partido.</p>`);
  }

  function pintarRiesgoSaludImpresion() {
    const box = $('#libroRiesgoSaludCard');
    if (!box || !M11.UI || !M11.UI.riesgoYSaludHTML) return;
    box.innerHTML = M11.UI.riesgoYSaludHTML();
  }

  function pintarDiagnosticoImpresion() {
    const box = $('#libroDiagnosticoCard');
    if (!box || !M11.UI || !M11.UI.construirNarrativa) return;
    const lineas = M11.UI.construirNarrativa();
    box.innerHTML = `<div class="eyebrow">DIAGNÓSTICO DEL ASISTENTE</div>` +
      (lineas.length ? lineas.map(l => `<p class="comentario-asistente-bloque">${l}</p>`).join('')
        : `<p class="legal-note">No hay diagnóstico reciente: todavía no se registró un resultado en esta sesión.</p>`);
  }

  // ---- Informe de rentabilidad, igual al de pantalla (sección 9-bis) ------
  // Nunca recalcula: lee de M11.UI.calcularRentabilidadCompleta(), la misma
  // función que alimenta el Informe de Rentabilidad del Centro de
  // Operaciones. Así pantalla e impresión muestran siempre el mismo número,
  // porque son el mismo número.
  function pintarRentabilidad() {
    const box = $('#libroRentabilidadCard');
    if (!box || !M11.UI || !M11.UI.calcularRentabilidadCompleta) return;
    const d = M11.UI.calcularRentabilidadCompleta();
    if (!d) { box.innerHTML = ''; return; }
    const signo = (n) => (n === null ? '' : (n >= 0 ? '+' : '−'));
    const fmtPct = (n) => `${signo(n)}${Math.abs(n).toFixed(2)}%`;
    const pctApostadoTxt = d.pctApostado === null ? 'No disponible' : fmtPct(d.pctApostado);
    const pctBrutoTxt = d.pctBruto === null ? 'No disponible' : `${d.pctBruto.toFixed(2)}%`;
    const pctCapitalTxt = d.pctCapital === null ? '—' : fmtPct(d.pctCapital);

    box.innerHTML = `
      <div class="eyebrow">INFORME DE RENTABILIDAD</div>
      <div class="libro-resumen-grid">
        <div><span>Capital inicial</span><strong>${fmtND(d.capitalInicial)}</strong></div>
        <div><span>Capital actual</span><strong>${fmtND(d.capitalActual)}</strong></div>
        <div><span>Ganancia/pérdida acumulada</span><strong>${d.gananciaAcumulada === null ? '—' : `${signo(d.gananciaAcumulada)}${fmtND(Math.abs(d.gananciaAcumulada))}`}</strong></div>
        <div><span>Total apostado</span><strong>${fmtND(d.totalApostado)}</strong></div>
        <div><span>Total retornado</span><strong>${fmtND(d.totalRetornado)}</strong></div>
        <div><span>Partidos jugados</span><strong>${d.partidosJugados}</strong></div>
        <div><span>Empates</span><strong>${d.empates}</strong></div>
        <div><span>No empates</span><strong>${d.noEmpates}</strong></div>
        <div><span>Promedio por operación cerrada</span><strong>${d.promedioPorOperacion === null ? 'No disponible' : `${d.promedioPorOperacion >= 0 ? '+' : '−'}${fmtND(Math.abs(d.promedioPorOperacion))}`}</strong></div>
        <div><span>Estrategias activas</span><strong>${d.estrategiasActivas.join(', ') || 'Ninguna'}</strong></div>
        <div><span>Estrategias finalizadas</span><strong>${d.estrategiasFinalizadas.join(', ') || 'Ninguna'}</strong></div>
      </div>
      <div class="rentabilidad-porcentajes">
        <div class="rent-pct-item">
          <span>Rentabilidad sobre capital inicial</span>
          <strong>${pctCapitalTxt}</strong>
          <small>Sobre capital inicial: rendimiento del capital total.</small>
        </div>
        <div class="rent-pct-item">
          <span>Rentabilidad sobre lo apostado</span>
          <strong>${pctApostadoTxt}</strong>
          <small>Sobre lo apostado: ganancia neta frente al dinero expuesto.</small>
        </div>
        <div class="rent-pct-item">
          <span>Retorno bruto sobre lo apostado</span>
          <strong>${pctBrutoTxt}</strong>
          <small>Retorno bruto: dinero recuperado más ganancia frente a lo apostado. No es ganancia neta.</small>
        </div>
      </div>`;
  }

  // ---- Filtros (sección 10) ------------------------------------------------
  function aplicarFiltros(registros) {
    const estrategia = $('#libroFiltroEstrategia').value;
    const resultado = $('#libroFiltroResultado').value;
    const soloFinalizadas = $('#libroFiltroFinalizadas').checked;
    const busqueda = $('#libroBusquedaEquipo').value.trim().toLowerCase();
    const desde = Number($('#libroFiltroDesde').value) || null;
    const hasta = Number($('#libroFiltroHasta').value) || null;
    const fechaDesdeVal = $('#libroFiltroFechaDesde').value;
    const fechaHastaVal = $('#libroFiltroFechaHasta').value;
    const fechaDesde = fechaDesdeVal ? new Date(fechaDesdeVal) : null;
    const fechaHasta = fechaHastaVal ? new Date(fechaHastaVal + 'T23:59:59') : null;

    return registros.filter(r => {
      if (estrategia !== 'todos' && !(r.estrategias[estrategia] && r.estrategias[estrategia].participa)) return false;
      if (resultado !== 'todos') {
        if (resultado === 'no_apostada') { if (r.tipoOriginal !== 'no_apostada' && r.tipoOriginal !== 'sin_accion') return false; }
        else if (resultado === 'cancelado') { if (r.resultado !== 'cancelado' && r.resultado !== 'suspendido') return false; }
        else if (r.resultado !== resultado) return false;
      }
      if (soloFinalizadas) {
        const algunaFinalizada = ['general', 'pares', 'impares'].some(n => r.estrategias[n].estadoDespues === 'secuencia_finalizada');
        if (!algunaFinalizada) return false;
      }
      if (busqueda) {
        const texto = `${r.equipoLocal || ''} ${r.equipoVisitante || ''}`.toLowerCase();
        if (!texto.includes(busqueda)) return false;
      }
      if (desde !== null && r.numero < desde) return false;
      if (hasta !== null && r.numero > hasta) return false;
      if (fechaDesde || fechaHasta) {
        const f = new Date(r.fechaHora);
        if (!isNaN(f.getTime())) {
          if (fechaDesde && f < fechaDesde) return false;
          if (fechaHasta && f > fechaHasta) return false;
        }
      }
      return true;
    });
  }

  // ---- Vista resumida: tabla (sección 7A) ----------------------------------
  function pintarVistaResumida(filtrados) {
    if (!filtrados.length) return '<div class="empty">Sin partidos que coincidan con los filtros.</div>';
    const filas = filtrados.map(r => {
      const expandido = filaExpandida === r.numero;
      const numeroVisible = r.tipoOriginal === 'apostada'
        ? `M11 #${r.numeroApuestaM11 || r.numero}`
        : `Reg. #${r.numero}`;
      return `<div class="libro-fila-wrap">
        <button type="button" class="libro-fila" data-numero="${r.numero}">
          <span>${numeroVisible}</span>
          <span>${formatearFecha(r.fechaHoraPartido || r.fechaHora)}</span>
          <span>${(r.equipoLocal || '—')} vs ${(r.equipoVisitante || '—')}</span>
          <span class="pill ${resultadoClase(r)}">${resultadoTexto(r)}</span>
          <span>${resumenCompacto(r.estrategias.general)}</span>
          <span>${resumenCompacto(r.estrategias.pares)}</span>
          <span>${resumenCompacto(r.estrategias.impares)}</span>
          <span>${fmtND(r.totalApostado)}</span>
          <span>${fmtND(r.retornoTotal)}</span>
          <span>${fmtND(r.capitalTotalDespues)}</span>
        </button>
        ${expandido ? `<div class="libro-fila-detalle">${construirFicha(r)}</div>` : ''}
      </div>`;
    }).join('');
    return `<div class="libro-tabla-scroll">
      <div class="libro-tabla-cabecera">
        <span>#</span><span>Fecha</span><span>Partido</span><span>Resultado</span><span>General</span><span>Pares</span><span>Impares</span><span>Apostado</span><span>Retorno</span><span>Saldo total</span>
      </div>
      ${filas}
    </div>`;
  }

  // ---- Vista detallada: fichas (sección 7B) --------------------------------
  function pintarVistaDetallada(filtrados) {
    if (!filtrados.length) return '<div class="empty">Sin partidos que coincidan con los filtros.</div>';
    return `<div class="libro-fichas">${filtrados.map(construirFicha).join('')}</div>`;
  }

  // Registros en el orden y con los filtros que el operador tiene
  // activos ahora mismo — única función que decide "qué está viendo el
  // usuario". La usan tanto render() como Imprimir y Compartir imagen,
  // para que los tres coincidan siempre exactamente.
  function registrosActuales() {
    const base = M11.Libro.listar(); // ya viene en orden ascendente (Partido 1, 2, 3...)
    const todos = orden === 'ascendente' ? base.slice() : base.slice().reverse();
    return aplicarFiltros(todos);
  }

  function render() {
    if (!$('#libroContenido')) return;
    pintarResumen();
    pintarRentabilidad();
    pintarObjetivos();
    pintarRiesgoSaludImpresion();
    pintarDiagnosticoImpresion();
    pintarFechaCorte();
    pintarDiagnosticoImpresion();
    $('#libroVistaResumidaBtn').classList.toggle('activo', vista === 'resumida');
    $('#libroVistaDetalladaBtn').classList.toggle('activo', vista === 'detallada');
    // Exportar imagen es la salida pensada para compartir (Vista
    // Resumida); en Vista Detallada solo tiene sentido Imprimir, para
    // consulta y auditoría.
    const btnExportar = $('#libroCompartirBtn');
    if (btnExportar) btnExportar.classList.toggle('hidden', vista !== 'resumida');
    const ordenBtn = $('#libroOrdenBtn');
    if (ordenBtn) ordenBtn.textContent = orden === 'ascendente' ? 'Orden: Partido 1 → último ↓' : 'Orden: más reciente primero ↑';
    const filtrados = registrosActuales();
    $('#libroContenido').innerHTML = vista === 'resumida' ? pintarVistaResumida(filtrados) : pintarVistaDetallada(filtrados);
  }

  M11.LibroUI = {
    render,
    setVista(v) { vista = v; render(); },
    toggleOrden() { orden = orden === 'ascendente' ? 'descendente' : 'ascendente'; render(); },
    toggleFila(numero) { filaExpandida = (filaExpandida === numero) ? null : numero; render(); },

    // Para Imprimir y Compartir imagen (Sprint V1.0): exactamente los
    // registros que el operador está viendo ahora — mismo orden, mismos
    // filtros. Nadie vuelve a calcular esto por su cuenta.
    registrosFiltradosActuales: registrosActuales,
    // Funciones de interpretación/formato ya existentes, reutilizables
    // por exportar.js sin reimplementarlas.
    resumenCompactoEstrategia: resumenCompacto,
    resultadoTexto,
    formatearFecha
  };

})(window.M11);
