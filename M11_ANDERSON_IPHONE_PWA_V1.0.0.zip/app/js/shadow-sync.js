/* Seguimiento informativo de resultados publicados para Operación Sombra. */
window.M11 = window.M11 || {};
(function (M11) {
  'use strict';
  const CACHE_MS = 30 * 60 * 1000;
  let aiAgendaCache = null;

  function normalizedText(value) {
    return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  }
  function stableAiId(match) {
    const raw=[match.competition,match.date,match.time,match.home,match.away].map(normalizedText).join('|');
    let hash=2166136261;for(let i=0;i<raw.length;i++){hash^=raw.charCodeAt(i);hash=Math.imul(hash,16777619);}
    return `ai-${(hash>>>0).toString(16)}`;
  }
  function aiMatchToEvent(match,tournament) {
    const stamp=match.timestampUTC||(`${match.date||''}T${match.time||'00:00'}:00-05:00`);
    const parsed=new Date(stamp), timestampUTC=Number.isNaN(parsed.getTime())?null:parsed.toISOString();
    const statusMap={programado:'programado',en_curso:'en_curso',finalizado:'finalizado',aplazado:'aplazado',cancelado:'cancelado',suspendido:'suspendido'};
    return {externalId:stableAiId(match),provider:`IA privada · ${match.provider||'búsqueda web'}`,leagueId:String(tournament.leagueId||''),leagueName:tournament.name,season:tournament.season||'',round:null,eventName:`${match.home||''} vs ${match.away||''}`,homeTeam:match.home||'',awayTeam:match.away||'',homeTeamId:null,awayTeamId:null,homeScore:null,awayScore:null,fecha:match.date||null,hora:match.time||null,timestampUTC,venue:'',status:statusMap[match.status]||'programado',resultadoSugerido:null,resultadoContradictorio:false,sourceData:match};
  }
  function aiEventsForTournament(tournament) {
    if(!aiAgendaCache||!Array.isArray(aiAgendaCache.matches))return [];
    const target=normalizedText(tournament.name), leagueId=String(tournament.leagueId||'');
    return aiAgendaCache.matches.filter(m=>{
      if(leagueId&&String(m.leagueId||'')===leagueId)return true;
      const competition=normalizedText(m.competition);
      return competition&&target&&(competition.includes(target)||target.includes(competition));
    }).map(m=>aiMatchToEvent(m,tournament)).filter(e=>e.externalId&&e.timestampUTC);
  }
  async function loadAiAgenda(experiment) {
    aiAgendaCache=null;
    if(!M11.AIAdmin||typeof M11.AIAdmin.callService!=='function')return null;
    const tournaments=(experiment.tournaments||[]).map(t=>({name:t.name,country:t.country||'',leagueId:String(t.leagueId||'')}));
    const today=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Bogota',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
    try{
      const data=await M11.AIAdmin.callService('daily_agenda',{context:{owner:'Wilder',timeZone:'America/Bogota',currentDateTime:new Date().toISOString(),date:today,day:'today',championships:tournaments,localAgenda:[],guardrails:{neverPlaceBet:true,neverChangeMoney:true,neverSettleWithoutScore:true}}});
      aiAgendaCache={matches:Array.isArray(data.matches)?data.matches:[],summary:data.summary||'',loadedAt:new Date().toISOString()};return aiAgendaCache;
    }catch(error){aiAgendaCache={matches:[],error:error.message||String(error),loadedAt:new Date().toISOString()};return aiAgendaCache;}
  }

  function trackingFor(tournament) {
    if(tournament.studyMode!=='retrospective')tournament.studyMode='prospective';
    if (!tournament.tracking) tournament.tracking = { lastSyncAt:null, eventNumbers:{}, nextNumber:1, ignoredBeforeStart:[], simultaneousExcluded:[], lastError:null };
    if (!Array.isArray(tournament.tracking.pendingEvents)) tournament.tracking.pendingEvents=[];
    if (!Array.isArray(tournament.tracking.queuedEvents)) tournament.tracking.queuedEvents=[];
    if (!Array.isArray(tournament.tracking.auditNotes)) tournament.tracking.auditNotes=[];
    if (!tournament.tracking.lockedEvents || Array.isArray(tournament.tracking.lockedEvents)) tournament.tracking.lockedEvents={};
    if (!tournament.tracking.eventCatalog || Array.isArray(tournament.tracking.eventCatalog)) tournament.tracking.eventCatalog={};
    if (!Array.isArray(tournament.tracking.missingEvents)) tournament.tracking.missingEvents=[];
    if (!tournament.tracking.deferredPlans || Array.isArray(tournament.tracking.deferredPlans)) tournament.tracking.deferredPlans={};
    if (tournament.tracking.openPlan === undefined) tournament.tracking.openPlan=null;
    const sources=[...(tournament.history||[]),...(tournament.tracking.queuedEvents||[]),...(tournament.tracking.pendingEvents||[]),...Object.values(tournament.tracking.lockedEvents||{})];
    if(tournament.tracking.openPlan)sources.push(tournament.tracking.openPlan);
    sources.forEach(e=>{if(e&&e.externalId)tournament.tracking.eventCatalog[e.externalId]={...(tournament.tracking.eventCatalog[e.externalId]||{}),externalId:e.externalId,chronologicalNumber:Number(e.chronologicalNumber)||tournament.tracking.eventNumbers[e.externalId],homeTeam:e.homeTeam||'',awayTeam:e.awayTeam||'',timestampUTC:e.timestampUTC||e.kickoffUTC||''};});
    return tournament.tracking;
  }
  function time(event) { return event.timestampUTC ? new Date(event.timestampUTC).getTime() : 0; }
  function keyTime(event) { return event.timestampUTC || `${event.fecha || ''}T${event.hora || ''}`; }
  function eligibleStatus(event) { return ['programado','en_curso','finalizado','cancelado','suspendido'].includes(event.status); }
  function eventResult(event) {
    if(event.status==='finalizado')return event.resultadoSugerido==='empate'?'draw':event.resultadoSugerido==='no_empate'?'not_draw':null;
    if(event.status==='cancelado')return 'cancelled';
    if(event.status==='suspendido')return 'suspended';
    return null;
  }
  function planFor(tournament,event,number) {
    const names=['general',number%2===0?'pares':'impares'], amounts={};
    names.forEach(name=>{const s=tournament.strategies[name];if(!s.closed)amounts[name]={level:s.level,amount:M11.ShadowEngine.amountForLevel(tournament.base,s.level)};});
    return {externalId:event.externalId,chronologicalNumber:number,homeTeam:event.homeTeam,awayTeam:event.awayTeam,kickoffUTC:event.timestampUTC,experimentalQuota:tournament.experimentalQuota,participants:names,amounts,plannedAt:new Date().toISOString(),label:'Apuesta ficticia preparada — no realizada'};
  }
  function currentAmounts(tournament,number) {
    const names=['general',number%2===0?'pares':'impares'], amounts={};
    names.forEach(name=>{const s=tournament.strategies[name];if(!s.closed)amounts[name]={level:s.level,amount:M11.ShadowEngine.amountForLevel(tournament.base,s.level)};});
    return amounts;
  }
  function refreshOpenPlan(tournament,tracking) {
    const open=tracking.openPlan;
    if(!open||tournament.processedEventIds.includes(open.externalId))return false;
    const refreshed=currentAmounts(tournament,Number(open.chronologicalNumber));
    const before=JSON.stringify(open.amounts||{}), after=JSON.stringify(refreshed);
    open.amounts=refreshed;
    open.participants=Object.keys(refreshed);
    open.experimentalQuota=tournament.experimentalQuota;
    if(before!==after)open.recalculatedAt=new Date().toISOString();
    return before!==after;
  }
  function lockEligibility(tournament,tracking,event,number,source) {
    if(tournament.studyMode==='retrospective'||tracking.lockedEvents[event.externalId])return false;
    const beforeFinal=event.status==='en_curso'||(event.status==='programado'&&time(event)>Date.now());
    if(!beforeFinal)return false;
    tracking.lockedEvents[event.externalId]={externalId:event.externalId,chronologicalNumber:number,homeTeam:event.homeTeam,awayTeam:event.awayTeam,kickoffUTC:event.timestampUTC,lockedAt:new Date().toISOString(),source:source||'schedule_seen_before_result',status:'eligible'};
    return true;
  }
  function rememberEvent(tracking,event,number) {
    if(!event||!event.externalId)return;
    tracking.eventCatalog[event.externalId]={externalId:event.externalId,chronologicalNumber:Number(number),homeTeam:event.homeTeam||'',awayTeam:event.awayTeam||'',homeTeamId:event.homeTeamId||null,awayTeamId:event.awayTeamId||null,round:event.round||null,season:event.season||'',timestampUTC:event.timestampUTC||'',lastSeenAt:new Date().toISOString()};
  }
  function normalizedName(value) {
    return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\b(fc|cf|ac|club|deportivo|the)\b/g,' ').replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
  }
  function sameTeam(expectedName,expectedId,candidateName,candidateId) {
    if(expectedId&&candidateId)return String(expectedId)===String(candidateId);
    return !!normalizedName(expectedName)&&normalizedName(expectedName)===normalizedName(candidateName);
  }
  function secureReplacementCandidate(tournament,tracking,oldId,rawCandidates) {
    const catalog=tracking.eventCatalog[oldId]||{}, oldTime=catalog.timestampUTC?new Date(catalog.timestampUTC).getTime():NaN;
    const candidates=(rawCandidates||[]).map(raw=>raw&&raw.externalId?raw:M11.SportsApi.normalizeSportsDbEvent(raw,{leagueId:tournament.leagueId,leagueName:tournament.name,season:tournament.season})).filter(event=>{
      if(!event.externalId||event.externalId===oldId||tournament.processedEventIds.includes(event.externalId))return false;
      if(event.leagueId&&tournament.leagueId&&String(event.leagueId)!==String(tournament.leagueId))return false;
      if(catalog.season&&event.season&&String(catalog.season)!==String(event.season))return false;
      const sameHome=sameTeam(catalog.homeTeam,catalog.homeTeamId,event.homeTeam,event.homeTeamId)&&sameTeam(catalog.awayTeam,catalog.awayTeamId,event.awayTeam,event.awayTeamId);
      const reversed=sameTeam(catalog.homeTeam,catalog.homeTeamId,event.awayTeam,event.awayTeamId)&&sameTeam(catalog.awayTeam,catalog.awayTeamId,event.homeTeam,event.homeTeamId);
      if(!sameHome&&!reversed)return false;
      const assigned=tracking.eventNumbers[event.externalId];
      if(assigned&&Number(assigned)!==Number(tracking.eventNumbers[oldId])&&!reversed)return false;
      const candidateTime=time(event);
      const distance=Number.isFinite(oldTime)&&candidateTime?Math.abs(candidateTime-oldTime):NaN;
      // Una localía invertida puede ser una corrección del proveedor, pero
      // solo se acepta si corresponde prácticamente al mismo horario. Así
      // nunca se mezcla un partido de ida con el de vuelta.
      if(reversed)return Number.isFinite(distance)&&distance<=12*60*60*1000;
      return !Number.isFinite(distance)||distance<=14*86400000;
    });
    if(candidates.length!==1)return null;
    return candidates[0];
  }
  function replaceObjectKey(object,oldId,newId,event) {
    if(!object||!object[oldId])return;
    object[newId]={...object[oldId],externalId:newId,homeTeam:event.homeTeam||object[oldId].homeTeam,awayTeam:event.awayTeam||object[oldId].awayTeam,kickoffUTC:event.timestampUTC||object[oldId].kickoffUTC};
    delete object[oldId];
  }
  function migrateTrackedEventId(tournament,tracking,oldId,event) {
    const number=tracking.eventNumbers[oldId];
    if(!number||!event||!event.externalId||event.externalId===oldId)return false;
    const duplicateNumber=Number(tracking.eventNumbers[event.externalId]);
    tracking.eventNumbers[event.externalId]=number;
    delete tracking.eventNumbers[oldId];
    const oldCatalog=tracking.eventCatalog[oldId]||{};
    tracking.eventCatalog[event.externalId]={...oldCatalog,externalId:event.externalId,chronologicalNumber:Number(number),homeTeam:event.homeTeam,awayTeam:event.awayTeam,homeTeamId:event.homeTeamId||oldCatalog.homeTeamId||null,awayTeamId:event.awayTeamId||oldCatalog.awayTeamId||null,round:event.round||oldCatalog.round||null,season:event.season||oldCatalog.season||'',timestampUTC:event.timestampUTC||oldCatalog.timestampUTC||'',migratedFrom:oldId,lastSeenAt:new Date().toISOString()};
    delete tracking.eventCatalog[oldId];
    replaceObjectKey(tracking.lockedEvents,oldId,event.externalId,event);
    replaceObjectKey(tracking.deferredPlans,oldId,event.externalId,event);
    if(tracking.openPlan&&tracking.openPlan.externalId===oldId)tracking.openPlan={...tracking.openPlan,externalId:event.externalId,homeTeam:event.homeTeam,awayTeam:event.awayTeam,kickoffUTC:event.timestampUTC||tracking.openPlan.kickoffUTC};
    ['pendingEvents','queuedEvents','missingEvents'].forEach(key=>{tracking[key]=(tracking[key]||[]).filter(item=>item.externalId!==oldId);});
    if(Number.isFinite(duplicateNumber)&&duplicateNumber!==Number(number)){
      Object.keys(tracking.eventNumbers).forEach(id=>{if(Number(tracking.eventNumbers[id])>duplicateNumber)tracking.eventNumbers[id]=Number(tracking.eventNumbers[id])-1;});
      const shift=item=>{if(item&&Number(item.chronologicalNumber)>duplicateNumber)item.chronologicalNumber=Number(item.chronologicalNumber)-1;};
      Object.values(tracking.eventCatalog||{}).forEach(shift);
      Object.values(tracking.lockedEvents||{}).forEach(shift);
      Object.values(tracking.deferredPlans||{}).forEach(shift);
      (tracking.pendingEvents||[]).forEach(shift);(tracking.queuedEvents||[]).forEach(shift);(tracking.missingEvents||[]).forEach(shift);
      shift(tracking.openPlan);
      tracking.nextNumber=Math.max(1,Number(tracking.nextNumber||1)-1);
    }
    tracking.auditNotes.push({type:'event_id_relinked',at:new Date().toISOString(),oldExternalId:oldId,newExternalId:event.externalId,chronologicalNumber:Number(number),message:`El partido #${number} fue recuperado automáticamente después de que la fuente cambió su identificador.`});
    tracking.relinkedThisSync=(tracking.relinkedThisSync||0)+1;
    return true;
  }
  async function recoverChangedEventId(tournament,tracking,oldId,knownEvents) {
    const catalog=tracking.eventCatalog[oldId]||{};
    if(!catalog.homeTeam||!catalog.awayTeam)return null;
    let candidate=secureReplacementCandidate(tournament,tracking,oldId,knownEvents||[]);
    if(candidate)return candidate;
    let raws=[];
    if(typeof M11.SportsApi.buscarPartidosPorNombre==='function'){
      raws=await M11.SportsApi.buscarPartidosPorNombre(`${catalog.homeTeam} vs ${catalog.awayTeam}`);
      candidate=secureReplacementCandidate(tournament,tracking,oldId,raws);
      if(candidate)return candidate;
    }
    if(tournament.season&&typeof M11.SportsApi.partidosTemporadaLiga==='function'){
      raws=await M11.SportsApi.partidosTemporadaLiga(tournament.leagueId,tournament.season);
      return secureReplacementCandidate(tournament,tracking,oldId,raws);
    }
    return null;
  }
  function missingNumberedEvents(tournament,tracking,events) {
    const present=new Set(events.map(e=>e.externalId)), previous=new Map((tracking.missingEvents||[]).map(e=>[e.externalId,e]));
    return Object.entries(tracking.eventNumbers).filter(([id])=>!tournament.processedEventIds.includes(id)&&!present.has(id)).map(([id,number])=>{
      const catalog=tracking.eventCatalog[id]||{}, old=previous.get(id)||{};
      return {externalId:id,chronologicalNumber:Number(number),homeTeam:catalog.homeTeam||old.homeTeam||'',awayTeam:catalog.awayTeam||old.awayTeam||'',timestampUTC:catalog.timestampUTC||old.timestampUTC||'',firstDetectedAt:old.firstDetectedAt||new Date().toISOString(),lastCheckedAt:new Date().toISOString(),reason:'TheSportsDB no devolvió el partido ni en la consulta directa'};
    }).sort((a,b)=>a.chronologicalNumber-b.chronologicalNumber);
  }
  function rollbackAfterMissing(tournament,tracking,missingNumber) {
    const removed=tournament.history.filter(r=>Number(r.chronologicalNumber)>missingNumber);
    if(!removed.length)return 0;
    const retained=tournament.history.filter(r=>Number(r.chronologicalNumber)<missingNumber).sort((a,b)=>Number(a.chronologicalNumber)-Number(b.chronologicalNumber));
    const fresh=M11.ShadowEngine.createTournament({id:tournament.id,name:tournament.name,leagueId:tournament.leagueId,country:tournament.country,season:tournament.season,base:tournament.base,experimentalQuota:tournament.experimentalQuota,targetPercent:tournament.targetPercent,studyMode:tournament.studyMode,createdAt:tournament.createdAt});
    tournament.strategies=fresh.strategies;tournament.processedEventIds=[];tournament.history=[];tournament.status='active';
    retained.forEach(r=>{
      const input={...r,externalId:r.externalId,chronologicalNumber:r.chronologicalNumber,result:r.result,experimentalQuota:r.experimentalQuota,resolutionSource:r.resolutionSource,homeTeam:r.homeTeam,awayTeam:r.awayTeam,kickoffUTC:r.kickoffUTC,sourceStatus:r.sourceStatus,sourceScore:r.sourceScore,plannedAt:r.plannedAt,eligibilityLockedAt:r.eligibilityLockedAt,processedAt:r.processedAt};
      if(r.label==='No registrada antes del inicio')M11.ShadowEngine.recordNoBet(tournament,input);else M11.ShadowEngine.processResult(tournament,input);
    });
    removed.forEach(r=>{if(r.label!=='No registrada antes del inicio')tracking.lockedEvents[r.externalId]={externalId:r.externalId,chronologicalNumber:r.chronologicalNumber,homeTeam:r.homeTeam,awayTeam:r.awayTeam,kickoffUTC:r.kickoffUTC,lockedAt:r.eligibilityLockedAt||r.plannedAt||r.processedAt,source:'rollback_after_missing_gap',status:'eligible'};});
    tracking.auditNotes.push({type:'missing_gap_rollback',at:new Date().toISOString(),missingNumber,restoredEventIds:removed.map(r=>r.externalId),message:`Se retiraron temporalmente ${removed.length} resultados posteriores al partido faltante #${missingNumber}. El capital y los niveles fueron reconstruidos hasta el último punto cronológico válido.`});
    return removed.length;
  }
  function suspendPlanAfterMissing(tournament,tracking,missingNumber) {
    const open=tracking.openPlan;
    if(!open||Number(open.chronologicalNumber)<=missingNumber)return false;
    tracking.deferredPlans[open.externalId]={...open,suspendedAt:new Date().toISOString(),blockedBy:missingNumber};
    if(!tracking.lockedEvents[open.externalId])tracking.lockedEvents[open.externalId]={externalId:open.externalId,chronologicalNumber:open.chronologicalNumber,homeTeam:open.homeTeam,awayTeam:open.awayTeam,kickoffUTC:open.kickoffUTC,lockedAt:open.plannedAt||new Date().toISOString(),source:'plan_suspended_by_missing_gap',status:'eligible'};
    tracking.openPlan=null;
    tracking.auditNotes.push({type:'plan_suspended_by_missing_gap',at:new Date().toISOString(),missingNumber,externalId:open.externalId,chronologicalNumber:open.chronologicalNumber,message:`La apuesta ficticia #${open.chronologicalNumber} dejó de mostrarse como activa mientras falta el partido #${missingNumber}. Conserva su elegibilidad previa en la cola.`});
    return true;
  }
  function upgradeProspectiveNoBets(tournament,tracking) {
    if(tournament.studyMode!=='prospective'||!tournament.history.some(r=>r.label==='No registrada antes del inicio'))return 0;
    const records=tournament.history.slice().sort((a,b)=>Number(a.chronologicalNumber)-Number(b.chronologicalNumber));
    const upgraded=records.filter(r=>r.label==='No registrada antes del inicio').length;
    const fresh=M11.ShadowEngine.createTournament({id:tournament.id,name:tournament.name,leagueId:tournament.leagueId,country:tournament.country,season:tournament.season,base:tournament.base,experimentalQuota:tournament.experimentalQuota,targetPercent:tournament.targetPercent,studyMode:tournament.studyMode,createdAt:tournament.createdAt});
    tournament.strategies=fresh.strategies;tournament.processedEventIds=[];tournament.history=[];tournament.status='active';
    records.forEach(r=>M11.ShadowEngine.processResult(tournament,{...r,externalId:r.externalId,chronologicalNumber:r.chronologicalNumber,result:r.result,experimentalQuota:r.experimentalQuota||tournament.experimentalQuota,resolutionSource:r.label==='No registrada antes del inicio'?'automatic_shadow_reconstruction':r.resolutionSource,homeTeam:r.homeTeam,awayTeam:r.awayTeam,kickoffUTC:r.kickoffUTC,sourceStatus:r.sourceStatus,sourceScore:r.sourceScore,plannedAt:r.plannedAt,eligibilityLockedAt:r.eligibilityLockedAt,processedAt:r.processedAt}));
    tracking.auditNotes.push({type:'prospective_shadow_reconstruction',at:new Date().toISOString(),upgraded,message:`Se reconstruyeron ${upgraded} resultados del laboratorio que habían quedado como no registrados. En Operación Sombra, los partidos numerados posteriores al corte pertenecen a la simulación automática.`});
    return upgraded;
  }
  function repairOutOfOrderNoBets(tournament,tracking) {
    if(tournament.studyMode==='retrospective'||!tracking.openPlan)return 0;
    const cutoff=Number(tracking.openPlan.chronologicalNumber), removable=tournament.history.filter(r=>Number(r.chronologicalNumber)>cutoff&&r.label==='No registrada antes del inicio');
    if(!removable.length)return 0;
    const ids=new Set(removable.map(r=>r.externalId));
    tournament.history=tournament.history.filter(r=>!ids.has(r.externalId));
    tournament.processedEventIds=tournament.processedEventIds.filter(id=>!ids.has(id));
    tracking.auditNotes.push({type:'chronology_repair',at:new Date().toISOString(),blockedBy:tracking.openPlan.externalId,restoredEventIds:Array.from(ids),message:'Se retiraron registros sin apuesta que habían quedado después de una operación anterior aún pendiente. No se modificó capital ni niveles.'});
    return ids.size;
  }
  function recoverLegacyQueuedEligibility(tournament,tracking) {
    if(tournament.studyMode==='retrospective')return 0;
    const recoveredIds=new Set();
    tracking.auditNotes.filter(n=>n.type==='chronology_repair').forEach(n=>(n.restoredEventIds||[]).forEach(id=>recoveredIds.add(id)));
    let recovered=0;
    recoveredIds.forEach(id=>{
      const record=tournament.history.find(r=>r.externalId===id&&r.label==='No registrada antes del inicio');
      const note=tracking.auditNotes.find(n=>n.type==='chronology_repair'&&(n.restoredEventIds||[]).includes(id));
      if(!tracking.lockedEvents[id]){tracking.lockedEvents[id]={externalId:id,chronologicalNumber:record&&record.chronologicalNumber,homeTeam:record&&record.homeTeam,awayTeam:record&&record.awayTeam,kickoffUTC:record&&record.kickoffUTC,lockedAt:note&&note.at||new Date().toISOString(),source:'legacy_chronology_queue',status:'eligible'};recovered+=1;}
      if(record){tournament.history=tournament.history.filter(r=>r.externalId!==id);tournament.processedEventIds=tournament.processedEventIds.filter(eventId=>eventId!==id);}
    });
    if(recovered)tracking.auditNotes.push({type:'eligibility_recovery',at:new Date().toISOString(),eventIds:Array.from(recoveredIds),message:'Se recuperó la elegibilidad de partidos que ya estaban numerados y en cola antes de conocerse su resultado.'});
    return recovered;
  }

  function assignChronology(tournament, events) {
    const tracking = trackingFor(tournament), retrospective=tournament.studyMode==='retrospective', created = new Date(tournament.createdAt).getTime();
    const ignored = new Set(tracking.ignoredBeforeStart || []), excluded = new Set(tracking.simultaneousExcluded || []);
    const newEvents = events.filter(e => e.externalId && !tracking.eventNumbers[e.externalId] && !ignored.has(e.externalId) && !excluded.has(e.externalId) && eligibleStatus(e));
    newEvents.forEach(e => { if (!retrospective && time(e) && time(e) < created) ignored.add(e.externalId); });
    const candidates = newEvents.filter(e => !ignored.has(e.externalId)).sort((a,b) => time(a)-time(b) || String(a.externalId).localeCompare(String(b.externalId)));
    const groups = new Map();
    candidates.forEach(e => { const k=keyTime(e); if(!groups.has(k))groups.set(k,[]); groups.get(k).push(e); });
    Array.from(groups.values()).forEach(group => {
      group.sort((a,b)=>String(a.externalId).localeCompare(String(b.externalId)));
      const selected=group[0]; tracking.eventNumbers[selected.externalId]=tracking.nextNumber++; rememberEvent(tracking,selected,tracking.eventNumbers[selected.externalId]); lockEligibility(tournament,tracking,selected,tracking.eventNumbers[selected.externalId],'chronology_assignment');
      group.slice(1).forEach(e=>excluded.add(e.externalId));
    });
    tracking.ignoredBeforeStart=Array.from(ignored);
    tracking.simultaneousExcluded=Array.from(excluded);
  }

  // Repara versiones anteriores que alcanzaron a numerar dos encuentros con
  // la misma hora. Conserva como oficial el que ya tenía el número menor
  // (decisión fijada primero), excluye el resto, renumera toda la secuencia y
  // reconstruye niveles/capital desde el historial retenido.
  function repairSimultaneousAssignments(tournament, events) {
    const tracking=trackingFor(tournament), byId=new Map(events.map(e=>[e.externalId,e]));
    const groups=new Map();
    events.filter(e=>e.externalId&&keyTime(e)).forEach(e=>{const k=keyTime(e);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(e);});
    const removed=new Set();
    groups.forEach(group=>{
      if(group.length<2)return;
      const numbered=group.filter(e=>Number.isFinite(Number(tracking.eventNumbers[e.externalId])))
        .sort((a,b)=>Number(tracking.eventNumbers[a.externalId])-Number(tracking.eventNumbers[b.externalId])||String(a.externalId).localeCompare(String(b.externalId)));
      const selected=numbered[0]||group.slice().sort((a,b)=>String(a.externalId).localeCompare(String(b.externalId)))[0];
      group.forEach(e=>{if(e.externalId!==selected.externalId&&tracking.eventNumbers[e.externalId])removed.add(e.externalId);});
    });
    if(!removed.size)return 0;
    removed.forEach(id=>{
      delete tracking.eventNumbers[id]; delete tracking.lockedEvents[id]; delete tracking.deferredPlans[id];
      if(tracking.openPlan&&tracking.openPlan.externalId===id)tracking.openPlan=null;
    });
    tracking.simultaneousExcluded=Array.from(new Set([...(tracking.simultaneousExcluded||[]),...removed]));
    ['pendingEvents','queuedEvents','missingEvents'].forEach(k=>{tracking[k]=(tracking[k]||[]).filter(e=>!removed.has(e.externalId));});
    const retainedIds=Object.keys(tracking.eventNumbers).sort((a,b)=>{
      const ea=byId.get(a)||tracking.eventCatalog[a]||{}, eb=byId.get(b)||tracking.eventCatalog[b]||{};
      const ta=time(ea)||new Date(ea.timestampUTC||0).getTime(), tb=time(eb)||new Date(eb.timestampUTC||0).getTime();
      return ta-tb||Number(tracking.eventNumbers[a])-Number(tracking.eventNumbers[b])||String(a).localeCompare(String(b));
    });
    retainedIds.forEach((id,index)=>{tracking.eventNumbers[id]=index+1;if(tracking.eventCatalog[id])tracking.eventCatalog[id].chronologicalNumber=index+1;if(tracking.lockedEvents[id])tracking.lockedEvents[id].chronologicalNumber=index+1;if(tracking.deferredPlans[id])tracking.deferredPlans[id].chronologicalNumber=index+1;});
    tracking.nextNumber=retainedIds.length+1;
    const oldHistory=(tournament.history||[]).filter(r=>!removed.has(r.externalId)&&tracking.eventNumbers[r.externalId])
      .map(r=>({...r,chronologicalNumber:tracking.eventNumbers[r.externalId]})).sort((a,b)=>a.chronologicalNumber-b.chronologicalNumber);
    const originalStatus=tournament.status;
    const fresh=M11.ShadowEngine.createTournament({id:tournament.id,name:tournament.name,leagueId:tournament.leagueId,country:tournament.country,season:tournament.season,base:tournament.base,experimentalQuota:tournament.experimentalQuota,targetPercent:tournament.targetPercent,studyMode:tournament.studyMode,createdAt:tournament.createdAt});
    tournament.strategies=fresh.strategies;tournament.processedEventIds=[];tournament.history=[];tournament.status='active';
    oldHistory.forEach(r=>{
      const input={...r,chronologicalNumber:r.chronologicalNumber,externalId:r.externalId,result:r.result,processedAt:r.processedAt};
      if(r.label==='No registrada antes del inicio')M11.ShadowEngine.recordNoBet(tournament,input);else M11.ShadowEngine.processResult(tournament,input);
    });
    if(originalStatus==='paused')tournament.status='paused';
    tracking.auditNotes.push({type:'simultaneity_repair',at:new Date().toISOString(),removedEventIds:Array.from(removed),message:`Se excluyeron ${removed.size} partido(s) numerados por error dentro de horarios simultáneos. La secuencia, los niveles y el capital fueron reconstruidos.`});
    return removed.size;
  }

  async function fetchTournamentEvents(tournament) {
    if(tournament.studyMode==='retrospective') {
      const seasonEvents=await M11.SportsApi.partidosTemporadaLiga(tournament.leagueId,tournament.season);
      return seasonEvents.map(raw=>M11.SportsApi.normalizeSportsDbEvent(raw,{leagueId:tournament.leagueId,leagueName:tournament.name,season:tournament.season})).filter(event=>event.externalId).sort((a,b)=>time(a)-time(b));
    }
    let next=[],past=[],providerError=null;
    try{[next,past]=await Promise.all([M11.SportsApi.proximosPartidosLiga(tournament.leagueId),M11.SportsApi.partidosAnterioresLiga(tournament.leagueId)]);}
    catch(error){providerError=error;}
    let daily=[];
    if(providerError||(!next.length&&!past.length)){
      try{daily=(await M11.SportsApi.partidosVentanaDiaria()).filter(raw=>String(raw.idLeague||'')===String(tournament.leagueId));}catch(_){}
    }
    const byId = new Map();
    [...next,...past,...daily].forEach(raw => {
      const event=M11.SportsApi.normalizeSportsDbEvent(raw,{leagueId:tournament.leagueId,leagueName:tournament.name,season:tournament.season});
      if(event.externalId)byId.set(event.externalId,event);
    });
    aiEventsForTournament(tournament).forEach(event=>byId.set(event.externalId,event));
    if(providerError&&!byId.size){
      const aiError=aiAgendaCache&&aiAgendaCache.error;
      throw new Error(`Proveedor deportivo no disponible${aiError?` y respaldo IA falló: ${aiError}`:'; el respaldo IA no encontró calendario verificable'}.`);
    }
    const tracking=trackingFor(tournament); tracking.relinkedThisSync=0;
    let open=tracking.openPlan, current=open&&byId.get(open.externalId);
    const missingIds=Object.entries(tracking.eventNumbers).filter(([id])=>!tournament.processedEventIds.includes(id)&&!byId.has(id)).sort((a,b)=>Number(a[1])-Number(b[1]));
    const exactId=missingIds.length?missingIds[0][0]:(open&&(!current||time(current)<=Date.now())?open.externalId:null);
    if(exactId&&typeof M11.SportsApi.consultarPartido==='function'){
      const raw=await M11.SportsApi.consultarPartido(exactId);
      if(raw){const exact=M11.SportsApi.normalizeSportsDbEvent(raw,{leagueId:tournament.leagueId,leagueName:tournament.name,season:tournament.season});if(exact.externalId)byId.set(exact.externalId,exact);}
      else {
        const replacement=await recoverChangedEventId(tournament,tracking,exactId,Array.from(byId.values()));
        if(replacement&&migrateTrackedEventId(tournament,tracking,exactId,replacement))byId.set(replacement.externalId,replacement);
      }
    }
    return Array.from(byId.values()).sort((a,b)=>time(a)-time(b));
  }

  async function syncTournament(tournament, force) {
    const tracking=trackingFor(tournament);
    if(tournament.status==='paused')return {ok:true,skipped:'paused',processed:0};
    if(!tournament.leagueId)return {ok:false,error:'El campeonato no tiene identificador de liga.'};
    if(!force && tracking.lastSyncAt && Date.now()-new Date(tracking.lastSyncAt).getTime()<CACHE_MS)return {ok:true,skipped:'cache',processed:0};
    try {
      const events=await fetchTournamentEvents(tournament);
      const ignoredBefore=(tracking.ignoredBeforeStart||[]).length, excludedBefore=(tracking.simultaneousExcluded||[]).length;
      const simultaneousRepaired=repairSimultaneousAssignments(tournament,events);
      assignChronology(tournament,events);
      events.forEach(event=>{const number=tracking.eventNumbers[event.externalId];if(number)rememberEvent(tracking,event,number);});
      const repaired=repairOutOfOrderNoBets(tournament,tracking);
      const recovered=recoverLegacyQueuedEligibility(tournament,tracking);
      tracking.missingEvents=missingNumberedEvents(tournament,tracking,events);
      const missingNumber=tracking.missingEvents.length?Number(tracking.missingEvents[0].chronologicalNumber):null;
      let rolledBack=missingNumber===null?0:rollbackAfterMissing(tournament,tracking,missingNumber);
      const suspendedPlan=missingNumber===null?false:suspendPlanAfterMissing(tournament,tracking,missingNumber);
      const reconstructed=upgradeProspectiveNoBets(tournament,tracking);
      events.forEach(event=>{const number=tracking.eventNumbers[event.externalId];if(number&&!tournament.processedEventIds.includes(event.externalId))lockEligibility(tournament,tracking,event,number,'observed_before_final');});
      let processed=0, scheduled=0, live=0, observedUnplanned=0, planned=0, queued=0;
      const pendingById=new Map((tracking.pendingEvents||[]).filter(e=>e&&e.externalId&&!tournament.processedEventIds.includes(e.externalId)).map(e=>[e.externalId,e]));
      if(tracking.openPlan&&tournament.processedEventIds.includes(tracking.openPlan.externalId))tracking.openPlan=null;
      let blockedNumber=tournament.studyMode==='retrospective'?null:[missingNumber,tracking.openPlan?Number(tracking.openPlan.chronologicalNumber):null].filter(Number.isFinite).sort((a,b)=>a-b)[0]??null;
      const queuedEvents=[];
      const orderedEvents=events.slice().sort((a,b)=>(tracking.eventNumbers[a.externalId]||Number.MAX_SAFE_INTEGER)-(tracking.eventNumbers[b.externalId]||Number.MAX_SAFE_INTEGER));
      orderedEvents.forEach(event => {
        const number=tracking.eventNumbers[event.externalId];
        if(!number || tournament.processedEventIds.includes(event.externalId))return;
        if(blockedNumber!==null&&number>blockedNumber){
          const queuedResult=eventResult(event);
          queuedEvents.push({externalId:event.externalId,chronologicalNumber:number,homeTeam:event.homeTeam,awayTeam:event.awayTeam,timestampUTC:event.timestampUTC,status:event.status,result:queuedResult,homeScore:event.homeScore,awayScore:event.awayScore,reason:`Esperando resolver el partido #${blockedNumber}`});queued+=1;
          return;
        }
        if(event.resultadoContradictorio){pendingById.set(event.externalId,{externalId:event.externalId,chronologicalNumber:number,homeTeam:event.homeTeam,awayTeam:event.awayTeam,timestampUTC:event.timestampUTC,fecha:event.fecha,hora:event.hora,homeScore:event.homeScore,awayScore:event.awayScore,status:event.status,detectedAt:new Date().toISOString()});if(tournament.studyMode!=='retrospective')blockedNumber=number;return;}
        pendingById.delete(event.externalId);
        if(event.status==='programado'||event.status==='en_curso'){if(event.status==='en_curso')live+=1;else scheduled+=1;if(tournament.studyMode!=='retrospective')blockedNumber=number;return;}
        const result=eventResult(event);
        if(!result)return;
        const score=event.homeScore===null||event.awayScore===null?'':`${event.homeScore}-${event.awayScore}`;
        const open=tracking.openPlan&&tracking.openPlan.externalId===event.externalId?tracking.openPlan:null;
        const locked=tracking.lockedEvents[event.externalId]&&tracking.lockedEvents[event.externalId].status==='eligible'?tracking.lockedEvents[event.externalId]:null;
        let response;
        if(tournament.studyMode==='retrospective'||tournament.studyMode==='prospective'||open||locked){response=M11.ShadowEngine.processResult(tournament,{externalId:event.externalId,chronologicalNumber:number,result,homeTeam:event.homeTeam,awayTeam:event.awayTeam,experimentalQuota:tournament.experimentalQuota,resolutionSource:tournament.studyMode==='retrospective'?'retrospective_reconstruction':open?'automatic_settlement':locked?'automatic_locked_settlement':'automatic_shadow_settlement',sourceStatus:event.status,sourceScore:score,plannedAt:open&&open.plannedAt,kickoffUTC:event.timestampUTC,plannedAmounts:open&&open.amounts||locked&&currentAmounts(tournament,number),eligibilityLockedAt:locked&&locked.lockedAt,processedAt:new Date().toISOString()});if(response.applied)processed+=1;if(locked)locked.status='settled';}
        else {response=M11.ShadowEngine.recordNoBet(tournament,{externalId:event.externalId,chronologicalNumber:number,result,homeTeam:event.homeTeam,awayTeam:event.awayTeam,sourceStatus:event.status,sourceScore:score,kickoffUTC:event.timestampUTC,processedAt:new Date().toISOString()});if(response.applied)observedUnplanned+=1;}
        if(open){tracking.openPlan=null;blockedNumber=null;}
      });
      tracking.pendingEvents=Array.from(pendingById.values()).filter(p=>blockedNumber===null||p.chronologicalNumber<=blockedNumber).sort((a,b)=>a.chronologicalNumber-b.chronologicalNumber);
      tracking.queuedEvents=queuedEvents.sort((a,b)=>a.chronologicalNumber-b.chronologicalNumber);
      if(missingNumber!==null)rolledBack+=rollbackAfterMissing(tournament,tracking,missingNumber);
      if(tournament.studyMode!=='retrospective')refreshOpenPlan(tournament,tracking);
      if(tournament.studyMode!=='retrospective'&&!tracking.openPlan&&tournament.status==='active'){
        const pendingIds=new Set(tracking.pendingEvents.map(e=>e.externalId));
        const candidate=events.filter(e=>e.status==='programado'&&time(e)>Date.now()&&!tournament.processedEventIds.includes(e.externalId)&&!pendingIds.has(e.externalId)&&tracking.eventNumbers[e.externalId]&&tracking.eventNumbers[e.externalId]===blockedNumber)[0];
        if(candidate){tracking.openPlan=planFor(tournament,candidate,tracking.eventNumbers[candidate.externalId]);const deferred=tracking.deferredPlans[candidate.externalId];if(deferred){tracking.openPlan.plannedAt=deferred.plannedAt||tracking.openPlan.plannedAt;tracking.openPlan.originallyPlannedAt=deferred.plannedAt||null;delete tracking.deferredPlans[candidate.externalId];}planned=1;}
      }
      const pendingReview=tracking.pendingEvents.length;
      tracking.lastSyncAt=new Date().toISOString(); tracking.lastError=null; tracking.lastEventsFound=events.length; tracking.pendingReview=pendingReview;
      return {ok:true,processed,scheduled,live,planned,observedUnplanned,queued,repaired,recovered,reconstructed,simultaneousRepaired,relinked:tracking.relinkedThisSync||0,rolledBack,suspendedPlan,missing:tracking.missingEvents.length,eventsFound:events.length,pendingReview,ignoredBeforeStart:Math.max(0,(tracking.ignoredBeforeStart||[]).length-ignoredBefore),simultaneousExcluded:Math.max(0,(tracking.simultaneousExcluded||[]).length-excludedBefore)};
    } catch(error) { tracking.lastSyncAt=new Date().toISOString(); tracking.lastError=error.message || 'No fue posible sincronizar.'; return {ok:false,error:tracking.lastError,processed:0}; }
  }

  async function syncAll(options) {
    const experiment=M11.ShadowStore.load(), results=[];
    // La sincronización normal no consume IA. Solo la acción expresamente
    // llamada "Sincronizar ... con IA" puede habilitar este respaldo.
    if(options&&options.useAiFallback)await loadAiAgenda(experiment);else aiAgendaCache=null;
    for(const tournament of experiment.tournaments) results.push({tournamentId:tournament.id, ...(await syncTournament(tournament,!!(options&&options.force)))});
    M11.ShadowStore.save(experiment);
    results.aiFallback={ok:!!(aiAgendaCache&&!aiAgendaCache.error),matches:aiAgendaCache&&aiAgendaCache.matches?aiAgendaCache.matches.length:0,error:aiAgendaCache&&aiAgendaCache.error||null};
    return results;
  }
  function resolvePending(tournamentId,eventId,result) {
    if(!['draw','not_draw','cancelled','suspended'].includes(result))throw new Error('Resultado de revisión inválido.');
    const experiment=M11.ShadowStore.load(), tournament=experiment.tournaments.find(t=>t.id===String(tournamentId));
    if(!tournament)throw new Error('Campeonato sombra no encontrado.');
    const tracking=trackingFor(tournament), pending=[...(tracking.pendingEvents||[]),...(tracking.missingEvents||[]),...(tracking.queuedEvents||[])].find(e=>e.externalId===String(eventId));
    if(!pending)throw new Error('El partido ya no está pendiente de revisión.');
    if(tracking.openPlan&&Number(pending.chronologicalNumber)>Number(tracking.openPlan.chronologicalNumber))throw new Error(`Primero debe resolverse el partido #${tracking.openPlan.chronologicalNumber}. La revisión #${pending.chronologicalNumber} permanece en espera cronológica.`);
    const earlierPending=tracking.pendingEvents.filter(e=>e.externalId!==pending.externalId&&Number(e.chronologicalNumber)<Number(pending.chronologicalNumber)).sort((a,b)=>a.chronologicalNumber-b.chronologicalNumber)[0];
    if(earlierPending)throw new Error(`Primero debe resolverse el partido #${earlierPending.chronologicalNumber}.`);
    const open=tracking.openPlan&&tracking.openPlan.externalId===pending.externalId?tracking.openPlan:null, locked=tracking.lockedEvents[pending.externalId]&&tracking.lockedEvents[pending.externalId].status==='eligible'?tracking.lockedEvents[pending.externalId]:null;
    const response=(tournament.studyMode==='retrospective'||tournament.studyMode==='prospective'||open||locked?M11.ShadowEngine.processResult:M11.ShadowEngine.recordNoBet)(tournament,{externalId:pending.externalId,chronologicalNumber:pending.chronologicalNumber,result,homeTeam:pending.homeTeam,awayTeam:pending.awayTeam,experimentalQuota:tournament.experimentalQuota,resolutionSource:open?'manual_review_planned':locked?'manual_review_locked':'manual_review',sourceStatus:pending.status,sourceScore:pending.homeScore===null||pending.awayScore===null?'':`${pending.homeScore}-${pending.awayScore}`,plannedAt:open&&open.plannedAt,kickoffUTC:pending.timestampUTC,plannedAmounts:open&&open.amounts||locked&&currentAmounts(tournament,pending.chronologicalNumber),eligibilityLockedAt:locked&&locked.lockedAt,processedAt:new Date().toISOString()});
    if(!response.applied)throw new Error(response.reason==='tournament_closed'?'El campeonato ya está cerrado o alcanzó la meta.':'No fue posible aplicar la revisión.');
    tracking.pendingEvents=(tracking.pendingEvents||[]).filter(e=>e.externalId!==pending.externalId);
    tracking.missingEvents=(tracking.missingEvents||[]).filter(e=>e.externalId!==pending.externalId);
    tracking.queuedEvents=(tracking.queuedEvents||[]).filter(e=>e.externalId!==pending.externalId);
    if(open)tracking.openPlan=null;
    if(locked)locked.status='settled';
    tracking.pendingReview=tracking.pendingEvents.length;
    M11.ShadowStore.save(experiment);
    return response;
  }
  M11.ShadowSync={VERSION:'S29',CACHE_MS,syncAll,syncTournament,assignChronology,repairSimultaneousAssignments,resolvePending};
})(window.M11);
