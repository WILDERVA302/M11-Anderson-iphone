/* =========================================================
   M11 · casas-ui.js  (Sprint V1.0.5, sección 4 — con respaldo file://)
   -----------------------------------------------------------
   Carga el catálogo de casas de apuestas para que events.js arme el
   selector de país -> casas. Nunca decide nada del Modelo M11; solo
   lee datos. El motor no se toca para actualizar este catálogo — se
   edita app/data/bookmakers.json (y su respaldo, ver abajo)
   directamente.

   Dos fuentes, en este orden:
   1) fetch('data/bookmakers.json') — la fuente PRINCIPAL y editable.
      Funciona sirviendo la app por http(s) (localhost, un servidor
      real, o dentro del WebView de Capacitor).
   2) window.M11_BOOKMAKERS (app/data/bookmakers-datos.js) — el
      RESPALDO incorporado. Se usa cuando el fetch falla por
      cualquier motivo, en particular al abrir la app directamente
      como archivo local (file:///C:/...), donde los navegadores
      bloquean fetch() a archivos del disco por seguridad aunque el
      archivo exista y sea válido — un <script> normal, en cambio, sí
      se carga bajo file://, así que ese respaldo llega igual.

   Si NINGUNA de las dos fuentes da un catálogo utilizable, el estado
   queda en 'error' — nunca se deja el selector de país vacío sin
   explicación (ver getEstado(), usado por events.js para mostrar un
   aviso visible en vez de fallar en silencio).
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  let catalogo = null;
  let estado = 'sin_cargar'; // 'sin_cargar' | 'cargando' | 'ok_json' | 'ok_respaldo' | 'error'
  let promesaCarga = null;

  function _catalogoValido(data) {
    return !!(data && data.paises && typeof data.paises === 'object' && Object.keys(data.paises).length > 0);
  }

  async function cargarCatalogo() {
    if (catalogo) return catalogo;
    if (promesaCarga) return promesaCarga;
    estado = 'cargando';
    promesaCarga = (async () => {
      // 1) Fuente principal: el archivo .json editable. Bajo file://
      // esto normalmente ni siquiera llega a resolver — el propio
      // fetch() lanza un error (o el navegador lo rechaza), y cae
      // directo al catch de abajo.
      try {
        const r = await fetch('data/bookmakers.json');
        if (r && r.ok) {
          const data = await r.json();
          if (_catalogoValido(data)) {
            catalogo = data;
            estado = 'ok_json';
            return catalogo;
          }
        }
      } catch (e) { /* fetch bloqueado (típicamente file://) o archivo no encontrado: se sigue al respaldo */ }

      // 2) Respaldo incorporado (siempre disponible, cargado por
      // <script> antes que este archivo — ver index.html).
      if (_catalogoValido(window.M11_BOOKMAKERS)) {
        catalogo = window.M11_BOOKMAKERS;
        estado = 'ok_respaldo';
        return catalogo;
      }

      // 3) Ninguna de las dos fuentes dio un catálogo utilizable.
      catalogo = null;
      estado = 'error';
      return null;
    })();
    return promesaCarga;
  }

  function getEstado() { return estado; }

  function paisesDisponibles() {
    return catalogo ? Object.keys(catalogo.paises) : [];
  }

  function casasDePais(pais) {
    const entrada = catalogo && catalogo.paises && catalogo.paises[pais];
    return (entrada && Array.isArray(entrada.casas)) ? entrada.casas.filter(c => c.activo !== false) : [];
  }

  M11.CasasUI = { cargarCatalogo, paisesDisponibles, casasDePais, getEstado };

})(window.M11);
