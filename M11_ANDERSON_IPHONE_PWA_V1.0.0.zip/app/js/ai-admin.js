/* Administrador IA M11 V2.1.3 — agenda, auditoría, respaldo y consultas.
   Nunca modifica capital, niveles, apuestas ni resultados por una respuesta IA. */
window.M11 = window.M11 || {};
(function (M11) {
  'use strict';
  const CONFIG_KEY='m11_ai_admin_config_v1';
  const MIGRATION_KEY='m11_ai_migration_v210';
  const AUTO_BACKUP_KEY='m11_ai_pre_migration_backup_v210';
  const EXCLUDED_KEYS=['m11_usuarios_locales_v1','m11_usuario_actual_v1','m11Session'];
  let selectedDay='today';

  const $=s=>document.querySelector(s);
  const escapeHtml=v=>String(v==null?'':v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const money=n=>new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(Number(n)||0);
  function bogotaParts(value){
    const d=value instanceof Date?value:new Date(value);
    const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Bogota',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(d);
    const out={};parts.forEach(p=>out[p.type]=p.value);return out;
  }
  function dayKey(date){const p=bogotaParts(date);return `${p.year}-${p.month}-${p.day}`;}
  function targetKey(){const d=new Date();if(selectedDay==='tomorrow')d.setTime(d.getTime()+86400000);return dayKey(d);}
  function formatTime(value,fallback){
    if(value){const p=bogotaParts(value);return `${p.hour}:${p.minute}`;}
    return fallback||'—';
  }
  function readConfig(){try{return JSON.parse(localStorage.getItem(CONFIG_KEY)||'{}');}catch(_){return{};}}
  function saveConfig(value){localStorage.setItem(CONFIG_KEY,JSON.stringify(value));}
  function safeSnapshot(){
    const data={};
    Object.keys(localStorage).sort().forEach(key=>{if(!EXCLUDED_KEYS.includes(key)&&key!==AUTO_BACKUP_KEY)data[key]=localStorage.getItem(key);});
    return {format:'m11-backup',schema:2,version:'2.1.0',createdAt:new Date().toISOString(),timeZone:'America/Bogota',data};
  }
  function migrate(){
    if(localStorage.getItem(MIGRATION_KEY)==='done')return;
    try{localStorage.setItem(AUTO_BACKUP_KEY,JSON.stringify(safeSnapshot()));localStorage.setItem(MIGRATION_KEY,'done');}
    catch(err){console.warn('No fue posible crear la copia automática previa a V2.1.0',err);}
  }
  async function downloadBackup(){
    const payload=safeSnapshot();
    const filename=`M11_respaldo_${dayKey(new Date())}.json`;
    const content=JSON.stringify(payload,null,2);
    const status=$('#aiBackupStatus');
    try{
      const plugins=window.Capacitor&&window.Capacitor.Plugins;
      if(plugins&&plugins.Filesystem&&plugins.Share){
        const saved=await plugins.Filesystem.writeFile({path:filename,data:content,directory:'CACHE',encoding:'utf8'});
        await plugins.Share.share({title:'Copia de seguridad M11',text:'Guarde este archivo para recuperar su operación M11.',url:saved.uri,dialogTitle:'Guardar o compartir copia M11'});
        if(status)status.textContent='Copia preparada. Confirme que la guardó o compartió antes de salir.';
        return;
      }
      const file=new File([content],filename,{type:'application/json'});
      if(navigator.canShare&&navigator.canShare({files:[file]})){
        await navigator.share({title:'Copia de seguridad M11',files:[file]});
        if(status)status.textContent='Copia compartida correctamente.';
        return;
      }
      const blob=new Blob([content],{type:'application/json'});
      const url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
      if(status)status.textContent=`Compruebe en Descargas que exista ${filename}.`;
    }catch(err){
      if(err&&/cancel/i.test(String(err.message||err))) {if(status)status.textContent='No se guardó la copia porque se cerró la ventana de compartir.';return;}
      if(status)status.textContent='No fue posible guardar la copia: '+(err.message||err);
    }
  }
  async function importBackup(file){
    const text=await file.text();let payload;
    try{payload=JSON.parse(text);}catch(_){throw new Error('El archivo no contiene una copia M11 válida.');}
    if(!payload||payload.format!=='m11-backup'||!payload.data||typeof payload.data!=='object')throw new Error('El archivo no corresponde a una copia de seguridad M11.');
    if(!confirm('Esta restauración reemplazará los datos operativos actuales por los de la copia. ¿Desea continuar?'))return false;
    const emergency=JSON.stringify(safeSnapshot());
    try{
      Object.keys(localStorage).forEach(k=>{if(!EXCLUDED_KEYS.includes(k))localStorage.removeItem(k);});
      Object.entries(payload.data).forEach(([k,v])=>{if(!EXCLUDED_KEYS.includes(k))localStorage.setItem(k,String(v));});
      localStorage.setItem('m11_ai_emergency_before_restore',emergency);
      localStorage.setItem(MIGRATION_KEY,'done');
      alert('Copia restaurada. El Asistente se reiniciará para cargar los datos.');location.reload();return true;
    }catch(err){throw new Error('No se pudo restaurar la copia: '+err.message);}
  }
  function allCalendars(){
    const results=[];
    Object.keys(localStorage).filter(k=>/^m11Calendario(?:__|$)/.test(k)).forEach(key=>{
      try{const list=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(list))list.forEach(p=>results.push({...p,_storageKey:key}));}catch(_){}
    });
    if(M11.Calendario&&M11.Calendario.listar)try{M11.Calendario.listar().forEach(p=>results.push(p));}catch(_){}
    return results;
  }
  function normalizeMatch(p){
    const timestamp=p.timestampUTC||p.kickoffUTC||null;
    const date=timestamp?dayKey(timestamp):String(p.fecha||'');
    return {id:String(p.externalId||p.id||`${date}-${p.hora}-${p.equipoLocal}-${p.equipoVisitante}`),date,time:formatTime(timestamp,p.hora),timestampUTC:timestamp,home:p.equipoLocal||p.homeTeam||p.home||'',away:p.equipoVisitante||p.awayTeam||p.away||'',competition:p.torneo||p.competition||p.leagueName||'Campeonato M11',leagueId:p.leagueId||null,status:p.estado||p.status||'programado',provider:p.provider||'local',sourceUrls:Array.isArray(p.sourceUrls)?p.sourceUrls:[],operationId:p.operationId||null,chronologicalNumber:p.numeroCronologico||p.chronologicalNumber||null};
  }
  function normalizedName(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
  function importVerifiedAgenda(matches){
    const operations=M11.Operaciones&&M11.Operaciones.listar?M11.Operaciones.listar():[];
    let imported=0;
    operations.forEach(op=>{
      const opName=normalizedName(op.nombre||op.leagueName),opLeague=String(op.leagueId||'');
      const selected=(matches||[]).filter(m=>{
        if(opLeague&&m.leagueId&&String(m.leagueId)===opLeague)return true;
        const competition=normalizedName(m.competition);return competition&&opName&&(competition.includes(opName)||opName.includes(competition));
      });
      if(!selected.length)return;
      const key=realKey('m11Calendario',op.id),calendar=readJson(key,[]),ids=new Set(calendar.map(p=>String(p.externalId||p.id)));
      let nextNumber=Math.max(0,...calendar.map(p=>Number(p.numeroCronologico)||0))+1;
      selected.slice().sort((a,b)=>String(a.timestampUTC||`${a.date}T${a.time}`).localeCompare(String(b.timestampUTC||`${b.date}T${b.time}`))).forEach(m=>{
        const id=String(m.id||`${m.date}-${m.time}-${m.home}-${m.away}`);if(ids.has(id))return;
        calendar.push({id:`ia-${id}`,externalId:id,provider:'IA privada',operationId:op.id,torneo:op.nombre||m.competition,equipoLocal:m.home,equipoVisitante:m.away,fecha:m.date,hora:m.time,timestampUTC:m.timestampUTC||null,estado:m.status||'programado',numeroCronologico:nextNumber++,resultadoSugerido:null,resultadoContradictorio:false,fuentes:m.sourceUrls||[]});ids.add(id);imported+=1;
      });
      localStorage.setItem(key,JSON.stringify(calendar));
    });
    if(imported&&M11.Operaciones&&M11.Operaciones.getActiva){
      const active=M11.Operaciones.getActiva(),key=active&&realKey('m11Calendario',active.id),all=key?readJson(key,[]):[];
      const ai=all.filter(p=>p.provider==='IA privada');if(ai.length&&M11.Calendario&&M11.Calendario.fusionarPartidosApi)M11.Calendario.fusionarPartidosApi(ai,{});
    }
    return imported;
  }
  function localAgenda(){
    const map=new Map();allCalendars().map(normalizeMatch).filter(m=>m.date===targetKey()&&m.home&&m.away).forEach(m=>{const old=map.get(m.id);if(!old||old.status==='programado')map.set(m.id,m);});
    return [...map.values()].sort((a,b)=>(a.timestampUTC?new Date(a.timestampUTC).getTime():Date.parse(`${a.date}T${a.time}:00-05:00`))-(b.timestampUTC?new Date(b.timestampUTC).getTime():Date.parse(`${b.date}T${b.time}:00-05:00`)));
  }
  function readJson(key,fallback){try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):fallback;}catch(_){return fallback;}}
  function realKey(base,operationId){return !operationId||operationId==='op-migrada-1'?base:`${base}__${operationId}`;}
  function strategyTotals(value){
    const names=['general','pares','impares'],s=value&&typeof value==='object'?value:{};
    return names.reduce((out,name)=>{const item=s[name]||{};out.available+=Number(item.disponible)||0;out.committed+=Number(item.comprometido)||0;out.levels[name]=Number(item.nivel)||null;return out;},{available:0,committed:0,levels:{}});
  }
  function recordDay(record){return dayKey(record&&record.fechaHora||record&&record.fechaRegistro||record&&record.fechaHoraPartido||new Date(0));}
  function dailyFinancial(records,date,pending){
    const bets=records.filter(r=>recordDay(r)===date&&r.tipoOriginal==='apostada');
    const settled=bets.filter(r=>['empate','no_empate','cancelado','suspendido'].includes(r.resultado));
    const amount=bets.reduce((sum,r)=>sum+(Number(r.totalApostado)||0),0);
    const returned=settled.reduce((sum,r)=>sum+(Number(r.retornoTotal)||0),0);
    const profit=settled.reduce((sum,r)=>sum+(Number(r.gananciaNetaTotal)||0),0);
    const pendingList=[];
    if(pending&&pending.estado==='PENDIENTE_RESULTADO'&&dayKey(pending.fechaRegistroApuesta||new Date())===date){
      pendingList.push({match:pending.partidoSnapshot?`${pending.partidoSnapshot.equipoLocal} vs ${pending.partidoSnapshot.equipoVisitante}`:'Partido pendiente',amount:Number(pending.montoApostado)||0,registeredAt:pending.fechaRegistroApuesta||null});
    }
    return {date,betCount:bets.length+pendingList.length,settledCount:settled.length,pendingCount:pendingList.length,totalBet:amount+pendingList.reduce((s,p)=>s+p.amount,0),settledBet:amount,pendingBet:pendingList.reduce((s,p)=>s+p.amount,0),totalReturned:returned,profitLoss:profit,returnOnSettledPercent:amount?profit/amount*100:null,pendingMatches:pendingList};
  }
  function financialSnapshot(){
    const operations=M11.Operaciones&&M11.Operaciones.listar?M11.Operaciones.listar():[];
    const today=dayKey(new Date()),yesterday=dayKey(new Date(Date.now()-86400000));
    const byOperation=operations.map(op=>{
      const records=readJson(realKey('m11Libro',op.id),[]);
      const pending=readJson(realKey('m11DecisionPartido',op.id),null);
      const strategyState=readJson(realKey('m11EstrategiasEngine',op.id),null);
      const balances=strategyTotals(strategyState);
      const historicalProfit=records.reduce((sum,r)=>sum+(typeof r.gananciaNetaTotal==='number'?r.gananciaNetaTotal:0),0);
      const storedCurrent=balances.available+balances.committed;
      const declaredInitial=Number(op.capitalInicial)||null;
      const initial=declaredInitial!==null?declaredInitial:(strategyState?storedCurrent-historicalProfit:null);
      const current=strategyState?storedCurrent:(initial||0);
      const totalBet=records.reduce((sum,r)=>sum+(Number(r.totalApostado)||0),0);
      const throughYesterday=records.filter(r=>recordDay(r)<=yesterday).reduce((sum,r)=>sum+(typeof r.gananciaNetaTotal==='number'?r.gananciaNetaTotal:0),0);
      return {id:op.id,name:op.nombre,status:op.estado,initialCapital:initial,availableCapital:balances.available,committedCapital:balances.committed,currentCapital:current,profitLoss:initial!==null?current-initial:historicalProfit,returnOnInitialPercent:initial?(current-initial)/initial*100:null,totalBet,historicalProfit,capitalAtYesterdayClose:initial!==null?initial+throughYesterday:null,profitLossThroughYesterday:throughYesterday,today:dailyFinancial(records,today,pending),yesterday:dailyFinancial(records,yesterday,pending),levels:balances.levels,pendingResult:pending&&pending.estado==='PENDIENTE_RESULTADO'?{amount:Number(pending.montoApostado)||0,registeredAt:pending.fechaRegistroApuesta||null,match:pending.partidoSnapshot?`${pending.partidoSnapshot.equipoLocal} vs ${pending.partidoSnapshot.equipoVisitante}`:null}:null};
    });
    const sum=field=>byOperation.reduce((total,op)=>total+(Number(op[field])||0),0);
    const combineDay=field=>byOperation.reduce((out,op)=>{const d=op[field];out.betCount+=d.betCount;out.settledCount+=d.settledCount;out.pendingCount+=d.pendingCount;out.totalBet+=d.totalBet;out.settledBet+=d.settledBet;out.pendingBet+=d.pendingBet;out.totalReturned+=d.totalReturned;out.profitLoss+=d.profitLoss;out.pendingMatches.push(...d.pendingMatches.map(p=>({...p,championship:op.name})));return out;},{date:field==='today'?today:yesterday,betCount:0,settledCount:0,pendingCount:0,totalBet:0,settledBet:0,pendingBet:0,totalReturned:0,profitLoss:0,pendingMatches:[]});
    const assigned=sum('initialCapital'),current=sum('currentCapital'),maxCapital=byOperation.reduce((m,op)=>Math.max(m,op.committedCapital),0);
    return {scope:'All real M11 operations stored on this device; never an external betting or bank account.',generatedAt:new Date().toISOString(),timeZone:'America/Bogota',operationCount:byOperation.length,operationsWithoutInitialCapital:byOperation.filter(op=>op.initialCapital===null).map(op=>op.name),totals:{assignedCapital:assigned,availableCapital:sum('availableCapital'),committedCapital:sum('committedCapital'),currentCapital:current,profitLoss:current-assigned,returnOnAssignedPercent:assigned?(current-assigned)/assigned*100:null,totalBetHistorical:sum('totalBet'),maximumCurrentlyCommittedInOneChampionship:maxCapital},throughYesterday:{capital:byOperation.reduce((s,op)=>s+(Number(op.capitalAtYesterdayClose)||0),0),profitLoss:byOperation.reduce((s,op)=>s+(Number(op.profitLossThroughYesterday)||0),0)},today:combineDay('today'),yesterday:combineDay('yesterday'),byOperation};
  }
  function recommendedAmount(match){
    if(!match.operationId||!M11.Store||!M11.Store.getDecisionDeOperacion)return null;
    try{
      if(M11.Store.getDecisionDeOperacion(match.operationId))return null;
      const ops=M11.Operaciones&&M11.Operaciones.listar?M11.Operaciones.listar():[];
      const op=ops.find(x=>x.id===match.operationId);if(!op)return null;
      const key=`m11EstrategiasEngine__${match.operationId}`;const e=JSON.parse(localStorage.getItem(key)||'null');if(!e)return null;
      const names=['general',Number(match.chronologicalNumber)%2===0?'pares':'impares'];
      return names.reduce((sum,n)=>sum+(e[n]&&!e[n].bloqueada&&M11.Engine?M11.Engine.montoPorNivel(e[n].nivel):0),0);
    }catch(_){return null;}
  }
  function buildAlerts(matches){
    const alerts=[];
    for(let i=1;i<matches.length;i++){
      const a=matches[i-1],b=matches[i];
      const am=a.timestampUTC?new Date(a.timestampUTC).getTime():Date.parse(`${a.date}T${a.time}:00-05:00`);
      const bm=b.timestampUTC?new Date(b.timestampUTC).getTime():Date.parse(`${b.date}T${b.time}:00-05:00`);
      const gap=Math.round((bm-am)/60000);
      if(gap===0)alerts.push(`Partidos simultáneos a las ${b.time}: ${a.home} vs ${a.away} y ${b.home} vs ${b.away}.`);
      else if(gap>0&&gap<=120)alerts.push(`Partidos seguidos con ${gap} minutos de diferencia: ${a.home} vs ${a.away} → ${b.home} vs ${b.away}.`);
    }
    return alerts;
  }
  function renderAgenda(matches){
    const box=$('#aiAgenda'),alerts=$('#aiAlerts');if(!box)return;
    const title=selectedDay==='today'?'hoy':'mañana';
    $('#aiGreeting').textContent=`${new Date().getHours()<12?'Buenos días':new Date().getHours()<18?'Buenas tardes':'Buenas noches'}, Wilder`;
    $('#aiSummary').textContent=matches.length?`Encontré ${matches.length} partido${matches.length===1?'':'s'} de sus campeonatos para ${title}. Puede registrar una apuesta desde el inicio del día, sin esperar la alarma de 15 minutos.`:`No hay partidos locales confirmados para ${title}. Use “Consultar y verificar con IA” para buscar cambios o encuentros que el proveedor no haya entregado.`;
    if(!matches.length){box.innerHTML='<p class="legal-note">La agenda está vacía en el calendario local.</p>';alerts.innerHTML='<p class="legal-note">Sin alertas calculables.</p>';return;}
    box.innerHTML=matches.map(m=>{const amount=recommendedAmount(m);const placed=m.status==='finalizado'||m.status==='cancelado'||m.status==='suspendido';return `<article class="ai-match ${placed?'closed':''}"><time>${escapeHtml(m.time)}</time><div><strong>${escapeHtml(m.home)} vs ${escapeHtml(m.away)}</strong><small>${escapeHtml(m.competition)} · ${escapeHtml(m.status)}</small>${amount!=null?`<span class="ai-amount">Apuesta M11 prevista: ${money(amount)}</span>`:''}</div><span class="ai-source">${escapeHtml(m.provider)}</span></article>`;}).join('');
    const list=buildAlerts(matches);alerts.innerHTML=list.length?`<ul>${list.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`:'<p class="legal-note">No se detectaron partidos simultáneos ni separados por dos horas o menos.</p>';
  }
  function context(matches,includeFinancial=true){
    const slots=M11.LabHub&&M11.LabHub.load?M11.LabHub.load():[];
    const data={owner:'Wilder',timeZone:'America/Bogota',currentDateTime:new Date().toISOString(),date:targetKey(),day:selectedDay,championships:slots.map(s=>({slot:s.slot,name:s.name,country:s.country,leagueId:s.leagueId})),localAgenda:matches,guardrails:{neverPlaceBet:true,neverChangeMoney:true,neverSettleWithoutConfirmation:true,requireSourcesOnlyForExternalFacts:true}};
    if(includeFinancial){data.realOperation=financialSnapshot();data.definitions={realOperation:'Registros internos de Operación Real en M11, no una cuenta de una casa de apuestas ni una cuenta bancaria.',assignedCapital:'Capital inicial distribuido entre los campeonatos.',currentCapital:'Capital disponible más capital comprometido en apuestas pendientes.',committedCapital:'Dinero de apuestas registradas que esperan resultado.',profitLoss:'Capital actual menos capital inicial.'};}
    return data;
  }
  async function callService(action,payload){
    const url=(readConfig().serviceUrl||'').trim();if(!url)throw new Error('Primero configure la dirección del servicio privado en Configuración.');
    const ctrl=new AbortController(),timeout=['daily_agenda','verify_results'].includes(action)?110000:60000,timer=setTimeout(()=>ctrl.abort(),timeout);
    try{
      const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...payload}),signal:ctrl.signal});
      let data=null;try{data=await response.json();}catch(_){}
      if(!response.ok)throw new Error((data&&data.error)||`El servicio respondió ${response.status}.`);
      if(!data||data.ok===false)throw new Error(data&&data.error||'Respuesta inválida del servicio.');return data;
    }catch(err){if(err.name==='AbortError')throw new Error('La consulta tardó demasiado. Intente nuevamente.');throw err;}finally{clearTimeout(timer);}
  }
  async function consult(){
    const status=$('#aiStatus'),local=localAgenda();status.textContent='La IA está buscando, comparando horarios y revisando cambios…';$('#aiConsultBtn').disabled=true;
    try{const data=await callService('daily_agenda',{context:context(local,false)});const matches=Array.isArray(data.matches)?data.matches.map(normalizeMatch):local,imported=importVerifiedAgenda(matches);renderAgenda(matches);status.textContent=`${data.summary||`Consulta terminada. ${matches.length} partido(s) verificado(s).`}${imported?` ${imported} encuentro(s) incorporado(s) al calendario M11.`:''}`;if(M11.AIActions)await M11.AIActions.downloadAnswer(`Partidos M11 — ${selectedDay==='today'?'hoy':'mañana'}`,matches.length?matches.map((m,i)=>`${i+1}. ${m.time} — ${m.home} vs ${m.away} (${m.competition})`).join('\n'):status.textContent,`M11_partidos_${selectedDay}_${targetKey()}.png`);}
    catch(err){renderAgenda(local);status.textContent=`No fue posible consultar la IA: ${err.message} La agenda local continúa disponible y no se modificó ningún dato.`;}
    finally{$('#aiConsultBtn').disabled=false;}
  }
  async function ask(){
    const q=$('#aiQuestion').value.trim(),box=$('#aiAnswer');if(!q)return;
    box.classList.remove('hidden');box.textContent='Consultando…';$('#aiAskBtn').disabled=true;
    try{
      const scheduleQuestion=/(partidos?|juegos?|encuentros?|agenda|calendario)/i.test(q)&&/(hoy|mañana|cronol[oó]g|fecha|hora|actualiza|sincroniza)/i.test(q);
      if(scheduleQuestion){
        if(/mañana/i.test(q))selectedDay='tomorrow';else if(/hoy/i.test(q))selectedDay='today';
        $('#aiTodayBtn').classList.toggle('active',selectedDay==='today');$('#aiTomorrowBtn').classList.toggle('active',selectedDay==='tomorrow');
        const local=localAgenda();box.textContent='Buscando en internet y ordenando los partidos. Esta consulta puede tardar hasta dos minutos…';
        const data=await callService('daily_agenda',{context:context(local,false)});
        const matches=Array.isArray(data.matches)?data.matches.map(normalizeMatch):local;renderAgenda(matches);
        if(!matches.length)box.textContent=data.summary||`No encontré partidos confirmados para ${selectedDay==='today'?'hoy':'mañana'} en los campeonatos configurados.`;
        else box.textContent=`${data.summary||`Encontré ${matches.length} partido${matches.length===1?'':'s'}.`}\n\n${matches.map((m,i)=>`${i+1}. ${m.time} — ${m.home} vs ${m.away} (${m.competition})`).join('\n')}`;
      }else{
        const matches=localAgenda(),data=await callService('question',{question:q,context:context(matches,true)});box.textContent=data.answer||'La IA no devolvió una respuesta.';
      }
      if(M11.AIActions)await M11.AIActions.downloadAnswer('Respuesta del Administrador IA',box.textContent,`M11_respuesta_IA_${dayKey(new Date())}.png`);
    }
    catch(err){box.textContent=`No fue posible consultar: ${err.message}`;}finally{$('#aiAskBtn').disabled=false;}
  }
  function selectDay(day){selectedDay=day;$('#aiTodayBtn').classList.toggle('active',day==='today');$('#aiTomorrowBtn').classList.toggle('active',day==='tomorrow');renderAgenda(localAgenda());}
  function showAi(){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));$('#aiView').classList.add('active');document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view==='aiView'));renderAgenda(localAgenda());window.scrollTo({top:0,behavior:'smooth'});}
  function init(){
    migrate();
    const cfg=readConfig();if($('#aiServiceUrl'))$('#aiServiceUrl').value=cfg.serviceUrl||'';
    if($('#aiConfigStatus'))$('#aiConfigStatus').textContent=cfg.serviceUrl?'Servicio privado configurado.':'Pendiente de configurar; la agenda local permanece disponible.';
    $('#openAiAssistantBtn')&&$('#openAiAssistantBtn').addEventListener('click',showAi);
    $('#aiTodayBtn')&&$('#aiTodayBtn').addEventListener('click',()=>selectDay('today'));
    $('#aiTomorrowBtn')&&$('#aiTomorrowBtn').addEventListener('click',()=>selectDay('tomorrow'));
    $('#aiConsultBtn')&&$('#aiConsultBtn').addEventListener('click',consult);
    $('#aiAskBtn')&&$('#aiAskBtn').addEventListener('click',ask);
    $('#aiSaveConfigBtn')&&$('#aiSaveConfigBtn').addEventListener('click',()=>{const serviceUrl=$('#aiServiceUrl').value.trim();saveConfig({serviceUrl});$('#aiConfigStatus').textContent=serviceUrl?'Conexión guardada. Abra IA para probarla.':'Conexión eliminada; solo se usará la agenda local.';});
    $('#aiExportBackupBtn')&&$('#aiExportBackupBtn').addEventListener('click',downloadBackup);
    $('#aiImportBackupInput')&&$('#aiImportBackupInput').addEventListener('change',async e=>{try{if(e.target.files[0])await importBackup(e.target.files[0]);}catch(err){$('#aiBackupStatus').textContent=err.message;}finally{e.target.value='';}});
    document.addEventListener('click',e=>{const nav=e.target.closest('.nav-btn[data-view="aiView"]');if(nav){e.preventDefault();showAi();}});
    renderAgenda(localAgenda());
  }
  function initLocalTools(){
    const cfg=readConfig();if($('#aiServiceUrl'))$('#aiServiceUrl').value=cfg.serviceUrl||'';
    if($('#aiConfigStatus'))$('#aiConfigStatus').textContent=cfg.serviceUrl?'Puente deportivo configurado.':'Pendiente de configurar.';
    $('#aiSaveConfigBtn')&&$('#aiSaveConfigBtn').addEventListener('click',()=>{const serviceUrl=$('#aiServiceUrl').value.trim();saveConfig({serviceUrl});$('#aiConfigStatus').textContent=serviceUrl?'Puente deportivo guardado.':'Dirección eliminada.';});
    $('#aiExportBackupBtn')&&$('#aiExportBackupBtn').addEventListener('click',downloadBackup);
    $('#aiImportBackupInput')&&$('#aiImportBackupInput').addEventListener('change',async e=>{try{if(e.target.files[0])await importBackup(e.target.files[0]);}catch(err){$('#aiBackupStatus').textContent=err.message;}finally{e.target.value='';}});
  }
  M11.AIAdmin={init,initLocalTools,show:showAi,localAgenda,financialSnapshot,safeSnapshot,readConfig,callService,importVerifiedAgenda};
})(window.M11);
