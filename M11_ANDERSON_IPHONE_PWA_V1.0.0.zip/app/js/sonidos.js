/* =========================================================
   M11 · sonidos.js  (Sprint 021)
   -----------------------------------------------------------
   Alertas sonoras breves, generadas con la Web Audio API (sin
   archivos de audio ni música de fondo). Tres tonos distinguibles:
     'normal'   -> un tono breve y suave (partido próximo / es
                   momento de apostar).
     'pendiente'-> dos tonos breves (resultado publicado por
                   TheSportsDB, pendiente de confirmación; una
                   estrategia entra en nivel elevado).
     'critica'  -> tono más grave, sin ser estridente (una
                   estrategia llega a Nivel 11; una estrategia
                   queda agotada definitivamente).

   Este módulo NUNCA decide nada del Modelo M11 ni de TheSportsDB:
   solo LEE M11.getPartidoActual(), M11.getEstadoActivo() y
   M11.Store.getEstrategias(), que ya existían, para saber cuándo
   sonar. No escribe en ningún store ni llama a ninguna transición.

   Restricción de Android/navegadores (sección 6.4): el audio no
   puede reproducirse antes de una interacción real del usuario. El
   AudioContext se crea recién en el primer toque/clic válido
   (desbloquearConGesto), y "Probar sonido" es en sí mismo ese primer
   toque para quien entra directo a Configuración.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_KEY = 'm11_sonidos_v1';
  const NIVEL_ELEVADO = 7;   // mismo umbral que ya usa ui.js para "Elevado"
  const NIVEL_MAXIMO = 11;   // cierre definitivo de la estrategia

  let audioCtx = null;
  let desbloqueado = false;

  function leerPreferencias() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const p = JSON.parse(raw);
        return {
          activado: typeof p.activado === 'boolean' ? p.activado : true,
          volumen: (typeof p.volumen === 'number' && p.volumen >= 0 && p.volumen <= 1) ? p.volumen : 0.6
        };
      }
    } catch (e) { /* preferencia corrupta: se usa el valor inicial recomendado */ }
    return { activado: true, volumen: 0.6 }; // valor inicial recomendado (sección 6.3)
  }

  let preferencias = leerPreferencias();

  function guardarPreferencias() {
    localStorage.setItem(LS_KEY, JSON.stringify(preferencias));
  }

  function setActivado(valor) { preferencias.activado = !!valor; guardarPreferencias(); }
  function setVolumen(valor) { preferencias.volumen = Math.min(1, Math.max(0, Number(valor))); guardarPreferencias(); }

  // Debe llamarse desde un manejador de un gesto real del usuario (click/touch).
  // Crear el AudioContext fuera de un gesto falla silenciosamente en Android/
  // Chrome; por eso este módulo no reproduce nada hasta que esto se haya
  // llamado al menos una vez.
  function desbloquearConGesto() {
    if (desbloqueado) return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      audioCtx = new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      desbloqueado = true;
    } catch (e) { /* sin soporte de audio: el resto de la app sigue funcionando */ }
  }

  // Un tono simple con ataque/caída suaves para que no "chasquee".
  function _tono(frecuencia, inicioSeg, duracionSeg, tipoOnda, volumenPico) {
    const t0 = audioCtx.currentTime + inicioSeg;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = tipoOnda || 'sine';
    osc.frequency.setValueAtTime(frecuencia, t0);
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(volumenPico, t0 + 0.02);
    gain.gain.linearRampToValueAtTime(volumenPico, t0 + duracionSeg - 0.05);
    gain.gain.linearRampToValueAtTime(0, t0 + duracionSeg);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(t0);
    osc.stop(t0 + duracionSeg + 0.02);
  }

  function _reproducirTipo(tipo) {
    const vol = preferencias.volumen;
    if (tipo === 'critica') {
      // Dos tonos descendentes, timbre triangular: se distingue con claridad
      // sin ser estridente.
      _tono(784, 0, 0.22, 'triangle', vol * 0.5);
      _tono(523, 0.20, 0.30, 'triangle', vol * 0.5);
    } else if (tipo === 'pendiente') {
      // Dos tonos breves ascendentes.
      _tono(660, 0, 0.14, 'sine', vol * 0.45);
      _tono(880, 0.15, 0.16, 'sine', vol * 0.45);
    } else {
      // 'normal': un único tono breve y suave.
      _tono(880, 0, 0.18, 'sine', vol * 0.4);
    }
  }

  // Reproduce un tipo de sonido si los sonidos están activados. "forzar"
  // (usado por "Probar sonido") lo reproduce aunque estén desactivados, para
  // que el operador pueda oír cómo suena antes de decidir si los deja
  // activados.
  function reproducir(tipo, forzar) {
    if (!forzar && !preferencias.activado) return;
    if (!desbloqueado || !audioCtx) return; // todavía no hubo un gesto del usuario
    try { _reproducirTipo(tipo); } catch (e) { /* no interrumpe la app */ }
  }

  function probar() {
    desbloquearConGesto();
    reproducir('normal', true);
  }

  // ---- Seguimiento de transiciones (para sonar una sola vez por evento) --
  let ultimoPartidoId = undefined;
  let ultimoEstado = null;
  const resultadoYaAvisado = new Set();
  const nivelAnterior = { general: 0, pares: 0, impares: 0 };
  const bloqueadaAnterior = { general: false, pares: false, impares: false };

  function evaluarPartido() {
    if (!M11.getPartidoActual || !M11.getEstadoActivo) return;
    const p = M11.getPartidoActual();
    const estado = M11.getEstadoActivo();
    const idActual = p ? p.id : null;

    if (idActual !== ultimoPartidoId) {
      // Cambió el partido vigente (nuevo próximo partido, cambio de liga,
      // o el Centro de Pruebas avanzó de partido): se reinicia el
      // seguimiento de estado para que EST-02/EST-03 puedan volver a
      // avisar en el partido nuevo.
      ultimoEstado = null;
    }

    if (p && estado === 'EST-02' && ultimoEstado === 'EST-01') reproducir('normal');
    if (p && estado === 'EST-03' && ultimoEstado !== 'EST-03' && ultimoEstado !== 'EST-04' && ultimoEstado !== 'EST-05' && ultimoEstado !== 'EST-06') reproducir('normal');

    if (p && p.resultadoSugerido && !p.resultadoContradictorio && !resultadoYaAvisado.has(p.id)) {
      resultadoYaAvisado.add(p.id);
      reproducir('pendiente');
    }

    ultimoPartidoId = idActual;
    ultimoEstado = estado;
  }

  function evaluarNiveles() {
    if (!M11.Store) return;
    const est = M11.Store.getEstrategias();
    ['general', 'pares', 'impares'].forEach(nombre => {
      const actual = est[nombre];
      if (!actual) return;
      const nivelPrevio = nivelAnterior[nombre];
      if (actual.nivel >= NIVEL_ELEVADO && nivelPrevio < NIVEL_ELEVADO) reproducir('pendiente');
      if (actual.nivel >= NIVEL_MAXIMO && nivelPrevio < NIVEL_MAXIMO) reproducir('critica');
      if (actual.bloqueada && !bloqueadaAnterior[nombre]) reproducir('critica');
      nivelAnterior[nombre] = actual.nivel;
      bloqueadaAnterior[nombre] = actual.bloqueada;
    });
  }

  // Se llama en cada M11.UI.render() (una vez por segundo) — barato: solo
  // lee valores que ya estaban calculados, no hace ningún cálculo nuevo.
  function evaluarEventos() {
    try { evaluarPartido(); } catch (e) { /* un fallo acá no debe romper el render */ }
    try { evaluarNiveles(); } catch (e) { /* idem */ }
  }

  M11.Sonidos = {
    getPreferencias() { return { activado: preferencias.activado, volumen: preferencias.volumen }; },
    setActivado,
    setVolumen,
    desbloquearConGesto,
    probar,
    evaluarEventos
  };

})(window.M11);
