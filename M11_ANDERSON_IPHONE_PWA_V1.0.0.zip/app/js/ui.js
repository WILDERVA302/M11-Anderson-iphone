/* =========================================================
   M11 · ui.js
   -----------------------------------------------------------
   Renderizado del Centro de Operaciones. El Centro de Decisiones
   M11 está siempre visible (un panel distinto por estado, nunca
   vacío); estrategias y capital se calculan siempre desde
   m11-engine.js + state.js, nunca con números escritos en el HTML.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);
  const NOMBRE = { general: 'General', pares: 'Pares', impares: 'Impares' };
  const RESULTADO_TEXTO = { empate: 'Empate', no_empate: 'No empate', cancelado: 'Cancelado', suspendido: 'Suspendido' };

  function fmt(n) { return '$' + Math.round(n).toLocaleString('es-CO'); }
  function fechaHoraMs(p) { return M11.inicioPartidoMs ? M11.inicioPartidoMs(p) : new Date(p.timestampUTC || `${p.fecha}T${p.hora}:00`).getTime(); }

  // Estado transitorio de presentación (no persiste): el resultado
  // recién confirmado en EST-06, para mostrar el resumen en vez del
  // selector, y el aviso opcional cuando "Mostrar alertas visuales"
  // está desactivado.
  let ultimoResultado = null;      // { resultado, detallePorEstrategia } | null
  let avisoConfirmacionTexto = '';

  // ---------------------------------------------------------------
  function pintarEstado(estado) {
    const meta = M11.ESTADO_META[estado];
    const card = $('#statusCard');
    card.className = 'status-card ' + meta.color;
    $('#statusTitle').textContent = meta.titulo;
    let desc = meta.desc;
    if (estado === M11.ESTADOS.ESPERANDO_RESULTADO) {
      const op = M11.Store.getDecision();
      desc = (op && op.estado === 'NO_APOSTADA')
        ? 'No se registró una apuesta para este partido. Sigue su curso; puede cerrar el ciclo cuando termine.'
        : 'Guardada de forma permanente. Puede cerrar el Asistente: consultará el resultado publicado y actualizará capital y niveles automáticamente.';
    }
    $('#statusDesc').textContent = desc;
  }

  function pintarProximoPartido() {
    const p = M11.getPartidoActual();
    const eyebrow = $('#proximoPartidoEyebrow');
    if (eyebrow) eyebrow.textContent = M11.Store.getCentroPruebas() ? 'PRÓXIMO PARTIDO · CENTRO DE PRUEBAS' : 'PRÓXIMO PARTIDO';
    if (!p) {
      $('#teamLocal').textContent = '—';
      $('#teamVisitante').textContent = '—';
      $('#matchCompetition').textContent = 'Sin partido programado';
      $('#matchDateLabel').textContent = '—';
      $('#countdown').textContent = '—';
      return;
    }
    $('#teamLocal').textContent = p.equipoLocal;
    $('#teamVisitante').textContent = p.equipoVisitante;
    $('#matchCompetition').textContent = `${p.torneo} · Cron. ${p.numeroCronologico}`;
    $('#matchDateLabel').textContent = M11.SportsApi.formatearFechaHora(fechaHoraMs(p));
    const minutos = M11.Countdown.minutosRestantes();
    const enGracia = minutos !== null && minutos <= 0 && minutos > -M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN;
    $('#countdown').textContent = enGracia
      ? `En vivo · quedan ${Math.max(1, Math.ceil(M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN + minutos))} min para registrar`
      : M11.Countdown.textoActual();
  }

  // ---- Centro de Decisiones: un panel por estado, siempre visible ----
  function mostrarPanel(idActivo) {
    ['dc-listo', 'dc-proximo', 'dc-apostar', 'dc-confirmacion', 'dc-espera', 'dc-cierre'].forEach(id => {
      $('#' + id).classList.toggle('hidden', id !== idActivo);
    });
  }

  // Lleva la vista al comienzo del Centro de Decisiones tras una acción
  // principal (Sí/No, Guardar apuesta, Registrar resultado, elegir
  // resultado, Continuar), para que el siguiente control quede visible
  // sin que el operador tenga que buscarlo con scroll. Desplazamiento
  // suave, nunca un salto brusco; no se usa en filtros, configuración
  // ni otras acciones que no forman parte de este flujo.
  function enfocarCentroDecisiones() {
    const el = $('#decisionCenter');
    if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function formatearDuracion(mins) {
    const total = Math.max(0, Math.ceil(mins));
    const h = Math.floor(total / 60), m = total % 60;
    return h > 0 ? `${h} h ${m} min` : `${m} min`;
  }

  function formatearHora(ms) {
    // Sprint 020: se fuerza la zona horaria de Colombia (America/Bogota)
    // en vez de dejar que el navegador use la suya — ver la nota extensa
    // en sports-api.js sobre el desfase de 5 horas reportado.
    return M11.SportsApi.formatearFechaHora(ms);
  }

  function montoRecomendadoActual() {
    const est = M11.Store.getEstrategias();
    return M11.getEstrategiasPorParidad().reduce((total, nombre) => {
      const estrategia = est[nombre];
      return total + (estrategia && !estrategia.bloqueada ? M11.Engine.montoPorNivel(estrategia.nivel) : 0);
    }, 0);
  }

  // Contenido compartido de EST-01 y EST-02: el Director pidió que la
  // pantalla de espera siempre responda cuál es el siguiente partido,
  // cuándo empieza, cuándo se podrá apostar, y qué hará el Asistente
  // automáticamente (nada de esto requiere entrar a Configuración ni
  // reiniciar la demostración).
  function construirInfoEspera() {
    const p = M11.getPartidoActual();
    if (!p) {
      return '<p>No hay ningún partido programado. Agregue uno en la pestaña Partidos.</p>';
    }
    const kickoffMs = fechaHoraMs(p);
    const mins = M11.Countdown.minutosRestantes();
    const umbralApostar = M11.Store.getUmbralApostarMin();
    const habilitacionMs = kickoffMs - umbralApostar * 60000;
    const faltaParaApostar = (habilitacionMs - Date.now()) / 60000;
    const recomendado = montoRecomendadoActual();
    return `
      <div class="dist-row"><span>Próximo partido</span><span>${p.equipoLocal} vs ${p.equipoVisitante}</span></div>
      <div class="dist-row"><span>Hora de inicio</span><span>${formatearHora(kickoffMs)}</span></div>
      <div class="dist-row"><span>Falta para el partido</span><span>${formatearDuracion(mins)}</span></div>
      <div class="dist-row"><span>Falta para poder apostar</span><span>${formatearDuracion(faltaParaApostar)}</span></div>
      <div class="dist-row"><span>Se habilitará a las</span><span>${formatearHora(habilitacionMs)}</span></div>
      <div class="real-next-amount"><span>La apuesta recomendada sería</span><strong>${fmt(recomendado)}</strong><small>Se confirmará al abrirse la ventana de apuesta.</small></div>
      <p class="legal-note">Cuando se cumpla ese tiempo, el Asistente pasa solo a "Es momento de apostar" — no hace falta recargar la página ni reiniciar la demostración.</p>`;
  }

  function pintarPanelApostar() {
    const p = M11.getPartidoActual();
    const porParidad = M11.getEstrategiasPorParidad();
    const est = M11.Store.getEstrategias();
    let total = 0;
    const filas = ['general', 'pares', 'impares'].map(nombre => {
      const aplica = porParidad.includes(nombre);
      const bloqueada = est[nombre].bloqueada;
      let valor;
      if (!aplica) valor = 'No participa en este partido';
      else if (bloqueada) valor = 'Secuencia finalizada (Nivel 11) — no participa';
      else {
        const m = M11.Engine.montoPorNivel(est[nombre].nivel);
        total += m;
        valor = fmt(m) + (est[nombre].nivel === M11.Engine.NIVELES ? ' — última apuesta de la secuencia' : '');
      }
      return `<div class="dist-row"><span class="tag ${nombre}">${NOMBRE[nombre]}</span><span>${valor}</span></div>`;
    }).join('');
    $('#dc-distribucion').innerHTML = filas;
    $('#dc-monto-total').textContent = fmt(total);
    $('#dc-cuota-ref').textContent = (p && p.cuotaReferencia) ? p.cuotaReferencia.toLocaleString('es-CO') : 'Pendiente de registrar';
    const capitalDisponible = est.general.disponible + est.pares.disponible + est.impares.disponible;
    $('#dc-capital-disponible').textContent = fmt(capitalDisponible);
    const minutos = M11.Countdown.minutosRestantes();
    const titulo = document.querySelector('#dc-apostar h2');
    const boton = $('#betHouseBtn');
    if (minutos !== null && minutos <= 0) {
      if (titulo) titulo.textContent = 'Aún puede registrar la apuesta';
      if (boton) boton.textContent = 'IR A LA CASA DE APUESTAS · EN VIVO';
    } else {
      if (titulo) titulo.textContent = 'Es momento de apostar';
      if (boton) boton.textContent = 'IR A LA CASA DE APUESTAS';
    }
  }

  // Visibilidad del formulario de apuesta: estado transitorio, NO debe
  // recalcularse en cada render. El contador se actualiza cada segundo
  // (setInterval en events.js) y antes este panel se reconstruía/ocultaba
  // en cada una de esas pasadas, por eso el formulario "parpadeaba" y
  // desaparecía apenas el usuario lo abría. Ahora solo se construye la
  // primera vez que se muestra en este ciclo; en los renders siguientes
  // no se toca mientras siga visible.
  let formularioApuestaVisible = false;
  let formularioApuestaConstruido = false;

  function pintarPanelConfirmacion() {
    if (formularioApuestaVisible && !formularioApuestaConstruido) {
      const activas = M11.getEstrategiasParticipantesActual();
      const est = M11.Store.getEstrategias();
      const recomendado = activas.reduce((sum, n) => sum + M11.Engine.montoPorNivel(est[n].nivel), 0);
      $('#bf-estrategias').textContent = activas.map(n => NOMBRE[n]).join(' + ');
      $('#bf-monto-recomendado').textContent = fmt(recomendado);
      $('#bfMontoApostado').value = recomendado;
      const p = M11.getPartidoActual();
      $('#bfCuota').value = (p && p.cuotaReferencia) ? p.cuotaReferencia : '';
      $('#casaApuestasInput').value = localStorage.getItem('m11BetHouseNombre') || '';
      formularioApuestaConstruido = true;
    }
    $('#dc-confirmacion-aviso').textContent = avisoConfirmacionTexto;
    $('#betForm').classList.toggle('hidden', !formularioApuestaVisible);
    $('#dc-confirmacion-pregunta').classList.toggle('hidden', formularioApuestaVisible);
    $('#dc-form-titulo').classList.toggle('hidden', !formularioApuestaVisible);
  }

  function pintarPanelEspera() {
    const op = M11.Store.getDecision();
    const box = $('#dc-resumen-decision');
    if (!op) {
      box.innerHTML = '<p><strong>Estado incompleto detectado.</strong></p><p>No existe una apuesta pendiente asociada. Puede desbloquear la operación sin modificar capital, niveles ni resultados.</p>';
      const btn = $('#registerResultBtn');
      if (btn) btn.textContent = 'DESBLOQUEAR Y CONTINUAR';
      return;
    }
    const fechaTxt = op.fechaRegistroApuesta ? M11.SportsApi.formatearFechaHora(new Date(op.fechaRegistroApuesta).getTime()) : '';
    if (op.estado === 'NO_APOSTADA') {
      box.innerHTML = `<p><strong>Operación no realizada</strong>${fechaTxt ? ' · ' + fechaTxt : ''}</p>
        <p>La decisión fue registrada como No apostada.<br>No se modificaron el capital ni los niveles.</p>`;
      const btn = $('#registerResultBtn');
      if (btn) btn.textContent = 'CONTINUAR';
      return;
    }
    $('#registerResultBtn').textContent = 'INGRESAR RESULTADO MANUAL';
    const estrategiasTxt = (op.estrategias || []).map(n => NOMBRE[n]).join(' + ');
    // Sprint V1.0.5, sección 6: "Partido en curso" si ya pasó la hora de
    // inicio, "Pendiente de resultado" si todavía no empieza — ambos
    // casos siguen siendo el mismo estado interno (PENDIENTE_RESULTADO);
    // esto es solo una distinción de texto para el operador.
    const p = M11.getPartidoActual();
    const yaComenzo = p && Number.isFinite(fechaHoraMs(p)) && fechaHoraMs(p) <= Date.now();
    const estadoTxt = yaComenzo ? 'Partido en curso' : 'Pendiente de resultado';
    const siguiente = p && M11.calendarioActivo().proximoPartidoDespuesDe
      ? M11.calendarioActivo().proximoPartidoDespuesDe(p.id, Date.now() - M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000)
      : null;
    const inicio = p ? fechaHoraMs(p) : NaN;
    const cierreEstimado = Number.isFinite(inicio) ? inicio + 105 * 60000 : NaN;
    const siguienteInicio = siguiente ? fechaHoraMs(siguiente) : NaN;
    const avisoEncadenado = siguiente && Number.isFinite(cierreEstimado) && Number.isFinite(siguienteInicio) && siguienteInicio <= cierreEstimado + 30 * 60000
      ? `<div class="warning-box"><strong>Partidos seguidos</strong><p>El siguiente es ${siguiente.equipoLocal} vs ${siguiente.equipoVisitante}, a las ${formatearHora(siguienteInicio)}.</p><p>Al terminar el partido actual, pulse <strong>INGRESAR RESULTADO MANUAL</strong>. Al cerrarlo, el siguiente se habilitará sin esperar a que la fuente publique el marcador.</p></div>`
      : '';
    box.innerHTML = `<p><strong>Apuesta registrada correctamente</strong>${fechaTxt ? ' · ' + fechaTxt : ''}</p>
      <p class="legal-note">Esta operación quedó guardada. Ya no necesita permanecer en el Asistente. Puede cerrarlo y regresar cuando el partido haya terminado.</p>
      ${avisoEncadenado}
      ${p ? `<div class="dist-row"><span>Partido</span><span>${p.equipoLocal} vs ${p.equipoVisitante}</span></div>
      <div class="dist-row"><span>Hora de inicio</span><span>${M11.SportsApi.formatearFechaHora(fechaHoraMs(p))}</span></div>` : ''}
      <div class="dist-row"><span>Cuota</span><span>${op.cuota}</span></div>
      <div class="dist-row"><span>Monto apostado</span><span>${fmt(op.montoApostado)}</span></div>
      <div class="dist-row"><span>Estrategias</span><span>${estrategiasTxt}</span></div>
      ${op.casaApuestas ? `<div class="dist-row"><span>Casa de apuestas</span><span>${op.casaApuestas}</span></div>` : ''}
      <div class="dist-row"><span>Estado</span><span>${estadoTxt}</span></div>`;
  }

  // Frase operativa por estrategia (PRIORIDAD 3), con redacción específica
  // para el cierre en Nivel 11 (PRIORIDAD 2b/2c) — el usuario no debe
  // tener que interpretar solo los números.
  function fraseOperativa(nombre, d) {
    const N = NOMBRE[nombre];
    if (d.resultado === 'gano') {
      if (d.nivelAnterior === M11.Engine.NIVELES) {
        return `La estrategia ${N} obtuvo empate en el Nivel 11. La secuencia terminó exitosamente y la estrategia reinicia en el Nivel 1.`;
      }
      return `La estrategia ${N} reinicia en el Nivel 1.`;
    }
    if (d.resultado === 'perdio') {
      if (d.secuenciaFinalizada) {
        return `La estrategia ${N} perdió la apuesta del Nivel 11. La secuencia ha finalizado.`;
      }
      return `La estrategia ${N} pasa al Nivel ${d.nivelNuevo}.`;
    }
    return `La operación de ${N} se cerró sin cambios en capital ni nivel.`;
  }

  function pintarPanelCierre() {
    // PRIORIDAD 1: con el Centro de Pruebas M11 activo, "Continuar"
    // queda oculto — usarlo antes de "Siguiente partido" reprogramaba un
    // partido que nunca se jugaba, y ese cronológico se perdía, rompiendo
    // la alternancia. La única forma de avanzar en ese modo es el botón
    // "⚽ Siguiente partido" del panel.
    const centroPruebasActivo = M11.Store.getCentroPruebas();

    // Sección 9 del Sprint 020 (antes sección 13 del 019): si TheSportsDB
    // ya publicó un marcador para este partido, se muestra como
    // sugerencia — nunca se preselecciona ningún botón. El operador sigue
    // siendo quien pulsa Empate/No empate/Cancelado/Suspendido para que
    // el motor M11 recién ahí actualice capital y niveles. Si el dato de
    // la API es contradictorio (marcador y estado no concuerdan), se pide
    // verificación manual en vez de sugerir un resultado.
    const detectadoBox = $('#dc-resultado-detectado');
    if (detectadoBox) {
      const p = M11.getPartidoActual();
      if (!ultimoResultado && p && p.resultadoContradictorio) {
        detectadoBox.innerHTML = '⚠️ TheSportsDB envió datos contradictorios para este partido (marcador y estado no coinciden). Verifique manualmente antes de confirmar el resultado.';
        detectadoBox.classList.remove('hidden');
      } else if (!ultimoResultado && p && p.resultadoSugerido) {
        const marcador = p.marcadorDetectado ? `${p.equipoLocal} ${p.marcadorDetectado.home}–${p.marcadorDetectado.away} ${p.equipoVisitante}` : `${p.equipoLocal} vs ${p.equipoVisitante}`;
        const texto = p.resultadoSugerido === 'empate' ? 'EMPATE' : 'NO EMPATE';
        detectadoBox.innerHTML = `⚽ TheSportsDB publicó este marcador: <strong>${marcador}</strong>. Esto corresponde a <strong>${texto}</strong>. Confirme el resultado antes de actualizar niveles y capital.`;
        detectadoBox.classList.remove('hidden');
      } else {
        detectadoBox.classList.add('hidden');
      }
    }

    if (!ultimoResultado) {
      // En Operación real el usuario siempre conserva una salida manual:
      // una fuente tardía nunca puede dejar el campeonato bloqueado.
      $('#dc-resultado-selector').classList.remove('hidden');
      $('#dc-resultado-resumen').classList.add('hidden');
      $('#continueBtn').classList.add('hidden');
      $('#dc-cierre-aviso-cp').classList.add('hidden');
      return;
    }
    $('#dc-resultado-selector').classList.add('hidden');
    $('#continueBtn').classList.toggle('hidden', centroPruebasActivo);
    $('#dc-cierre-aviso-cp').classList.toggle('hidden', !centroPruebasActivo);
    const box = $('#dc-resultado-resumen');
    box.classList.remove('hidden');
    const detalle = ultimoResultado.detallePorEstrategia;
    const nombres = Object.keys(detalle);
    let cuerpo;
    if (!nombres.length) {
      cuerpo = '<p>No había una apuesta registrada para este partido: no se modificó capital ni niveles.</p>';
    } else {
      cuerpo = nombres.map(nombre => {
        const d = detalle[nombre];
        const gSigno = d.gananciaNeta >= 0 ? '+' : '−';
        const gTxt = gSigno + fmt(Math.abs(d.gananciaNeta)).replace('$', '$');
        return `<div class="resultado-fila">
          <strong>${NOMBRE[nombre]}</strong>
          <span>Nivel ${d.nivelAnterior} → ${d.nivelNuevo}</span>
          <span>Monto apostado: ${fmt(d.montoApostado)}</span>
          ${d.cuota ? `<span>Cuota: ${d.cuota}</span>` : ''}
          <span>Retorno: ${fmt(d.retorno)}</span>
          <span>Ganancia/pérdida neta: ${gTxt}</span>
          <span>Saldo después: ${fmt(d.saldoDespues)}</span>
          <span class="frase-operativa">${fraseOperativa(nombre, d)}</span>
        </div>`;
      }).join('');
    }
    const resultadoTxt = ultimoResultado.resultado === null ? 'Sin resultado aplicable' : RESULTADO_TEXTO[ultimoResultado.resultado];
    box.innerHTML = `<p><strong>Resultado registrado:</strong> ${resultadoTxt}</p>${cuerpo}
      <p class="legal-note">El Asistente M11 no ejecuta apuestas ni administra dinero real: estos son los cálculos del Modelo M11 aplicados sobre datos de demostración (equipos, cuotas y partidos de ejemplo).</p>`;
  }

  function pintarCentroDecisiones(estado) {
    const E = M11.ESTADOS;
    if (estado !== E.FINALIZADO) ultimoResultado = null;

    const panelPorEstado = {
      [E.LISTO]: 'dc-listo',
      [E.PROXIMO]: 'dc-proximo',
      [E.APOSTAR]: 'dc-apostar',
      [E.ESPERANDO_CONFIRMACION]: 'dc-confirmacion',
      [E.ESPERANDO_RESULTADO]: 'dc-espera',
      [E.FINALIZADO]: 'dc-cierre'
    };
    mostrarPanel(panelPorEstado[estado] || 'dc-listo');

    if (estado === E.LISTO) $('#dc-espera-info').innerHTML = construirInfoEspera();
    if (estado === E.PROXIMO) $('#dc-espera-info-proximo').innerHTML = construirInfoEspera();
    if (estado === E.APOSTAR) pintarPanelApostar();
    if (estado === E.ESPERANDO_CONFIRMACION) {
      pintarPanelConfirmacion();
    } else {
      formularioApuestaVisible = false;
      formularioApuestaConstruido = false;
    }
    if (estado === E.ESPERANDO_RESULTADO) pintarPanelEspera();
    if (estado === E.FINALIZADO) pintarPanelCierre();
  }

  // ---- Capital y estrategias, siempre desde el motor -------------------
  function pintarCapital() {
    const est = M11.Store.getEstrategias();
    const inicial = M11.Engine.presupuestoCompleto() * 3;
    const disponible = est.general.disponible + est.pares.disponible + est.impares.disponible;
    const comprometido = est.general.comprometido + est.pares.comprometido + est.impares.comprometido;
    $('#capInicial').textContent = fmt(inicial);
    $('#capDisponible').textContent = fmt(disponible);
    $('#capComprometido').textContent = fmt(comprometido);
  }

  // Resumen compacto equivalente al del laboratorio ficticio, pero leído
  // exclusivamente del Libro y del motor de la operación REAL activa.
  // El cambio de campeonato cambia también estas cifras: nunca se consolidan
  // datos de otras ligas ni del laboratorio sombra.
  function pintarMetricasReales() {
    const box = $('#realMetrics');
    if (!box || !M11.Libro) return;
    const s = M11.Libro.resumenGeneral();
    const dinero = n => n === null || n === undefined ? '—' : fmt(n);
    const porcentaje = n => n === null || n === undefined ? '—' : `${Number(n).toFixed(2).replace('.', ',')}%`;
    const utilidad = s.gananciaAcumulada;
    const patrimonio = s.patrimonioActual;
    const ratioCapitalExigido = utilidad !== null && s.maximoCapitalRequerido
      ? utilidad / s.maximoCapitalRequerido * 100 : null;
    box.innerHTML = `
      <div class="capital-benefit"><span>Resultado con el capital máximo exigido</span><strong>${dinero(utilidad)} / ${dinero(s.maximoCapitalRequerido)}</strong><small>Ratio utilidad ÷ capital máximo: ${porcentaje(ratioCapitalExigido)}</small></div>
      <div><span>Reserva teórica</span><strong>${dinero(s.capitalInicial)}</strong></div>
      <div><span>Dinero movilizado</span><strong>${dinero(s.totalApostadoAcum)}</strong><small>Suma de apuestas reales cerradas</small></div>
      <div><span>Mayor capital requerido</span><strong>${dinero(s.maximoCapitalRequerido)}</strong><small>Hasta completar una secuencia</small></div>
      <div><span>Mayor apuesta en un partido</span><strong>${dinero(s.maximoUtilizado)}</strong></div>
      <div><span>Reserva realmente exigida</span><strong>${porcentaje(s.porcentajeReservaExigida)}</strong></div>
      <div><span>Utilidad/pérdida producida</span><strong class="${utilidad === null || utilidad >= 0 ? 'positive' : 'negative'}">${dinero(utilidad)}</strong></div>
      <div><span>Rendimiento sobre lo movilizado</span><strong>${porcentaje(s.rendimientoSobreMovilizado)}</strong></div>
      <div><span>Ratio utilidad / capital máximo</span><strong>${porcentaje(ratioCapitalExigido)}</strong><small>Resultado histórico, no garantía futura</small></div>
      <div><span>Patrimonio / retirable</span><strong>${dinero(patrimonio)} / ${dinero(s.retirableAhora)}</strong></div>
      <div><span>Comprometido / registros</span><strong>${dinero(s.capitalComprometido)} · ${s.totalPartidos}</strong></div>`;
  }

  // Único cálculo de rentabilidad de todo el Asistente: pantalla e
  // impresión leen de acá — nunca se recalcula aparte. Lee de
  // M11.Libro.informeRentabilidad() y M11.Libro.resumenGeneral() (las
  // mismas funciones de lectura de siempre) y agrega los tres
  // indicadores de rentabilidad sobre ese mismo resultado.
  function calcularRentabilidadCompleta() {
    if (!M11.Libro) return null;
    const r = M11.Libro.informeRentabilidad();
    const g = M11.Libro.resumenGeneral();
    const totalApostado = g.totalApostadoAcum;
    const sinApostado = !totalApostado;
    const operacionesCerradas = g.empates + g.noEmpates; // partidos con resultado financiero definitivo
    return {
      capitalInicial: r.capitalInicial,
      capitalActual: r.capitalActual,
      gananciaAcumulada: r.gananciaAcumulada,
      totalApostado: g.totalApostadoAcum,
      totalRetornado: g.totalRetornadoAcum,
      partidosJugados: r.partidosJugados,
      empates: r.empates,
      noEmpates: r.noEmpates,
      estrategiasActivas: r.estrategiasActivas,
      estrategiasFinalizadas: r.estrategiasFinalizadas,
      pctCapital: r.rentabilidadPct,
      pctApostado: sinApostado ? null : (r.gananciaAcumulada / totalApostado) * 100,
      pctBruto: sinApostado ? null : (g.totalRetornadoAcum / totalApostado) * 100,
      operacionesCerradas,
      promedioPorOperacion: operacionesCerradas > 0 ? r.gananciaAcumulada / operacionesCerradas : null
    };
  }

  // Informe de Rentabilidad: siempre visible en el Centro de Operaciones,
  // para que el operador pueda evaluar continuamente y decidir libremente
  // si continúa o se detiene. Toda la cifra sale de calcularRentabilidadCompleta()
  // (una sola fuente), nunca se recalcula aparte.
  function pintarInformeRentabilidad() {
    if (!$('#rentCapitalInicial')) return;
    const d = calcularRentabilidadCompleta();
    if (!d) return;
    const signo = (n) => (n === null ? '' : (n >= 0 ? '+' : '−'));
    const fmtPct = (n) => `${signo(n)}${Math.abs(n).toFixed(2)}%`;

    $('#rentCapitalInicial').textContent = fmt(d.capitalInicial);
    $('#rentCapitalActual').textContent = fmt(d.capitalActual);
    $('#rentGanancia').textContent = d.gananciaAcumulada === null ? '—' : `${signo(d.gananciaAcumulada)}${fmt(Math.abs(d.gananciaAcumulada))}`;
    $('#rentTotalApostado').textContent = fmt(d.totalApostado);
    $('#rentTotalRetornado').textContent = fmt(d.totalRetornado);
    $('#rentPartidosJugados').textContent = d.partidosJugados;
    $('#rentEmpates').textContent = d.empates;
    $('#rentNoEmpates').textContent = d.noEmpates;
    if ($('#rentPromedioOperacion')) {
      $('#rentPromedioOperacion').textContent = d.promedioPorOperacion === null ? 'No disponible' : `${d.promedioPorOperacion >= 0 ? '+' : '−'}${fmt(Math.abs(d.promedioPorOperacion))}`;
    }
    $('#rentActivas').textContent = d.estrategiasActivas.join(', ') || 'Ninguna';
    $('#rentFinalizadas').textContent = d.estrategiasFinalizadas.join(', ') || 'Ninguna';

    $('#rentPctCapital').textContent = d.pctCapital === null ? '—' : fmtPct(d.pctCapital);
    if (d.pctApostado === null) {
      $('#rentPctApostado').textContent = 'No disponible';
      $('#rentPctBruto').textContent = 'No disponible';
    } else {
      $('#rentPctApostado').textContent = fmtPct(d.pctApostado);
      $('#rentPctBruto').textContent = `${d.pctBruto.toFixed(2)}%`;
    }
  }

  // ---- Sprint 1: Objetivos de Rentabilidad M11 --------------------------
  // Reutiliza calcularRentabilidadCompleta() (la misma fuente de pantalla
  // e impresión). No agrega ni modifica ningún cálculo del Modelo M11:
  // solo compara la rentabilidad ya calculada contra tres metas fijas.
  const METAS_RENTABILIDAD = [5, 10, 15];

  function calcularObjetivos() {
    const d = calcularRentabilidadCompleta();
    if (!d) return null;
    const actual = d.pctCapital; // null si aún no hay capital inicial válido
    const alcanzadas = METAS_RENTABILIDAD.filter(m => actual !== null && actual >= m);
    const metaSiguiente = METAS_RENTABILIDAD.find(m => !(actual !== null && actual >= m)) || null;
    const metaMaxima = alcanzadas.length === METAS_RENTABILIDAD.length;
    let progresoPct = 0;
    if (actual !== null && metaSiguiente) progresoPct = Math.max(0, Math.min(100, (actual / metaSiguiente) * 100));
    else if (metaMaxima) progresoPct = 100;
    const faltante = (actual !== null && metaSiguiente) ? Math.max(0, metaSiguiente - actual) : null;
    // Ganancia necesaria = capital inicial × meta − ganancia acumulada (sección 10).
    const gananciaNecesaria = (metaSiguiente && d.capitalInicial && d.gananciaAcumulada !== null)
      ? Math.max(0, d.capitalInicial * (metaSiguiente / 100) - d.gananciaAcumulada) : null;
    return { actual, alcanzadas, metaSiguiente, metaMaxima, progresoPct, faltante, gananciaNecesaria };
  }

  function barraTexto(progresoPct) {
    const total = 15, llenos = Math.round((progresoPct / 100) * total);
    return '█'.repeat(llenos) + '░'.repeat(total - llenos);
  }

  // Mismo texto base para las tres metas (el encargo pide "un mensaje
  // similar" para 10% y 15%, no uno distinto) — solo cambia el número.
  // Los botones CONTINUAR OPERACIÓN / FINALIZAR OPERACIÓN son reales:
  // "Finalizar" persiste la decisión del operador (ver
  // M11.Store.finalizarOperacionPorOperador) y así queda reflejada en
  // Salud de la Operación. Nunca se sugiere el 10% como paso
  // predeterminado — solo se muestra si el operador sigue.
  function bannerObjetivoHTML(meta) {
    return `
      <div class="objetivo-alcanzado">
        <div class="objetivo-estrellas">★★★★★</div>
        <strong>OBJETIVO DEL ${meta}% ALCANZADO</strong>
        <p>La operación alcanzó una rentabilidad importante sobre el capital inicial.<br>
        Puede ser un buen momento para evaluar la posibilidad de asegurar las utilidades obtenidas.</p>
        <p class="legal-note">La decisión final corresponde únicamente al operador.</p>
        <div class="choice-row" style="margin-top:12px">
          <button type="button" id="continuarOperacionBtn" class="choice secondary">CONTINUAR OPERACIÓN</button>
          <button type="button" id="finalizarOperacionBtn" class="choice" style="background:var(--red)">FINALIZAR OPERACIÓN</button>
        </div>
      </div>`;
  }

  function objetivosHTML(o) {
    if (!o) return '';
    if (M11.Store.getOperacionFinalizadaPorOperador()) {
      return `<div class="eyebrow">OBJETIVOS DE RENTABILIDAD M11</div>
        <div class="objetivo-alcanzado">
          <strong>OPERACIÓN FINALIZADA POR EL OPERADOR</strong>
          <p class="legal-note">El operador decidió dar por finalizada la operación. El Libro de Operaciones conserva el historial completo.</p>
        </div>`;
    }
    const actualTxt = o.actual === null ? '—' : `${o.actual >= 0 ? '+' : '−'}${Math.abs(o.actual).toFixed(2)}%`;
    let html = `<div class="eyebrow">OBJETIVOS DE RENTABILIDAD M11</div>`;

    if (o.alcanzadas.length) {
      html += bannerObjetivoHTML(o.alcanzadas[o.alcanzadas.length - 1]);
    }

    html += `<div class="objetivo-actual">
      <span>Rentabilidad actual</span>
      <strong>${actualTxt}</strong>
    </div>
    <div class="objetivo-barra" aria-hidden="true">${barraTexto(o.progresoPct)}</div>`;

    if (o.metaSiguiente) {
      const faltanTxt = o.faltante === null ? '—' : `${o.faltante.toFixed(2)}%`;
      const necesariaTxt = o.gananciaNecesaria === null ? '—' : fmt(o.gananciaNecesaria);
      html += `<div class="objetivo-meta-fila">
        <div><span>Meta siguiente</span><strong>${o.metaSiguiente}%</strong></div>
        <div><span>Faltan</span><strong>${faltanTxt}</strong></div>
      </div>
      <div class="objetivo-meta-fila">
        <div style="flex:2"><span>Ganancia necesaria para la meta siguiente</span><strong>${necesariaTxt}</strong></div>
      </div>`;
    } else {
      html += `<p class="legal-note">Ya se alcanzaron las tres metas definidas (5%, 10% y 15%). No hay una meta adicional configurada.</p>`;
    }

    html += `<p class="legal-note">El Asistente nunca sugiere continuar apostando. Solo informa el avance frente a las metas definidas.</p>`;
    return html;
  }

  // ---- Sección 13: Riesgo visible ----------------------------------------
  function clasificarRiesgoNivel(nivel, bloqueada) {
    if (bloqueada) return 'Finalizada';
    if (nivel >= 11) return 'Máximo';
    if (nivel >= 9) return 'Alto';
    if (nivel >= 7) return 'Elevado';
    if (nivel >= 4) return 'Moderado';
    return 'Bajo';
  }
  const ORDEN_RIESGO = ['Bajo', 'Moderado', 'Elevado', 'Alto', 'Máximo', 'Finalizada'];
  const NOMBRE_ESTRATEGIA_CAP = { general: 'General', pares: 'Pares', impares: 'Impares' };

  function calcularRiesgo() {
    if (!M11.Store) return null;
    const est = M11.Store.getEstrategias();
    const porEstrategia = ['general', 'pares', 'impares'].map(n => ({
      nombre: NOMBRE_ESTRATEGIA_CAP[n], nivel: est[n].nivel, bloqueada: est[n].bloqueada,
      categoria: clasificarRiesgoNivel(est[n].nivel, est[n].bloqueada)
    }));
    const activas = porEstrategia.filter(e => !e.bloqueada);
    const general = activas.length
      ? activas.reduce((peor, e) => ORDEN_RIESGO.indexOf(e.categoria) > ORDEN_RIESGO.indexOf(peor.categoria) ? e : peor, activas[0])
      : { nombre: '—', nivel: null, categoria: 'Finalizada' };
    return { porEstrategia, general };
  }

  // ---- Sección 14: Salud de la operación ---------------------------------
  function calcularSalud() {
    if (!M11.Store || !M11.Libro) return null;
    if (M11.Store.getOperacionFinalizadaPorOperador()) {
      return { estado: 'Finalizada', razon: 'El operador decidió dar por finalizada la operación.' };
    }
    const est = M11.Store.getEstrategias();
    const g = M11.Libro.resumenGeneral();
    const activas = ['general', 'pares', 'impares'].filter(n => !est[n].bloqueada);
    if (!activas.length) return { estado: 'Finalizada', razon: 'Las tres estrategias quedaron cerradas para este torneo.' };

    const nivelMax = Math.max(...activas.map(n => est[n].nivel));
    const capitalInsuficiente = g.capitalDisponible <= 0;
    if (nivelMax >= 11 || capitalInsuficiente) {
      return { estado: 'Crítica', razon: capitalInsuficiente ? 'El capital disponible no alcanza para la siguiente operación.' : 'Al menos una estrategia llegó al Nivel 11.' };
    }
    if (nivelMax >= 9) return { estado: 'Exigente', razon: 'Al menos una estrategia está en Nivel 9 o 10.' };

    const d = calcularRentabilidadCompleta();
    const rentabilidadNegativa = d && d.pctCapital !== null && d.pctCapital < 0;
    if (nivelMax >= 7) return { estado: 'En observación', razon: 'Al menos una estrategia está en Nivel 7 u 8.' };
    if (rentabilidadNegativa) return { estado: 'En observación', razon: 'La rentabilidad acumulada sobre el capital inicial es negativa.' };
    return { estado: 'Estable', razon: 'Las tres estrategias están activas, ninguna por encima del Nivel 6, y el capital disponible es suficiente.' };
  }

  function riesgoYSaludHTML() {
    const riesgo = calcularRiesgo();
    const salud = calcularSalud();
    if (!riesgo || !salud) return '';
    const colorSalud = { Estable: 'var(--green)', 'En observación': 'var(--blue)', Exigente: 'var(--orange)', Crítica: 'var(--red)', Finalizada: 'var(--muted)' }[salud.estado];
    const colorRiesgo = { Bajo: 'var(--green)', Moderado: 'var(--blue)', Elevado: 'var(--orange)', Alto: 'var(--red)', Máximo: 'var(--red)', Finalizada: 'var(--muted)' }[riesgo.general.categoria];
    return `<div class="eyebrow">RIESGO Y SALUD DE LA OPERACIÓN</div>
      <div class="salud-riesgo-fila">
        <div class="salud-item" style="border-color:${colorSalud}">
          <span>Salud de la operación</span>
          <strong style="color:${colorSalud}">${salud.estado}</strong>
          <small>${salud.razon}</small>
        </div>
        <div class="salud-item" style="border-color:${colorRiesgo}">
          <span>Riesgo general</span>
          <strong style="color:${colorRiesgo}">${riesgo.general.categoria}</strong>
          <small>${riesgo.general.nivel !== null ? `Estrategia ${riesgo.general.nombre} · Nivel ${riesgo.general.nivel}` : 'Todas las estrategias están cerradas'}</small>
        </div>
      </div>
      <div class="riesgo-detalle-grid">
        ${riesgo.porEstrategia.map(e => `<div><span>${e.nombre}</span><strong>${e.bloqueada ? 'Finalizada' : 'Nivel ' + e.nivel}</strong><small>${e.categoria}</small></div>`).join('')}
      </div>`;
  }

  function pintarRiesgoYSalud() {
    const box = $('#riesgoSaludCard');
    if (box) box.innerHTML = riesgoYSaludHTML();
  }

  // ---- Sección 15: Centro de Logros --------------------------------------
  // Hitos auditables únicamente — nunca premia monto apostado, cantidad de
  // apuestas, alcanzar niveles altos, ni continuar después de pérdidas.
  function calcularLogros() {
    if (!M11.Libro || !M11.Store) return [];
    const g = M11.Libro.resumenGeneral();
    const registros = M11.Libro.listar();
    const registrosCompletos = registros.length > 0 && registros.every(r => r.numero != null && r.fechaHora != null && r.resultado != null);
    const o = calcularObjetivos();
    const salud = calcularSalud();
    return [
      { nombre: '10 partidos registrados', logrado: g.totalPartidos >= 10 },
      { nombre: '20 partidos registrados', logrado: g.totalPartidos >= 20 },
      { nombre: 'Primer bloque evaluado', logrado: !!(M11.Evaluacion && M11.Evaluacion.ultima()) },
      { nombre: '100% de registros completos', logrado: registrosCompletos },
      { nombre: 'Primer objetivo de rentabilidad alcanzado', logrado: !!(o && o.alcanzadas.length > 0) },
      { nombre: 'Operación cerrada respetando las reglas', logrado: !!(salud && salud.estado === 'Finalizada') }
    ];
  }

  function logrosHTML() {
    const hitos = calcularLogros();
    if (!hitos.length) return '';
    return `<div class="eyebrow">CENTRO DE LOGROS</div>
      <div class="logros-lista">
        ${hitos.map(h => `<div class="logro-item ${h.logrado ? 'logrado' : ''}">
          <span class="logro-check">${h.logrado ? '✓' : '—'}</span>
          <span>${h.nombre}</span>
        </div>`).join('')}
      </div>`;
  }

  function pintarLogros() {
    const box = $('#logrosCard');
    if (box) box.innerHTML = logrosHTML();
  }

  function pintarObjetivosRentabilidad() {
    const o = calcularObjetivos();
    const box = $('#objetivosRentabilidadCard');
    if (box) box.innerHTML = objetivosHTML(o);
    return o;
  }

  // ---- Sprint 2: Inteligencia Narrativa ----------------------------------
  // Compone explicaciones a partir de datos que el motor YA calculó
  // (detallePorEstrategia del último resultado, niveles actuales, Libro
  // de Operaciones). No agrega ni cambia ningún cálculo: solo los explica
  // en texto.
  let ultimaMetaNarrada = 0; // más alta meta (5/10/15) ya comentada en esta sesión

  function contarRachaNoEmpates() {
    const regs = M11.Libro ? M11.Libro.listar() : [];
    let racha = 0;
    for (let i = regs.length - 1; i >= 0; i--) {
      if (regs[i].resultado === 'no_empate') racha++; else break;
    }
    return racha;
  }

  function construirNarrativa() {
    if (!M11.Libro) return [];
    const lineas = [];
    const est = M11.Store.getEstrategias();
    const NOMBRE_CAP = { general: 'General', pares: 'Pares', impares: 'Impares' };
    const d = calcularRentabilidadCompleta();
    const rentabilidadTxt = d && d.pctCapital !== null ? `${d.pctCapital >= 0 ? '' : '−'}${Math.abs(d.pctCapital).toFixed(2).replace('.', ',')} %` : null;

    // 1) Reacción directa al último resultado registrado.
    let proximoPasoLinea = null;
    if (ultimoResultado) {
      const { resultado, detallePorEstrategia } = ultimoResultado;
      const participantes = Object.keys(detallePorEstrategia || {});
      if (resultado === 'empate') {
        lineas.push('Se registró un empate.');
        const ganadoras = participantes.filter(n => detallePorEstrategia[n] && detallePorEstrategia[n].resultado === 'gano').map(n => NOMBRE_CAP[n]);
        if (ganadoras.length === 1) lineas.push(`La estrategia ${ganadoras[0]} regresó al Nivel 1.`);
        else if (ganadoras.length > 1) lineas.push(`Las estrategias ${ganadoras.join(' e ')} regresaron al Nivel 1.`);
        const activas = ['general', 'pares', 'impares'].filter(n => !est[n].bloqueada);
        lineas.push(activas.length === 3 ? 'Las tres estrategias permanecen activas.' : `Estrategias activas: ${activas.map(n => NOMBRE_CAP[n]).join(', ') || 'ninguna'}.`);
        if (rentabilidadTxt !== null) lineas.push(`La rentabilidad acumulada es de ${rentabilidadTxt} sobre el capital inicial.`);
        proximoPasoLinea = 'Próximo paso: esperar el siguiente partido.';
      } else if (resultado === 'no_empate') {
        lineas.push('Se registró un no empate.');
        const participante = participantes.find(n => detallePorEstrategia[n] && detallePorEstrategia[n].resultado === 'perdio');
        if (participante) lineas.push(`La estrategia ${NOMBRE_CAP[participante]} pasó al Nivel ${detallePorEstrategia[participante].nivelNuevo}.`);
        lineas.push('El capital disponible continúa cubriendo la progresión prevista.');
        lineas.push('La operación permanece activa.');
        proximoPasoLinea = 'Próximo paso: esperar el siguiente partido.';
      } else if (resultado === 'cancelado' || resultado === 'suspendido') {
        lineas.push(`El partido se registró como ${resultado === 'cancelado' ? 'cancelado' : 'suspendido'}.`);
        lineas.push('No afecta capital ni niveles.');
        lineas.push('La operación continúa normalmente.');
      }

      // Estrategia recién finalizada (Nivel 11 sin ganar) tiene prioridad
      // sobre el resto: se antepone.
      participantes.forEach(n => {
        const dd = detallePorEstrategia[n];
        if (dd && dd.secuenciaFinalizada) {
          const otras = ['general', 'pares', 'impares'].filter(x => x !== n && !est[x].bloqueada);
          lineas.unshift(`La estrategia ${NOMBRE_CAP[n]} finalizó para este torneo.`);
          lineas.splice(1, 0, otras.length ? 'Las demás estrategias continúan de forma independiente.' : 'No quedan estrategias activas.');
        }
      });
    }

    // Nivel elevado en alguna estrategia activa (aviso de disciplina): va
    // antes que "Próximo paso" a propósito — es información que protege
    // al operador, y "próximo paso: esperar" es la línea menos esencial
    // de todas si el espacio (máximo 5 líneas) se pone justo.
    const elevadas = ['general', 'pares', 'impares'].filter(n => !est[n].bloqueada && est[n].nivel >= 9);
    if (elevadas.length) {
      lineas.push(`La estrategia ${elevadas.map(n => NOMBRE_CAP[n]).join(' y ')} alcanzó un nivel elevado.`);
      lineas.push('Mantenga disciplina y no modifique la progresión.');
      lineas.push('El Asistente no predice el próximo resultado.');
    }
    if (proximoPasoLinea) lineas.push(proximoPasoLinea);

    // Objetivo de rentabilidad recién alcanzado (no se repite dos veces).
    const o = calcularObjetivos();
    if (o && o.alcanzadas.length) {
      const masAlta = o.alcanzadas[o.alcanzadas.length - 1];
      if (masAlta > ultimaMetaNarrada) {
        ultimaMetaNarrada = masAlta;
        lineas.push(`El operador alcanzó una rentabilidad importante sobre el capital inicial (${masAlta}%).`);
        lineas.push('La decisión final corresponde únicamente al operador.');
      }
    }

    // Máximo cinco líneas (sección 12): se prioriza lo ya insertado en
    // orden — resultado del partido primero, luego avisos de disciplina
    // u objetivo — y se corta ahí, nunca se resume "de más".
    return lineas.slice(0, 5);
  }

  function pintarComentarioAsistente() {
    const box = $('#comentarioAsistenteCard');
    if (!box) return;
    const bloques = construirNarrativa();
    box.innerHTML = `<div class="eyebrow">DIAGNÓSTICO DEL ASISTENTE</div>` +
      (bloques.length ? bloques.map(b => `<p class="comentario-asistente-bloque">${b}</p>`).join('') : `<p class="legal-note">No hay diagnóstico reciente: todavía no se registró un resultado en esta sesión.</p>`);
  }

  function pintarEstrategias() {
    const est = M11.Store.getEstrategias();
    const porParidad = M11.getEstrategiasPorParidad();
    ['general', 'pares', 'impares'].forEach(nombre => {
      const e = est[nombre];
      const card = $('#est-' + nombre + '-card');
      // Nunca se muestra capital negativo: si la secuencia está
      // bloqueada (o, por seguridad, si algún dato quedara en negativo),
      // se reemplaza por el estado de cierre en vez del número.
      if (e.bloqueada || e.disponible < 0) {
        $('#est-' + nombre + '-saldo').textContent = 'Secuencia finalizada';
        $('#est-' + nombre + '-barra').style.width = '100%';
        $('#est-' + nombre + '-texto').textContent = 'Capital agotado · Nivel 11 alcanzado';
        card.classList.add('warning-max', 'blocked-card');
        return;
      }
      card.classList.remove('blocked-card');
      const pct = (e.nivel / M11.Engine.NIVELES) * 100;
      $('#est-' + nombre + '-saldo').textContent = fmt(e.disponible);
      $('#est-' + nombre + '-barra').style.width = pct + '%';
      const enMaximo = e.nivel === M11.Engine.NIVELES;
      let texto;
      if (enMaximo) {
        // Nivel 11 alcanzado pero TODAVÍA sin resolver: es la última
        // apuesta de la secuencia, no un cierre — el cierre solo ocurre
        // si esa apuesta se pierde (ver tarjeta "bloqueada" arriba).
        texto = 'Nivel 11 de 11 — Última apuesta de la secuencia. Si no obtiene empate, esta secuencia finalizará.';
      } else {
        texto = `Nivel ${e.nivel} de ${M11.Engine.NIVELES}`;
        if (!porParidad.includes(nombre)) texto += ' · No participa en el próximo partido';
      }
      $('#est-' + nombre + '-texto').textContent = texto;
      card.classList.toggle('warning-max', enMaximo);
    });
  }

  // ---- Partidos (calendario) ---------------------------------------------
  // La pestaña Partidos completa (país/liga, estado de conexión,
  // agrupaciones próximo/próximos/recientes/sin fecha) vive en
  // liga-ui.js desde el Sprint 019. Aquí solo se dispara su render, en el
  // mismo punto del ciclo que antes ocupaba el calendario manual.
  function pintarPartidos() {
    if (M11.LigaUI) M11.LigaUI.render();
  }

  // Modal de partidos simultáneos (Sprint 006, sección 2): se construye
  // UNA sola vez por grupo detectado (comparando los ids), igual que el
  // formulario de apuesta y el modal de secuencia — para que el
  // redibujado cada segundo no borre la selección que el operador ya
  // esté haciendo.
  let ultimoGrupoSimultaneoIds = null;
  function pintarModalSimultaneidad() {
    const modal = $('#modalSimultaneidad');
    const cal = M11.calendarioActivo();
    if (!modal || !cal.grupoSimultaneoPendiente) return;
    const grupo = cal.grupoSimultaneoPendiente();
    if (!grupo) { modal.classList.add('hidden'); ultimoGrupoSimultaneoIds = null; return; }
    modal.classList.remove('hidden');
    const idsActuales = grupo.map(p => p.id).sort().join(',');
    if (idsActuales === ultimoGrupoSimultaneoIds) return; // ya construido, no pisar la elección en curso
    ultimoGrupoSimultaneoIds = idsActuales;
    $('#simultaneidadOpciones').innerHTML = grupo.map(p => `
      <label class="simultaneidad-opcion">
        <input type="radio" name="simultaneidadElegido" value="${p.id}">
        <span><strong>${p.equipoLocal} vs ${p.equipoVisitante}</strong><br>${M11.SportsApi.formatearFechaHora(fechaHoraMs(p))} · ${p.torneo}<br>Cuota de empate: ${p.cuotaReferencia !== null && p.cuotaReferencia !== undefined ? p.cuotaReferencia : 'Pendiente de registrar'}</span>
      </label>`).join('');
    $('#simultaneidadContinuarBtn').disabled = true;
  }

  // ---- Centro de Pruebas M11 ---------------------------------------------
  // Panel visible únicamente cuando el interruptor está activado
  // (Configuración). No sustituye el flujo real: solo lo acelera para
  // poder probar decenas de veces en pocos minutos. Nunca debe bloquear
  // el uso normal del Centro de Decisiones: por eso puede minimizarse,
  // cerrarse y arrastrarse fuera del camino.
  //
  // Se evita reposicionar el panel mientras el operador lo está
  // arrastrando activamente (mismo problema que el formulario de
  // apuesta: el redibujado periódico —cada segundo— no debe pisar una
  // interacción en curso).
  let arrastrandoCentroPruebas = false;

  function pintarCentroPruebas() {
    const panel = $('#centroPruebasPanel');
    const barraMin = $('#centroPruebasMinimizadoBar');
    const btnReabrir = $('#centroPruebasReabrirBtn');
    if (!panel) return;

    const activo = M11.Store.getCentroPruebas();
    if (!activo) {
      panel.classList.add('hidden');
      barraMin.classList.add('hidden');
      btnReabrir.classList.add('hidden');
      return;
    }

    const oculto = M11.Store.getCentroPruebasOculto();
    const minimizado = M11.Store.getCentroPruebasMinimizado();

    panel.classList.toggle('hidden', oculto || minimizado);
    barraMin.classList.toggle('hidden', oculto || !minimizado);
    btnReabrir.classList.toggle('hidden', !oculto);

    if (oculto || minimizado) return;

    if (!arrastrandoCentroPruebas) {
      const pos = M11.Store.getCentroPruebasPosicion();
      if (pos) {
        panel.style.left = pos.left + 'px';
        panel.style.top = pos.top + 'px';
      }
    }

    const estado = M11.getEstadoActivo();
    const p = M11.getPartidoActual();
    const porParidad = M11.getEstrategiasPorParidad();
    const est = M11.Store.getEstrategias();
    const op = M11.Store.getDecision();
    const bloqueadas = ['general', 'pares', 'impares'].filter(n => est[n].bloqueada);

    $('#cpEstado').textContent = estado;
    $('#cpCronologico').textContent = p ? p.numeroCronologico : '—';
    $('#cpParticipan').textContent = porParidad.map(n => NOMBRE[n]).join(' + ') || '—';
    $('#cpOperacionPendiente').textContent = (op && op.estado === 'PENDIENTE_RESULTADO') ? 'Sí' : 'No';
    $('#cpBloqueadas').textContent = bloqueadas.length
      ? bloqueadas.map(n => `${NOMBRE[n]}: bloqueada por Nivel 11`).join(' · ')
      : 'Ninguna';

    // Botones inteligentes: Empate, No empate y Cancelado solo tienen
    // sentido si hay una apuesta pendiente de resultado.
    const hayPendiente = !!(op && op.estado === 'PENDIENTE_RESULTADO');
    $('#cpEmpateBtn').disabled = !hayPendiente;
    $('#cpNoEmpateBtn').disabled = !hayPendiente;
    $('#cpCanceladoBtn').disabled = !hayPendiente;
    $('#cpSiguienteEstadoBtn').disabled = estado === M11.ESTADOS.FINALIZADO;
  }

  // ---- Modal de secuencia finalizada (Nivel 11) --------------------------
  function pintarModalSecuencia(nombreEstrategia) {
    const modal = $('#modalSecuenciaFinalizada');
    if (!nombreEstrategia) { modal.classList.add('hidden'); return; }
    $('#modalSecuenciaNombre').textContent = NOMBRE[nombreEstrategia];
    modal.classList.remove('hidden');
  }


  // Se sincroniza UNA sola vez por visita a esta pantalla (no en cada
  // render periódico), para no borrar lo que el usuario esté escribiendo
  // antes de pulsar "Guardar cambios" — el mismo tipo de error que el
  // formulario de apuesta, aplicado aquí.
  let configuracionSincronizada = false;

  function pintarConfiguracion() {
    const vista = $('#settingsView');
    if (!vista || !vista.classList.contains('active')) { configuracionSincronizada = false; return; }
    // La sección "Liga y calendario" (Sprint 019) tiene su propio estado de
    // conexión (Actualizando / Conectado / Sin conexión...) que sí debe
    // refrescarse en cada render periódico, a diferencia del resto de este
    // formulario — por eso se llama fuera de la puerta configuracionSincronizada.
    if (M11.LigaUI) M11.LigaUI.renderConfiguracion();
    if (M11.OperacionesUI) M11.OperacionesUI.render();
    if (configuracionSincronizada) return;

    const modoSel = $('#demoModeSelect');
    if (modoSel) modoSel.value = (M11.Store.getModo() === 'auto') ? 'automatico' : M11.Store.getEstadoManual();
    $('#umbralProximoInput').value = M11.Store.getUmbralProximoMin();
    $('#umbralApostarInput').value = M11.Store.getUmbralApostarMin();
    $('#alertasVisualesCheckbox').checked = M11.Store.getAlertasVisuales();
    $('#betHouseNombre').value = localStorage.getItem('m11BetHouseNombre') || '';
    $('#betHouseUrl').value = localStorage.getItem('m11BetHouseUrl') || '';
    const cp = $('#centroPruebasCheckbox');
    if (cp) cp.checked = M11.Store.getCentroPruebas();
    configuracionSincronizada = true;
  }

  M11.UI = {
    render() {
      // El login debe permanecer independiente de los datos operativos. Si
      // la zona privada no está visible, no se recorren calendario, libro ni
      // operaciones; los controles de acceso quedan siempre disponibles.
      const privado = $('#privateModule');
      if (privado && privado.classList.contains('hidden')) return null;
      const estado = M11.getEstadoActivo();
      const E = M11.ESTADOS;
      const home = $('#homeView');
      if (home) home.classList.toggle('modo-operativo', estado !== E.LISTO && estado !== E.PROXIMO);
      pintarEstado(estado);
      pintarProximoPartido();
      pintarCentroDecisiones(estado);
      pintarCapital();
      pintarMetricasReales();
      pintarInformeRentabilidad();
      pintarObjetivosRentabilidad();
      pintarRiesgoYSalud();
      pintarLogros();
      pintarComentarioAsistente();
      pintarEstrategias();
      const vistaPartidos = $('#matchesView');
      if (vistaPartidos && vistaPartidos.classList.contains('active')) pintarPartidos();
      pintarModalSimultaneidad();
      const vistaConfiguracion = $('#settingsView');
      if (vistaConfiguracion && vistaConfiguracion.classList.contains('active')) pintarConfiguracion();
      pintarCentroPruebas();
      if (M11.EvaluacionUI) M11.EvaluacionUI.pintarAviso();
      if (M11.Sonidos) M11.Sonidos.evaluarEventos();
      if (M11.Notifications) M11.Notifications.syncIfChanged();
      return estado;
    },
    registrarResultadoUI(resultado, detallePorEstrategia) {
      ultimoResultado = { resultado, detallePorEstrategia };
    },
    setAvisoConfirmacion(texto) { avisoConfirmacionTexto = texto || ''; },
    mostrarFormularioApuesta() { formularioApuestaVisible = true; },
    ocultarFormularioApuesta() { formularioApuestaVisible = false; formularioApuestaConstruido = false; },
    mostrarModalSecuencia: pintarModalSecuencia,
    setArrastrandoCentroPruebas(on) { arrastrandoCentroPruebas = on; },
    enfocarCentroDecisiones,
    calcularRentabilidadCompleta,
    calcularObjetivos,
    objetivosHTML,
    calcularRiesgo,
    calcularSalud,
    riesgoYSaludHTML,
    construirNarrativa,
    construirNarrativa,
    calcularLogros
  };

})(window.M11);
