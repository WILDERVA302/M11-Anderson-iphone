/* =========================================================
   M11 · android.js  (Sprint 021, ampliado en V1.0.5 sección 5)
   -----------------------------------------------------------
   Integración con el contenedor nativo de Android (Capacitor). Todo
   este archivo es opcional: si window.Capacitor no existe (la app
   corriendo en un navegador normal, como siempre), init() no hace
   nada y el resto de la aplicación sigue funcionando exactamente
   igual. No decide nada del Modelo M11 — solo navega entre pantallas
   ya existentes (haciendo clic en los mismos botones que usaría el
   operador) y consulta si hay un modal abierto.

   Botón Atrás (sección 10 del encargo):
   1) Si hay un modal de ayuda abierto (sin decisión pendiente), se
      cierra con el mismo botón "Entendido" que ya existe.
   2) Si hay un modal que exige una decisión (secuencia finalizada,
      partidos simultáneos), Atrás no hace nada — no existe un
      "cancelar" seguro para esos dos, y no cerrarlos evita dejar la
      operación a medias.
   3) Si no está en Inicio, vuelve a Inicio (mismo botón de la
      navegación inferior).
   4) Si ya está en Inicio, pide confirmación antes de salir.

   Casa de apuestas (Sprint V1.0.5, sección 5): abrirCasaDeApuestas()
   usa el navegador integrado de Capacitor (@capacitor/browser) en vez
   de sacar al operador de la app por completo — así no depende del
   botón cuadrado/gestual de Android para volver. Fuera de Android
   (navegador normal), sigue usando window.open() exactamente como
   antes. No se inserta ningún código ni botón dentro del sitio de la
   casa de apuestas — solo se abre y se detecta cuándo se cerró.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  function _capacitorApp() {
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) || null;
  }
  function _capacitorBrowser() {
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser) || null;
  }

  function _abierto(id) {
    const el = document.getElementById(id);
    return !!(el && !el.classList.contains('hidden'));
  }

  function manejarBotonAtras() {
    if (_abierto('modalAyudaCentroPruebas')) {
      const btn = document.getElementById('ayudaCentroPruebasCerrarBtn');
      if (btn) btn.click();
      return;
    }
    if (_abierto('modalSecuenciaFinalizada') || _abierto('modalSimultaneidad')) {
      return; // decisión obligatoria: Atrás no hace nada mientras esté abierto
    }
    const vistaActiva = document.querySelector('.view.active');
    if (vistaActiva && vistaActiva.id !== 'homeView') {
      const btnInicio = document.querySelector('.nav-btn[data-view="homeView"]');
      if (btnInicio) { btnInicio.click(); return; }
    }
    if (window.confirm('¿Salir del Asistente M11?')) {
      const App = _capacitorApp();
      if (App) App.exitApp();
    }
  }

  // Barra de estado: oscura con íconos claros, a juego con el encabezado
  // M11 (que siempre usa fondo oscuro/translúcido en los tres temas). Se
  // fija una sola vez al iniciar, según el tema resuelto en ese momento.
  function _ajustarBarraDeEstado() {
    const StatusBar = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar;
    if (!StatusBar) return;
    try {
      const claro = document.documentElement.getAttribute('data-tema') === 'claro';
      StatusBar.setBackgroundColor({ color: claro ? '#eef2f7' : '#0f172a' });
      StatusBar.setStyle({ style: claro ? 'DARK' : 'LIGHT' });
    } catch (e) { /* ajuste cosmético: si falla, no afecta el resto de la app */ }
  }

  // Abre la URL de la casa de apuestas de forma controlada. Con Capacitor
  // disponible, usa el navegador integrado (el operador nunca sale de la
  // app del todo); si no, usa window.open() como siempre. onRegreso()
  // se llama cuando el navegador integrado se cierra (evento
  // 'browserFinished') — sirve para volver a enfocar el Centro de
  // Decisiones, que ya tiene ahí mismo "¿Realizó la apuesta?" esperando.
  function abrirCasaDeApuestas(url, onRegreso) {
    const Browser = _capacitorBrowser();
    if (Browser) {
      try {
        Browser.open({ url });
        Browser.addListener('browserFinished', () => { if (onRegreso) onRegreso(); }, { once: true });
        return;
      } catch (e) { /* si falla el navegador integrado, cae al método normal */ }
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  function init() {
    const App = _capacitorApp();
    if (!App) return; // no está corriendo dentro de la app de Android: no hace nada
    App.addListener('backButton', manejarBotonAtras);
    _ajustarBarraDeEstado();
  }

  M11.Android = { init, manejarBotonAtras, abrirCasaDeApuestas };

})(window.M11);

