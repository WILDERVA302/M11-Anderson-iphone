/* Conciliación segura de Operación Normal: una sola verdad para Inicio y Plantillas. */
window.M11=window.M11||{};
(function(M11){
  'use strict';
  const KEY='m11_real_activity_v3', VERIFY_KEY='m11_real_result_candidates_v1', STABILITY_MS=4*60*1000;
  let running=false;
  function json(key,fallback){try{return JSON.parse(localStorage.getItem(key)||JSON.stringify(fallback));}catch(_){return fallback;}}
  function load(){return json(KEY,{events:[]});}
  function remember(event){const s=load();s.events=[event,...(s.events||[]).filter(e=>e.key!==event.key)].slice(0,30);localStorage.setItem(KEY,JSON.stringify(s));}
  function kickoff(p){return new Date(p.timestampUTC||`${p.fecha}T${p.hora}:00`).getTime();}
  function perteneceOperacion(p){
    const op=M11.Operaciones&&M11.Operaciones.getActiva?M11.Operaciones.getActiva():null,liga=M11.LeagueService&&M11.LeagueService.getLigaActiva?M11.LeagueService.getLigaActiva():null;
    if(!op)return false;
    if(p.operationId&&String(p.operationId)!==String(op.id))return false;
    if(liga&&p.leagueId&&String(p.leagueId)!==String(liga.leagueId))return false;
    const inicio=new Date(op.fechaInicio||0).getTime();
    return !Number.isFinite(inicio)||kickoff(p)>=inicio;
  }
  function label(p){return `${p.equipoLocal||p.homeTeam} vs ${p.equipoVisitante||p.awayTeam}`;}
  function explicitFinal(raw){const s=String(raw&&raw.strStatus||'').trim().toLowerCase();return s.includes('match finished')||s.includes('finished')||['ft','aet','pen'].includes(s);}
  function candidateConfirmed(p,n,raw){
    if(!n||n.status!=='finalizado'||!n.resultadoSugerido)return false;
    const score=`${n.homeScore}-${n.awayScore}`;
    if(explicitFinal(raw))return true;
    const all=json(VERIFY_KEY,{}),old=all[p.externalId],now=Date.now();
    if(old&&old.score===score&&old.result===n.resultadoSugerido&&now-old.firstSeen>=STABILITY_MS){delete all[p.externalId];localStorage.setItem(VERIFY_KEY,JSON.stringify(all));return true;}
    all[p.externalId]={score,result:n.resultadoSugerido,firstSeen:old&&old.score===score?old.firstSeen:now,lastSeen:now};localStorage.setItem(VERIFY_KEY,JSON.stringify(all));return false;
  }
  async function verify(p){
    if(!p||!p.externalId||!M11.SportsApi||!M11.SportsApi.consultarPartido)return null;
    try{const raw=await M11.SportsApi.consultarPartido(p.externalId);if(!raw)return null;const n=M11.SportsApi.normalizeSportsDbEvent(raw,{leagueId:p.leagueId,leagueName:p.torneo});if(['cancelado','suspendido'].includes(n.status))return n;return candidateConfirmed(p,n,raw)?n:null;}catch(_){return null;}
  }
  async function repairHistorical(){
    if(!M11.Libro||!M11.Libro.listar)return 0;
    const decision=M11.Store.getDecision();if(decision&&decision.estado==='PENDIENTE_RESULTADO')return 0;
    const records=M11.Libro.listar().filter(r=>r.externalId&&['empate','no_empate'].includes(r.resultado)).slice(-8).reverse();let repaired=0;
    for(const r of records){
      const p=M11.Calendario.obtenerPorExternalId('TheSportsDB',r.externalId)||{externalId:r.externalId,torneo:r.torneo,equipoLocal:r.equipoLocal,equipoVisitante:r.equipoVisitante};
      let raw,n;try{raw=await M11.SportsApi.consultarPartido(r.externalId);if(!raw)continue;n=M11.SportsApi.normalizeSportsDbEvent(raw,{leagueName:r.torneo});}catch(_){continue;}
      if(!n)continue;
      const resultadoFuente=['cancelado','suspendido'].includes(n.status)?n.status:(n.status==='finalizado'?n.resultadoSugerido:null);
      if(!resultadoFuente||resultadoFuente===r.resultado)continue;
      const out=M11.Libro.corregirResultadoYReconstruir(r.externalId,resultadoFuente,{provider:'TheSportsDB',score:{home:n.homeScore,away:n.awayScore},status:n.status,checkedAt:new Date().toISOString()});
      if(out&&out.cambiado){repaired++;remember({key:`corrected-${r.externalId}`,type:'corrected',at:new Date().toISOString(),match:label(p),result:resultadoFuente,score:{home:n.homeScore,away:n.awayScore}});}
    }
    return repaired;
  }
  async function reconcile(){
    if(running||!M11.Store||M11.Store.getCentroPruebas())return {settled:0,missed:0,repaired:0};
    running=true;let settled=0,missed=0,repaired=0;
    try{
      if(M11.Libro&&M11.Libro.repararIntegridad)M11.Libro.repararIntegridad();
      const decision=M11.Store.getDecision();
      if(decision&&decision.estado==='PENDIENTE_RESULTADO'){
        const p=M11.Calendario.obtener(decision.partidoId),verified=await verify(p);
        if(verified){const result=['cancelado','suspendido'].includes(verified.status)?verified.status:verified.resultadoSugerido;M11.Transiciones.registrarResultado(result);remember({key:`settled-${p.id}`,type:'settled',at:new Date().toISOString(),match:label(p),kickoff:p.timestampUTC||null,result,score:{home:verified.homeScore,away:verified.awayScore},source:'TheSportsDB · estado final verificado'});M11.Transiciones.continuarDespuesDeFinalizado();settled++;}
        else if(p&&p.resultadoContradictorio){remember({key:`review-${p.id}`,type:'review',at:new Date().toISOString(),match:label(p),kickoff:p.timestampUTC||null});M11.Transiciones.abrirCierre();}
      }
      // Una salida a la casa todavía no es una apuesta confirmada, pero sí
      // es una decisión abierta. Debe quedar protegida de la conciliación
      // automática hasta que el operador pulse APOSTÉ o NO APOSTÉ.
      const active=M11.Store.getDecision(),confirming=M11.Store.getPartidoEnConfirmacion&&M11.Store.getPartidoEnConfirmacion();
      const activeIds=new Set([active&&active.partidoId,confirming&&confirming.id].filter(Boolean).map(String));
      M11.Calendario.listar().filter(perteneceOperacion).slice().sort((a,b)=>kickoff(a)-kickoff(b)).forEach(p=>{
        const gracia=(M11.CONFIG&&M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN||5)*60000;
        if(activeIds.has(String(p.id))||!Number.isFinite(kickoff(p))||kickoff(p)+gracia>Date.now())return;
        M11.Calendario.marcarEstado(p.id,p.estadoApi==='finalizado'?'finalizado':'sin_accion');
        const record=M11.Libro.registrarSinAccion(p);if(!record)return;
        remember({key:`missed-${p.id}`,type:'missed',at:new Date().toISOString(),match:label(p),kickoff:p.timestampUTC||null,result:p.estadoApi==='finalizado'?p.resultadoSugerido:null});missed++;
      });
      repaired=await repairHistorical();return {settled,missed,repaired};
    }finally{running=false;}
  }
  function latest(){return load().events||[];}
  function render(){
    const box=document.getElementById('realActivityCard');if(!box)return;const events=latest(),last=events[0],missed=events.filter(e=>e.type==='missed').slice(0,3);
    if(!last){box.classList.add('hidden');return;}box.classList.remove('hidden');
    const result=e=>e.result==='empate'?'Empate':e.result==='no_empate'?'No empate':e.result==='cancelado'?'Cancelado':e.result==='suspendido'?'Suspendido/anulado':'Resultado pendiente de la fuente',score=last.score?` · ${last.score.home}–${last.score.away}`:'';
    const title=last.type==='settled'?'Resultado final verificado':last.type==='corrected'?'Resultado corregido automáticamente':last.type==='review'?'Revisión necesaria':'Partido sin acción registrada';
    const body=last.type==='settled'?`${result(last)}${score}. Capital y niveles fueron actualizados con el resultado final.`:last.type==='corrected'?`La fuente corrigió el marcador a ${result(last)}${score}. Plantillas, capital y niveles fueron reconstruidos automáticamente.`:last.type==='review'?'La fuente publicó datos contradictorios. Este es el único caso que requiere revisión manual.':'La hora del partido pasó y no quedó una apuesta registrada en el aplicativo. No se modificaron capital ni niveles.';
    box.innerHTML=`<div class="eyebrow">ACTIVIDAD AUTOMÁTICA</div><h2>${title}</h2><p><strong>${last.match}</strong></p><p>${body}</p>${missed.length?`<details><summary>Partidos no atendidos (${missed.length})</summary>${missed.map(e=>`<p>${e.match} · ${e.kickoff?M11.SportsApi.formatearFechaHora(new Date(e.kickoff).getTime()):'Hora no disponible'}</p>`).join('')}</details>`:''}`;
  }
  async function syncNow(force){if(M11.LeagueService&&M11.LeagueService.getLigaActiva())await M11.LeagueService.sincronizar({forzar:!!force});const out=await reconcile();render();if(M11.UI)M11.UI.render();return out;}
  let started=false;
  function start(){
    if(started)return;
    started=true;
    syncNow(true).catch(()=>{render();});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)syncNow(true).catch(()=>{});});
    setInterval(()=>syncNow(true).catch(()=>{}),5*60000);
  }
  function init(){
    // La red y la conciliación no arrancan sobre el formulario de acceso.
    // El login debe responder primero, aunque el proveedor entregue cientos
    // de partidos o exista un historial antiguo que requiera revisión.
    document.addEventListener('m11:authenticated',start);
    if(localStorage.getItem('m11Session')==='active')setTimeout(start,0);
  }
  M11.RealSync={reconcile,render,latest,syncNow,verify,repairHistorical,init};
})(window.M11);
