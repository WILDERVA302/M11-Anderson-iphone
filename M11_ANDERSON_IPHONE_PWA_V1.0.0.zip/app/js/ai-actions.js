/* M11 V2.1.5 — acciones verificables del Administrador IA.
   La IA verifica hechos externos. Los cálculos y cambios de capital siempre
   pasan por los motores deterministas de Operación Real y Ficticia. */
window.M11=window.M11||{};
(function(M11){
  'use strict';
  const $=s=>document.querySelector(s);
  const money=n=>new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(Number(n)||0);
  const percent=n=>`${Number(n||0).toFixed(2).replace('.',',')}%`;
  const day=v=>{try{return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Bogota',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(v));}catch(_){return'';}};
  let lastSyncReport=null;
  let lastRealReportCanvas=null;

  function migrateChampionshipIdentity(){
    if(localStorage.getItem('m11_identity_migration_v214')==='done'||!M11.LabHub)return;
    const bySlot=new Map(M11.LabHub.load().map(s=>[Number(s.slot),s]));
    try{
      const operations=JSON.parse(localStorage.getItem('m11_operaciones_v1')||'{}');
      Object.values(operations).forEach(op=>{const slot=bySlot.get(Number(op.labSlot));if(!slot)return;op.nombre=slot.name;op.leagueName=slot.name;op.leagueId=String(slot.leagueId||'');op.country=slot.country||'';});
      localStorage.setItem('m11_operaciones_v1',JSON.stringify(operations));
      if(M11.ShadowStore){const experiment=M11.ShadowStore.load();(experiment.tournaments||[]).forEach(t=>{const slot=bySlot.get(Number(t.labSlot));if(!slot)return;t.name=slot.name;t.leagueId=String(slot.leagueId||'');t.country=slot.country||'';});M11.ShadowStore.save(experiment);}
      localStorage.setItem('m11_identity_migration_v214','done');
    }catch(err){console.warn('No se pudo migrar la identidad de campeonatos V2.1.4',err);}
  }

  function shadowSnapshot(){
    const experiment=M11.ShadowStore?M11.ShadowStore.load():{tournaments:[]};
    const operations=(experiment.tournaments||[]).map(t=>{
      const current=M11.ShadowEngine.totalCapital(t),initial=Number(t.initialCapital)||0;
      const st=t.strategies||{},tracking=t.tracking||{};
      return {id:t.id,name:t.name,leagueId:String(t.leagueId||''),initial,current,profitLoss:current-initial,returnPercent:initial?(current-initial)/initial*100:0,records:(t.history||[]).length,levels:{general:st.general&&st.general.level,pares:st.pares&&st.pares.level,impares:st.impares&&st.impares.level},pending:(tracking.pendingEvents||[]).length,missing:(tracking.missingEvents||[]).length};
    });
    const sum=f=>operations.reduce((s,o)=>s+(Number(o[f])||0),0),initial=sum('initial'),current=sum('current');
    return {generatedAt:new Date().toISOString(),operationCount:operations.length,totals:{initial,current,profitLoss:current-initial,returnPercent:initial?(current-initial)/initial*100:0},operations};
  }

  function reportLines(kind,snapshot){
    const stamp=new Date().toLocaleString('es-CO',{timeZone:'America/Bogota',dateStyle:'long',timeStyle:'short'});
    if(kind==='real'){
      const t=snapshot.totals;
      const lines=[`INFORME DE OPERACIÓN REAL M11`,stamp,'',`Capital asignado: ${money(t.assignedCapital)}`,`Capital actual: ${money(t.currentCapital)}`,`Disponible: ${money(t.availableCapital)}`,`Comprometido: ${money(t.committedCapital)}`,`${t.profitLoss>=0?'Utilidad':'Pérdida'} acumulada: ${money(t.profitLoss)} (${percent(t.returnOnAssignedPercent)})`,`Total apostado histórico: ${money(t.totalBetHistorical)}`,'',`AYER`,`Apostado: ${money(snapshot.yesterday.totalBet)} · Retornado: ${money(snapshot.yesterday.totalReturned)}`,`Resultado: ${money(snapshot.yesterday.profitLoss)} · Pendientes: ${snapshot.yesterday.pendingCount}`,'',`HOY`,`Apostado: ${money(snapshot.today.totalBet)} · Pendiente: ${money(snapshot.today.pendingBet)}`,'',`POR CAMPEONATO`];
      snapshot.byOperation.slice().sort((a,b)=>b.profitLoss-a.profitLoss).forEach(o=>lines.push(`${o.name}: ${o.profitLoss>=0?'+':''}${money(o.profitLoss)} · capital ${money(o.currentCapital)}`));
      return lines;
    }
    const t=snapshot.totals,lines=[`INFORME DE OPERACIÓN FICTICIA M11`,stamp,'',`Capital inicial simulado: ${money(t.initial)}`,`Capital actual simulado: ${money(t.current)}`,`${t.profitLoss>=0?'Utilidad':'Pérdida'} simulada: ${money(t.profitLoss)} (${percent(t.returnPercent)})`,`Campeonatos: ${snapshot.operationCount}`,'',`POR CAMPEONATO`];
    snapshot.operations.slice().sort((a,b)=>b.profitLoss-a.profitLoss).forEach(o=>lines.push(`${o.name}: ${o.profitLoss>=0?'+':''}${money(o.profitLoss)} (${percent(o.returnPercent)}) · registros ${o.records} · pendientes ${o.pending+o.missing}`));
    lines.push('','Operación simulada: no representa dinero apostado en una casa de apuestas.');return lines;
  }

  function syncLines(report){
    const lines=['INFORME DE SINCRONIZACIÓN FICTICIA M11',new Date(report.generatedAt).toLocaleString('es-CO',{timeZone:'America/Bogota',dateStyle:'long',timeStyle:'short'}),'',`Solicitados: ${report.requested}`,`Verificados: ${report.verified}`,`Liquidados por el motor M11: ${report.applied}`,`Sin resolver: ${report.unresolved}`,`Conflictos: ${report.conflicts}`,''];
    (report.items||[]).forEach(x=>lines.push(`${x.status==='verified'?'✓':'⚠'} ${x.match} — ${x.detail}`));return lines;
  }

  function wrap(ctx,text,maxWidth){
    if(!text)return[''];const words=String(text).split(/\s+/),out=[];let line='';
    words.forEach(word=>{const next=line?`${line} ${word}`:word;if(ctx.measureText(next).width>maxWidth&&line){out.push(line);line=word;}else line=next;});if(line)out.push(line);return out;
  }
  function makeImage(lines,titleType){
    const width=1200,pad=76,maxWidth=width-pad*2,lineHeight=48;
    const measure=document.createElement('canvas').getContext('2d');measure.font='30px system-ui, sans-serif';
    const rows=[];lines.forEach((text,i)=>wrap(measure,text,maxWidth).forEach((part,j)=>rows.push({text:part,heading:i===0,blank:!text,continuation:j>0})));
    const height=Math.max(800,180+rows.reduce((s,r)=>s+(r.heading?72:r.blank?28:lineHeight),0)+80);
    const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const c=canvas.getContext('2d');
    c.fillStyle='#eef3fb';c.fillRect(0,0,width,height);c.fillStyle='#101a34';c.fillRect(0,0,width,24);
    c.fillStyle='#fff';c.strokeStyle='#d7dfec';c.lineWidth=2;c.beginPath();c.roundRect(36,48,width-72,height-88,30);c.fill();c.stroke();
    let y=118;rows.forEach(r=>{if(r.heading){c.font='700 44px system-ui, sans-serif';c.fillStyle='#101a34';}else{c.font=r.continuation?'30px system-ui, sans-serif':'500 30px system-ui, sans-serif';c.fillStyle=/Pérdida|-$|⚠|Sin resolver|Conflictos/.test(r.text)?'#b42318':/^Utilidad|^✓|\+/.test(r.text)?'#067647':'#172033';}c.fillText(r.text,pad,y);y+=r.heading?72:r.blank?28:lineHeight;});
    c.font='24px system-ui, sans-serif';c.fillStyle='#667085';c.fillText('Generado por M11 · cálculos del dispositivo · '+titleType,pad,height-68);return canvas;
  }
  async function saveCanvas(canvas,filename,title){
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png',1));
    const plugins=window.Capacitor&&window.Capacitor.Plugins;
    if(plugins&&plugins.Filesystem&&plugins.Share){
      const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(blob);});
      const saved=await plugins.Filesystem.writeFile({path:filename,data,directory:'CACHE'});await plugins.Share.share({title,text:'Informe generado por M11',url:saved.uri,dialogTitle:'Guardar, ampliar o compartir informe'});return;
    }
    const file=new File([blob],filename,{type:'image/png'});if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title,files:[file]});return;}
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  async function downloadAnswer(title,text,filename){const lines=[String(title||'RESPUESTA DEL ADMINISTRADOR IA M11').toUpperCase(),new Date().toLocaleString('es-CO',{timeZone:'America/Bogota',dateStyle:'long',timeStyle:'short'}),'',...String(text||'Sin contenido.').split('\n')];return saveCanvas(makeImage(lines,'Administrador IA'),filename||`M11_respuesta_IA_${day(new Date())}.png`,title);}
  async function createReport(kind){
    const status=$('#aiActionStatus');status.textContent='Calculando y preparando la imagen…';
    try{
      const snapshot=kind==='real'?M11.AIAdmin.financialSnapshot():shadowSnapshot();
      if(!snapshot.operationCount)throw new Error(`No existen campeonatos con datos en Operación ${kind==='real'?'Real':'Ficticia'}.`);
      const lines=reportLines(kind,snapshot),canvas=makeImage(lines,kind==='real'?'Operación Real':'Operación Ficticia');
      if(kind==='real'){
        lastRealReportCanvas=canvas;
        const image=$('#realReportImage'),preview=$('#realReportPreview');
        if(image)image.src=canvas.toDataURL('image/png',1);
        if(preview)preview.classList.remove('hidden');
        status.textContent='Informe generado. Incluye el resultado de ayer. Abriendo las aplicaciones para compartir…';
        // Se conserva el comportamiento que el usuario ya conocía: el
        // primer botón genera la imagen y abre inmediatamente la hoja de
        // Android (WhatsApp, guardar, correo, etc.). La vista previa queda
        // además en M11 por si la ventana se cancela o Android no la abre.
        await saveCanvas(canvas,`M11_informe_real_${day(new Date())}.png`,lines[0]);
        status.textContent='Informe generado. Puede verlo abajo y fue preparado para compartir por WhatsApp u otra aplicación.';
        if(preview)preview.scrollIntoView({behavior:'smooth',block:'start'});
        return;
      }
      await saveCanvas(canvas,`M11_informe_${kind}_${day(new Date())}.png`,lines[0]);
      status.textContent='Informe generado. Ya puede guardarlo, ampliarlo o compartirlo.';
    }catch(err){status.textContent='No fue posible generar el informe: '+(err.message||err);}
  }

  function unresolvedEvents(){
    const list=[];(M11.ShadowStore.load().tournaments||[]).forEach(t=>{const tracking=t.tracking||{};[...(tracking.pendingEvents||[]),...(tracking.missingEvents||[])].forEach(e=>list.push({requestId:`${t.id}::${e.externalId}`,tournamentId:t.id,eventId:e.externalId,chronologicalNumber:e.chronologicalNumber,competition:t.name,leagueId:String(t.leagueId||''),home:e.homeTeam||'',away:e.awayTeam||'',date:day(e.timestampUTC||e.kickoffUTC),timestampUTC:e.timestampUTC||e.kickoffUTC||null,currentStatus:e.status||'unresolved'}));});return list;
  }
  function realCandidates(){
    const out=[];Object.keys(localStorage).filter(k=>/^m11Libro(?:__|$)/.test(k)&&!/Contador|Migrado|Error/.test(k)).forEach(key=>{try{(JSON.parse(localStorage.getItem(key)||'[]')||[]).forEach(r=>{const p=r.partidoSnapshot||r.partido||r;const result=r.resultado==='empate'?'draw':r.resultado==='no_empate'?'not_draw':null;if(result&&p)out.push({competition:r.nombreOperacion||r.torneo||p.torneo||'',home:p.equipoLocal||p.homeTeam||'',away:p.equipoVisitante||p.awayTeam||'',date:day(p.timestampUTC||r.fechaHoraPartido||r.fechaHora),result,score:r.marcador||null,source:'confirmed_real_operation'});});}catch(_){}});return out;
  }
  async function syncWithAI(){
    const button=$('#aiShadowSyncBtn'),status=$('#aiActionStatus');button.disabled=true;status.textContent='Primero sincronizando el proveedor deportivo…';
    try{
      if(M11.ShadowSync)await M11.ShadowSync.syncAll({force:true,useAiFallback:true});
      const unresolved=unresolvedEvents();if(!unresolved.length){lastSyncReport={generatedAt:new Date().toISOString(),requested:0,verified:0,applied:0,unresolved:0,conflicts:0,items:[]};status.textContent='Sincronización terminada: no hay resultados pendientes ni partidos perdidos.';$('#aiSyncReportBtn').disabled=false;return;}
      status.textContent=`La IA está verificando ${unresolved.length} partido(s) por equipos, campeonato y fecha…`;
      const data=await M11.AIAdmin.callService('verify_results',{context:{timeZone:'America/Bogota',unresolved,realCandidates:realCandidates(),matchPolicy:'competition + both teams + date must match; never infer'}});
      const byId=new Map(unresolved.map(x=>[x.requestId,x]));let applied=0,verified=0,conflicts=0;const items=[];
      const ordered=(data.results||[]).slice().sort((a,b)=>(byId.get(a.requestId)?.chronologicalNumber||999999)-(byId.get(b.requestId)?.chronologicalNumber||999999));
      for(const result of ordered){
        const request=byId.get(result.requestId);if(!request)continue;
        if(result.status==='verified'&&['draw','not_draw'].includes(result.result)){
          verified+=1;try{const response=M11.ShadowSync.resolvePending(request.tournamentId,request.eventId,result.result);if(response&&response.applied)applied+=1;}catch(err){items.push({status:'conflict',match:`${request.competition}: ${request.home} vs ${request.away}`,detail:'Verificado, pero no aplicado: '+(err.message||err)});conflicts+=1;continue;}
        }else if(result.status==='conflict')conflicts+=1;
        items.push({status:result.status,match:`${request.competition}: ${request.home} vs ${request.away}`,detail:result.status==='verified'?`${result.score||result.result} · ${result.sourceName||result.sourceType}`:result.reason||'No se encontró evidencia suficiente.'});
      }
      const unresolvedCount=Math.max(0,unresolved.length-verified-conflicts);lastSyncReport={generatedAt:new Date().toISOString(),requested:unresolved.length,verified,applied,unresolved:unresolvedCount,conflicts,items};
      $('#aiSyncReportBtn').disabled=false;status.textContent=`Sincronización finalizada: ${verified} verificado(s), ${applied} liquidado(s) por el motor M11, ${unresolvedCount} sin resolver y ${conflicts} conflicto(s).`;
      await downloadSyncReport();
      if(M11.ShadowUI)M11.ShadowUI.render();
    }catch(err){status.textContent='No fue posible sincronizar con IA: '+(err.message||err)+' Los datos y el capital ficticio no fueron alterados.';}finally{button.disabled=false;}
  }
  async function downloadSyncReport(){if(!lastSyncReport)return;const canvas=makeImage(syncLines(lastSyncReport),'Sincronización Ficticia');await saveCanvas(canvas,`M11_sincronizacion_ficticia_${day(new Date())}.png`,'Sincronización ficticia M11');}
  function init(){
    $('#aiRealReportBtn')&&$('#aiRealReportBtn').addEventListener('click',()=>createReport('real'));
    $('#shareRealReportBtn')&&$('#shareRealReportBtn').addEventListener('click',async()=>{
      const status=$('#aiActionStatus'),button=$('#shareRealReportBtn');
      if(!lastRealReportCanvas){status.textContent='Primero genere el informe para poder compartirlo.';return;}
      button.disabled=true;button.textContent='PREPARANDO…';
      try{await saveCanvas(lastRealReportCanvas,`M11_informe_real_${day(new Date())}.png`,'INFORME DE OPERACIÓN REAL M11');status.textContent='Informe preparado para guardar o compartir.';}
      catch(err){status.textContent='No fue posible abrir la ventana de compartir: '+(err.message||err);}
      finally{button.disabled=false;button.textContent='COMPARTIR O GUARDAR INFORME';}
    });
  }
  M11.AIActions={init,shadowSnapshot,reportLines,unresolvedEvents,realCandidates,syncWithAI,migrateChampionshipIdentity,downloadAnswer};
})(window.M11);
