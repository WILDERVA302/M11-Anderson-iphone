/* =========================================================
   M11 · evaluacion-ui.js
   -----------------------------------------------------------
   Renderizado de la Evaluación de recorrido M11. Lee
   exclusivamente de M11.Evaluacion — nunca recalcula nada por su
   cuenta. Vive por ahora dentro de Plantillas M11 (Sprint V1.0),
   pero se mantiene separada a propósito para poder trasladarla a
   un futuro módulo de Reportes sin tocar su lógica.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);

  function pillCondicion(cumple, etiqueta) {
    return `<span class="pill ${cumple ? 'verde' : 'gris'}">${cumple ? '✓' : '—'} ${etiqueta}</span>`;
  }

  function construirFichaEvaluacion(ev) {
    return `<article class="evaluacion-ficha">
      <div class="evaluacion-ficha-header">
        <strong>Bloque ${ev.bloque}</strong>
        <span class="legal-note">Partidos ${ev.desde}–${ev.hasta}</span>
      </div>
      <div class="evaluacion-condiciones">
        ${pillCondicion(ev.cumpleC1, `C1 · ${ev.empates} empates (${ev.porcentajeEmpates}%)`)}
        ${pillCondicion(ev.cumpleC2, ev.primerEmpatePosicion !== null ? `C2 · 1er empate en la posición ${ev.primerEmpatePosicion}` : 'C2 · Sin empates en el bloque')}
        ${pillCondicion(ev.cumpleC3, 'C3 · Empates consecutivos (16–20)')}
      </div>
      <p class="evaluacion-resultado">${ev.condicionesCumplidas} de 3 condiciones favorables</p>
      <p class="evaluacion-mensaje">${ev.mensaje}</p>
    </article>`;
  }

  function render() {
    const box = $('#evaluacionContenido');
    if (!box || !M11.Evaluacion) return;
    const todas = M11.Evaluacion.listar().slice().reverse(); // más reciente primero
    if (!todas.length) {
      box.innerHTML = '<div class="empty">Todavía no se completó el primer bloque de 20 partidos. La evaluación de recorrido aparecerá automáticamente al cerrarse.</div>';
      return;
    }
    const [ultima, ...anteriores] = todas;
    box.innerHTML = `
      <div class="eyebrow">EVALUACIÓN MÁS RECIENTE</div>
      ${construirFichaEvaluacion(ultima)}
      ${anteriores.length ? `<div class="eyebrow" style="margin-top:14px">BLOQUES ANTERIORES</div>${anteriores.map(construirFichaEvaluacion).join('')}` : ''}
    `;
  }

  // ---- Aviso no invasivo al cerrarse un bloque -----------------------------
  function pintarAviso() {
    const el = $('#avisoEvaluacion');
    if (!el || !M11.Evaluacion) return;
    const pendientes = M11.Evaluacion.avisosPendientes();
    if (!pendientes.length) { el.classList.add('hidden'); return; }
    const bloque = pendientes[0];
    const ev = M11.Evaluacion.obtener(bloque);
    if (!ev) { el.classList.add('hidden'); return; }
    // Solo reconstruir si cambió el bloque mostrado, para no pisar una
    // interacción del operador en curso (mismo criterio que el resto de
    // la interfaz).
    if (el.dataset.bloque === String(bloque)) { el.classList.remove('hidden'); return; }
    el.dataset.bloque = String(bloque);
    el.innerHTML = `
      <span>📊 <strong>Evaluación de recorrido M11 — Bloque ${ev.bloque} completado.</strong> ${ev.condicionesCumplidas} de 3 condiciones favorables. Ver detalle en Plantillas M11.</span>
      <button type="button" id="avisoEvaluacionCerrarBtn" aria-label="Cerrar aviso">✕</button>
    `;
    el.classList.remove('hidden');
  }

  M11.EvaluacionUI = { render, pintarAviso };

})(window.M11);
