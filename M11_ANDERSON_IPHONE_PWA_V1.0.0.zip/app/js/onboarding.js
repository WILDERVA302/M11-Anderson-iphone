(function (M11) {
  'use strict';
  function $(sel) { return document.querySelector(sel); }
  function fmt(n) { return '$' + Math.round(n).toLocaleString('es-CO'); }

  function mostrarPaso(n) {
    for (let i = 1; i <= 6; i++) $('#ob-' + i).classList.toggle('hidden', i !== n);
    const el = $('#onboardingModule');
    if (el && el.scrollIntoView) el.scrollTo && el.scrollTo(0, 0);
  }

  function capitalMinimo(base) {
    // Misma fórmula que ya usa el motor: BASE × 2047 por estrategia × 3.
    return base * 2047 * 3;
  }

  function init() {
    if (!$('#onboardingModule')) return;

    $('#obComenzarBtn').addEventListener('click', () => mostrarPaso(2));

    $('#obBase').addEventListener('input', () => {
      const base = Number($('#obBase').value) || 0;
      $('#obCapitalMinimo').textContent = fmt(capitalMinimo(base));
    });
    $('#obCapitalMinimo').textContent = fmt(capitalMinimo(1000));

    $('#obPaso2SiguienteBtn').addEventListener('click', () => {
      const base = Number($('#obBase').value) || 1000;
      const minimo = capitalMinimo(base);
      $('#obCapitalMinimo3').textContent = fmt(minimo);
      $('#obCapitalRegistrado').value = minimo;
      $('#obCapitalRegistrado').min = minimo;
      mostrarPaso(3);
    });

    $('#obPaso3SiguienteBtn').addEventListener('click', () => {
      const base = Number($('#obBase').value) || 1000;
      const minimo = capitalMinimo(base);
      const registrado = Number($('#obCapitalRegistrado').value) || 0;
      if (registrado < minimo) {
        $('#obCapitalError').classList.remove('hidden');
        return;
      }
      $('#obCapitalError').classList.add('hidden');
      mostrarPaso(4);
    });

    $('#obPaso4SiguienteBtn').addEventListener('click', () => mostrarPaso(5));
    $('#obPaso5SiguienteBtn').addEventListener('click', () => {
      const base = Number($('#obBase').value) || 1000;
      const minimo = capitalMinimo(base);
      const registrado = Number($('#obCapitalRegistrado').value) || minimo;
      const pais = $('#obPais').value;
      const casa = $('#obCasa').value;
      const paisTxt = $('#obPais').selectedOptions[0] ? $('#obPais').selectedOptions[0].textContent : 'No configurado';
      const casaTxt = $('#obCasa').selectedOptions[0] ? $('#obCasa').selectedOptions[0].textContent : 'No configurada';
      $('#obResumen').innerHTML = `
        <div><span>Base</span><strong>${fmt(base)}</strong></div>
        <div><span>Capital mínimo</span><strong>${fmt(minimo)}</strong></div>
        <div><span>Capital registrado</span><strong>${fmt(registrado)}</strong></div>
        <div><span>País</span><strong>${pais ? paisTxt : 'No configurado'}</strong></div>
        <div><span>Casa de apuestas</span><strong>${casa ? casaTxt : 'No configurada'}</strong></div>
        <div><span>Torneo</span><strong>${$('#obTorneoNombre').textContent}</strong></div>
        <div><span>Estrategias activas</span><strong>General, Pares, Impares</strong></div>`;
      mostrarPaso(6);
    });

    $('#obIniciarOperacionBtn').addEventListener('click', () => {
      const base = Number($('#obBase').value) || 1000;
      const minimo = capitalMinimo(base);
      const registrado = Number($('#obCapitalRegistrado').value) || minimo;
      M11.Engine.CONFIG.BASE = base;
      M11.Store.guardarConfiguracionInicial({
        base,
        capitalDeclarado: registrado > minimo ? registrado : null,
        pais: $('#obPais').value || null,
        casaApuestas: $('#obCasa').value || null,
        torneo: $('#obTorneoNombre').textContent
      });
      M11.OnboardingUI.alTerminar();
    });

    mostrarPaso(1);
  }

  M11.OnboardingUI = {
    init,
    // Aplica la Base guardada al motor en cada carga de la app (el motor
    // arranca siempre en 1000 si no se le dice lo contrario). Debe
    // llamarse ANTES de cualquier render del Centro de Operaciones.
    aplicarConfiguracionGuardada() {
      const c = M11.Store.getConfiguracionInicial();
      if (c && c.base) M11.Engine.CONFIG.BASE = c.base;
    },
    // Se sobreescribe desde app.js/events.js con lo que corresponda
    // mostrar después (privateModule).
    alTerminar() {}
  };
})(window.M11);
