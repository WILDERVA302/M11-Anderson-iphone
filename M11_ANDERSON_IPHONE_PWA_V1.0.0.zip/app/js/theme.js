/* =========================================================
   M11 · theme.js  (Sprint 020)
   -----------------------------------------------------------
   Solo cambia el atributo data-tema del <html> y variables CSS —
   nunca toca cálculos, datos ni el motor M11. El script inline en
   el <head> de index.html ya aplicó el tema antes del primer pintado
   (evita el parpadeo); este módulo se encarga de:
   - guardar la preferencia cuando el operador la cambia en
     Configuración → Apariencia;
   - mantenerla al cerrar y volver a abrir (localStorage);
   - reaccionar en vivo si el modo es "auto" y el sistema operativo
     cambia de claro a oscuro (o viceversa) mientras la app está
     abierta, sin recargar la página.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_KEY = 'm11_tema_v1';
  const VALORES = ['claro', 'oscuro', 'auto'];

  function getPreferencia() {
    const guardado = localStorage.getItem(LS_KEY);
    return VALORES.includes(guardado) ? guardado : 'auto';
  }

  function prefiereOscuroElSistema() {
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }

  function resolver(preferencia) {
    if (preferencia === 'auto') return prefiereOscuroElSistema() ? 'oscuro' : 'claro';
    return preferencia === 'claro' ? 'claro' : 'oscuro';
  }

  function aplicar(preferencia) {
    document.documentElement.setAttribute('data-tema', resolver(preferencia));
  }

  function set(preferencia) {
    const valor = VALORES.includes(preferencia) ? preferencia : 'auto';
    localStorage.setItem(LS_KEY, valor);
    aplicar(valor);
  }

  function init() {
    aplicar(getPreferencia());
    // Si el modo activo es "auto", reacciona en vivo a un cambio de
    // preferencia del sistema operativo sin que el operador tenga que
    // recargar la página.
    if (window.matchMedia) {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      const onChange = () => { if (getPreferencia() === 'auto') aplicar('auto'); };
      if (media.addEventListener) media.addEventListener('change', onChange);
      else if (media.addListener) media.addListener(onChange); // navegadores antiguos
    }
  }

  M11.Theme = { getPreferencia, resolver, set, init, VALORES };

})(window.M11);
