/* Interfaz de configuración y consulta de Operación Sombra. */
window.M11 = window.M11 || {};
(function (M11) {
  'use strict';
  const $ = s => document.querySelector(s);
  const money = v => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(v || 0);
  const percent = v => v===null||v===undefined?'—':`${Number(v).toFixed(2).replace('.',',')}%`;
  let leaguesFound = [];
  let selectedTournamentId = null;
  let reportOnly = false;
  function escapeHtml(v) { const n = document.createElement('span'); n.textContent = String(v || ''); return n.innerHTML; }
  function statusLabel(s) { return ({ active:'Activo', paused:'Pausado', target_reached:'Meta alcanzada', all_strategies_closed:'Estrategias agotadas' })[s] || s; }
  function studyLabel() { return 'DESDE HOY — PROSPECTIVO'; }
  function openExternal(url) {
    if (!url) return;
    if (M11.Android) M11.Android.abrirCasaDeApuestas(url, function(){});
    else window.open(url, '_blank', 'noopener,noreferrer');
  }
  function flashscoreUrl(tournament) {
    const text=`${tournament.country||''} ${tournament.name||''}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(text.includes('libertadores'))return 'https://www.flashscore.co/futbol/sudamerica/copa-libertadores/resultados/';
    if(text.includes('champions'))return 'https://www.flashscore.co/futbol/europa/champions-league/resultados/';
    if(text.includes('premier'))return 'https://www.flashscore.co/futbol/inglaterra/premier-league/resultados/';
    if(text.includes('serie a')||text.includes('italia'))return 'https://www.flashscore.co/futbol/italia/serie-a/resultados/';
    if(text.includes('la liga')||text.includes('espana'))return 'https://www.flashscore.co/futbol/espana/laliga/resultados/';
    if(text.includes('colombia')||text.includes('dimayor')||text.includes('betplay'))return 'https://www.flashscore.co/futbol/colombia/primera-a/resultados/';
    return 'https://www.flashscore.co/futbol/';
  }
  function strategyLine(name, s) {
    const label = ({ general:'General', pares:'Pares', impares:'Impares' })[name];
    return `<div class="shadow-strategy ${s.closed?'closed':''}"><span>${label}</span><strong>${s.closed?'Cerrada':`Nivel ${s.level}`}</strong><small>${money(s.balance)}</small></div>`;
  }
  function tournamentCalendarBlock(tournament) {
    const calendar=M11.ShadowEngine.competitionCalendar(tournament);
    const operationStart=tournament.createdAt?new Date(tournament.createdAt).toLocaleDateString('es-CO',{day:'numeric',month:'long',year:'numeric'}):'No informado';
    if(!calendar)return `<section class="shadow-calendar"><div class="eyebrow">CALENDARIO DEL CAMPEONATO</div><p class="legal-note">Fechas oficiales no registradas para esta competición.</p><small>Operación Sombra iniciada: ${escapeHtml(operationStart)}</small></section>`;
    const statusLabel={upcoming:'Próximo',active:'En competencia',finished:'Finalizado'}[calendar.status];
    const remaining=calendar.status==='active'?` · ${calendar.daysRemaining} días aproximados restantes`:calendar.status==='upcoming'?` · inicia en ${calendar.daysRemaining} días`:'';
    return `<section class="shadow-calendar"><div class="shadow-calendar-head"><div class="eyebrow">CALENDARIO DEL CAMPEONATO</div><span class="pill ${calendar.status==='active'?'verde':'neutral'}">${statusLabel}</span></div><div class="shadow-calendar-dates"><div><span>Inicio</span><strong>${escapeHtml(calendar.startLabel)}</strong></div><div><span>Final ${calendar.estimatedEnd?'posible':'programada'}</span><strong>${escapeHtml(calendar.endLabel)}</strong></div></div>${calendar.phaseLabel?`<small>${escapeHtml(calendar.phaseLabel)}</small>`:''}<small>${calendar.estimatedEnd?'Fecha final aproximada; puede cambiar según la programación oficial.':`Calendario oficial${remaining}.`}</small><small><strong>Seguimiento M11 desde:</strong> ${escapeHtml(operationStart)}. Los resultados de M11 se calculan desde este corte, no desde el inicio del torneo.</small></section>`;
  }
  function renderCapitalUsage(experiment) {
    (experiment.tournaments||[]).forEach(t=>{
      const card=Array.from(document.querySelectorAll('[data-shadow-id]')).find(el=>el.dataset.shadowId===String(t.id)), metrics=card&&card.querySelector('.shadow-metrics');
      if(!metrics)return;
      const usage=M11.ShadowEngine.capitalUsage(t), capital=M11.ShadowEngine.totalCapital(t), pct=((capital-t.initialCapital)/t.initialCapital)*100;
      const benefitRatio=usage.maximumSequenceRequired?usage.netProfit/usage.maximumSequenceRequired*100:null;
      metrics.innerHTML=`<div class="capital-benefit"><span>Resultado con el capital máximo exigido</span><strong>${money(usage.netProfit)} / ${money(usage.maximumSequenceRequired)}</strong><small>Ratio utilidad ÷ capital máximo: ${percent(benefitRatio)}</small></div><div><span>Reserva teórica</span><strong>${money(usage.assigned)}</strong></div><div><span>Dinero movilizado</span><strong>${money(usage.totalUsed)}</strong><small>Suma de apuestas cerradas</small></div><div><span>Mayor capital requerido</span><strong>${money(usage.maximumSequenceRequired)}</strong><small>Hasta completar una secuencia</small></div><div><span>Mayor apuesta en un partido</span><strong>${money(usage.maximumUsed)}</strong></div><div><span>Reserva realmente exigida</span><strong>${percent(usage.capitalUsedPercent)}</strong></div><div><span>Utilidad/pérdida producida</span><strong class="${usage.netProfit>=0?'positive':'negative'}">${money(usage.netProfit)}</strong></div><div><span>Rendimiento sobre lo movilizado</span><strong>${percent(usage.returnOnMovementPercent)}</strong></div><div><span>Ratio utilidad / capital máximo</span><strong>${percent(benefitRatio)}</strong><small>Resultado histórico, no garantía futura</small></div><div><span>Patrimonio / retirable</span><strong>${money(capital)} / ${money(usage.withdrawableNow)}</strong></div><div><span>Comprometido / registros</span><strong>${money(usage.currentCommitted)} · ${t.history.length}</strong></div>`;
      const note=document.createElement('p');note.className='legal-note';note.textContent='La reserva teórica no equivale a dinero utilizado. “Dinero movilizado” es acumulado; “mayor capital requerido” muestra cuánto exigió la secuencia más profunda.';metrics.after(note);
    });
  }
  function renderPortfolioSummary(experiment) {
    const box=$('#shadowPortfolioSummary');
    if(!box)return;
    const usage=M11.ShadowEngine.portfolioCapitalUsage(experiment);
    box.classList.toggle('hidden',!usage.tournaments);
    if(!usage.tournaments){box.innerHTML='';return;}
    const usedPct=usage.assigned?usage.maximumPortfolioRequired/usage.assigned*100:null,movementPct=usage.totalUsed?usage.netProfit/usage.totalUsed*100:null,benefitRatio=usage.maximumPortfolioRequired?usage.netProfit/usage.maximumPortfolioRequired*100:null;
    box.innerHTML=`<div class="shadow-portfolio-head"><div><div class="eyebrow">CONSOLIDADO DE OPERACIÓN SOMBRA</div><h2>${usage.tournaments} campeonatos juntos</h2></div><span class="pill azul">${usage.records} resultados registrados</span></div><div class="capital-uso-grid">
      <div><span>Capital asignado total</span><strong>${money(usage.assigned)}</strong><small>Suma de los campeonatos</small></div>
      <div><span>Dinero movilizado acumulado</span><strong>${money(usage.totalUsed)}</strong><small>Suma de apuestas cerradas</small></div>
      <div class="capital-benefit"><span>Resultado con el capital máximo conjunto</span><strong>${money(usage.netProfit)} / ${money(usage.maximumPortfolioRequired)}</strong><small>Ratio utilidad ÷ capital máximo: ${percent(benefitRatio)}</small></div>
      <div><span>Capital máximo conjunto</span><strong>${money(usage.maximumPortfolioRequired)}</strong><small>Suma conservadora de los máximos por campeonato</small></div>
      <div><span>Mayor capital requerido</span><strong>${money(usage.maximumSequenceRequired)}</strong><small>En un solo campeonato</small></div>
      <div><span>Mayor apuesta en un partido</span><strong>${money(usage.maximumSingleMatch)}</strong></div>
      <div><span>Reserva realmente exigida</span><strong>${percent(usedPct)}</strong></div>
      <div><span>Utilidad/pérdida producida</span><strong class="${usage.netProfit>=0?'positive':'negative'}">${money(usage.netProfit)}</strong></div>
      <div><span>Rendimiento sobre lo movilizado</span><strong>${percent(movementPct)}</strong></div>
      <div><span>Ratio utilidad / capital máximo</span><strong>${percent(benefitRatio)}</strong><small>Resultado histórico, no garantía futura</small></div>
      <div><span>Comprometido ahora</span><strong>${money(usage.currentCommitted)}</strong><small>En todos los campeonatos</small></div>
      <div><span>Patrimonio ficticio actual</span><strong>${money(usage.patrimonioActual)}</strong><small>Disponible + comprometido</small></div>
      <div><span>Podría recoger ahora</span><strong>${money(usage.withdrawableNow)}</strong><small>Excluye partidos pendientes</small></div>
    </div><p class="legal-note">Este resumen reúne exclusivamente los ${usage.tournaments} campeonatos de Operación Sombra. La reserva es respaldo; el dinero movilizado es acumulado y puede reutilizarse.</p>`;
  }
  function historyBlock(tournament) {
    if(!tournament.history.length)return '<p class="legal-note">Todavía no hay resultados procesados.</p>';
    const rows=tournament.history.slice().sort((a,b)=>Number(b.chronologicalNumber)-Number(a.chronologicalNumber)).slice(0,10).map(r=>`<div class="shadow-history-row"><span>#${r.chronologicalNumber} · ${escapeHtml(r.homeTeam||'Local')} vs ${escapeHtml(r.awayTeam||'Visitante')}</span><strong>${r.result==='draw'?'Empate':r.result==='not_draw'?'No empate':r.result}</strong><small>${escapeHtml(r.label||'Simulada — no realizada')} · ${Number(r.experimentalQuota).toFixed(2).replace('.',',')} · ${r.profitabilityPercent.toFixed(2).replace('.',',')}%</small></div>`).join('');
    return `<details class="shadow-history"><summary>Ver últimos resultados sombra</summary>${rows}</details>`;
  }
  function planBlock(tournament) {
    const tracking=tournament.tracking||{}, plan=tracking.openPlan, missing=(tracking.missingEvents||[])[0];
    if(!plan)return tournament.studyMode==='retrospective'?'':missing?`<p class="legal-note"><strong>Operación detenida en el partido #${missing.chronologicalNumber}.</strong> No existe una apuesta ficticia activa posterior mientras la fuente no permita resolver este punto cronológico.</p>`:'<p class="legal-note">Sin apuesta ficticia preparada: esperando el siguiente partido cronológico disponible.</p>';
    const lines=Object.entries(plan.amounts||{}).map(([name,d])=>`${({general:'General',pares:'Pares',impares:'Impares'})[name]}: ${money(d.amount)} (nivel ${d.level})`).join(' · ');
    const committed=Object.values(plan.amounts||{}).reduce((sum,d)=>sum+Number(d.amount||0),0);
    const kickoff=plan.kickoffUTC?M11.SportsApi.formatearFechaHora(new Date(plan.kickoffUTC).getTime()):'Hora no informada';
    const registered=M11.SportsApi.formatearFechaHora(new Date(plan.plannedAt).getTime());
    const lockedCount=Object.values((tournament.tracking||{}).lockedEvents||{}).filter(e=>e.status==='eligible'&&e.externalId!==plan.externalId).length;
    return `<section class="shadow-plan"><div class="eyebrow">APUESTA FICTICIA PREPARADA — NO REALIZADA</div><strong>#${plan.chronologicalNumber} · ${escapeHtml(plan.homeTeam)} vs ${escapeHtml(plan.awayTeam)}</strong><small>Inicio: ${escapeHtml(kickoff)} · Cuota experimental ${Number(plan.experimentalQuota).toFixed(2).replace('.',',')}</small><p>${escapeHtml(lines)}</p><strong>Total ficticio comprometido: ${money(committed)}</strong><small>Registrada antes del partido: ${escapeHtml(registered)}</small>${lockedCount?`<small>${lockedCount} partido(s) posterior(es) ya numerados y elegibles; sus montos se calcularán en orden.</small>`:''}<button type="button" class="shadow-bet" data-shadow-amount="${committed}">APOSTAR ${money(committed)}</button><small class="shadow-bet-note">Abre la casa configurada. La simulación Sombra no cambia se pulse o no.</small></section>`;
  }
  function pendingBlock(tournament) {
    const pending=((tournament.tracking||{}).pendingEvents||[]);
    if(!pending.length)return '';
    const rows=pending.map(p=>{
      const when=p.timestampUTC?new Date(p.timestampUTC).toLocaleString('es-CO'):[p.fecha,p.hora].filter(Boolean).join(' ');
      const score=p.homeScore===null||p.homeScore===undefined||p.awayScore===null||p.awayScore===undefined?'Marcador no informado':`Marcador recibido: ${p.homeScore}–${p.awayScore}`;
      return `<div class="shadow-pending-row" data-shadow-event-id="${escapeHtml(p.externalId)}"><strong>#${p.chronologicalNumber} · ${escapeHtml(p.homeTeam||'Local')} vs ${escapeHtml(p.awayTeam||'Visitante')}</strong><small>${escapeHtml(when||'Fecha no informada')} · ${score} · Estado recibido: ${escapeHtml(p.status||'sin estado')}</small><div class="shadow-review-actions"><button type="button" class="ghost-small shadow-review" data-shadow-result="draw">EMPATE</button><button type="button" class="ghost-small shadow-review" data-shadow-result="not_draw">NO EMPATE</button><button type="button" class="ghost-small shadow-review" data-shadow-result="cancelled">CANCELADO</button><button type="button" class="ghost-small shadow-review" data-shadow-result="suspended">SUSPENDIDO</button></div></div>`;
    }).join('');
    return `<details class="shadow-pending" open><summary>⚠ Resultados pendientes de revisión (${pending.length})</summary><p class="legal-note">Confirme únicamente después de verificar el resultado. Esta decisión modifica el laboratorio sombra y queda registrada como revisión manual.</p>${rows}</details>`;
  }
  function queueBlock(tournament) {
    const tracking=tournament.tracking||{}, queued=tracking.queuedEvents||[], missing=tracking.missingEvents||[], lastRepair=(tracking.auditNotes||[]).filter(n=>n.type==='chronology_repair').at(-1);
    if(!queued.length&&!missing.length&&!lastRepair)return '';
    const missingRows=missing.map(m=>`<div class="shadow-queue-row"><strong>⚠ #${m.chronologicalNumber} · ${escapeHtml(m.homeTeam||'Partido previamente numerado')} ${m.awayTeam?`vs ${escapeHtml(m.awayTeam)}`:''}</strong><small>No localizado en la última sincronización ni en la consulta directa. La liquidación financiera queda detenida aquí; se volverá a consultar automáticamente.</small></div>`).join('');
    const rows=queued.map(q=>{const hasScore=Number.isFinite(Number(q.homeScore))&&Number.isFinite(Number(q.awayScore))&&q.homeScore!==null&&q.awayScore!==null;const provisional=q.status==='en_curso'&&hasScore?`En curso: ${q.homeScore}–${q.awayScore} (provisional)`:q.status==='en_curso'?'En curso — marcador provisional pendiente':q.result==='draw'?'Empate definitivo detectado':q.result==='not_draw'?'No empate definitivo detectado':'Resultado pendiente de verificar';return `<div class="shadow-queue-row"><strong>#${q.chronologicalNumber} · ${escapeHtml(q.homeTeam||'Local')} vs ${escapeHtml(q.awayTeam||'Visitante')}</strong><small>${escapeHtml(provisional)} · ${escapeHtml(q.reason)}</small></div>`;}).join('');
    return `<section class="shadow-queue"><div class="eyebrow">COLA CRONOLÓGICA</div>${lastRepair?'<p class="legal-note">Se corrigió el historial anterior sin modificar capital ni niveles.</p>':''}${missingRows}${rows||(!missingRows?'<p class="legal-note">La reparación cronológica quedó registrada.</p>':'')}</section>`;
  }
  function render() {
    const experiment = M11.ShadowStore.load(), count = experiment.tournaments.length;
    $('#shadowCount').textContent = `${count} de ${M11.ShadowEngine.MAX_TOURNAMENTS} campeonatos`;
    const hero=$('#shadowHeroCard');if(hero)hero.classList.toggle('hidden',!reportOnly);
    if(reportOnly)renderPortfolioSummary(experiment);else{$('#shadowPortfolioSummary').classList.add('hidden');$('#shadowPortfolioSummary').innerHTML='';}
    $('#shadowAddCard').classList.toggle('hidden', count >= M11.ShadowEngine.MAX_TOURNAMENTS);
    const list = $('#shadowTournamentList');
    if (!count) { list.innerHTML = '<section class="card empty"><strong>Aún no hay campeonatos sombra.</strong><p>Agregue el primero. Ningún dato de esta zona afecta la operación real.</p></section>'; return; }
    const visible=reportOnly?[]:(selectedTournamentId?experiment.tournaments.filter(t=>String(t.id)===String(selectedTournamentId)):experiment.tournaments.slice(0,1));
    if(!visible.length){list.innerHTML=reportOnly?'':'<section class="card empty"><strong>Este campeonato todavía no tiene seguimiento ficticio.</strong></section>';return;}
    list.innerHTML = visible.map(t => {
      const capital = M11.ShadowEngine.totalCapital(t), pct = ((capital-t.initialCapital)/t.initialCapital)*100;
      const tracking=t.tracking||{}; const sync=tracking.lastSyncAt?new Date(tracking.lastSyncAt).toLocaleString('es-CO'):'Sin sincronizar';
      return `<article class="card shadow-tournament ${t.status==='paused'?'is-paused':''}" data-shadow-id="${t.id}"><div class="shadow-card-head"><div><div class="eyebrow">SIMULADA — NO REALIZADA · MOTOR ${escapeHtml((M11.ShadowSync&&M11.ShadowSync.VERSION)||'')}</div><h2>${escapeHtml(t.name)}</h2><span class="pill azul">${studyLabel(t)}</span></div><span class="pill ${t.status==='active'?'verde':'gris'}">${statusLabel(t.status)}</span></div>${t.status==='paused'?'<div class="shadow-paused-note">⏸ Seguimiento pausado: no se prepararán nuevas acciones ni alarmas hasta reanudarlo.</div>':''}<p class="legal-note">${escapeHtml(t.country||'País no indicado')} · Temporada ${escapeHtml(t.season||'sin indicar')} · Cuota experimental <strong>${Number(t.experimentalQuota).toFixed(2).replace('.',',')}</strong></p>${tournamentCalendarBlock(t)}<button type="button" class="shadow-flashscore">⚽ VER HISTORIAL EN FLASHSCORE</button><p class="legal-note">Última sincronización: ${sync} · Encontrados: ${tracking.lastEventsFound||0} · Ignorados antes del corte: ${(tracking.ignoredBeforeStart||[]).length}${tracking.lastError?` · Error: ${escapeHtml(tracking.lastError)}`:''}${tracking.simultaneousExcluded&&tracking.simultaneousExcluded.length?` · Simultáneos excluidos: ${tracking.simultaneousExcluded.length}`:''}</p><div class="shadow-metrics"><div><span>Capital ficticio</span><strong>${money(capital)}</strong></div><div><span>Resultado</span><strong class="${pct>=0?'positive':'negative'}">${pct.toFixed(2).replace('.',',')}%</strong></div><div><span>Registros</span><strong>${t.history.length}</strong></div></div><div class="shadow-strategies">${['general','pares','impares'].map(n=>strategyLine(n,t.strategies[n])).join('')}</div>${planBlock(t)}${queueBlock(t)}${pendingBlock(t)}${historyBlock(t)}<div class="shadow-actions"><button type="button" class="shadow-pause">${t.status==='paused'?'▶ Reanudar seguimiento':'⏸ Pausar seguimiento'}</button><details class="shadow-more"><summary aria-label="Más acciones" title="Más acciones">⋮</summary><div><p>Acciones del campeonato</p><button type="button" class="shadow-remove">🗑 Eliminar campeonato</button></div></details></div></article>`;
    }).join('');
    renderCapitalUsage(experiment);
  }
  function showTournament(id){selectedTournamentId=String(id);reportOnly=false;render();}
  function showReport(){selectedTournamentId=null;reportOnly=true;render();}
  async function searchLeagues() {
    const countryWritten=$('#shadowCountry').value.trim(), country=M11.ShadowEngine.countryForApi(countryWritten), message=$('#shadowFormMessage');
    if(!countryWritten){message.textContent='Escriba el país para buscar sus ligas.';return;}
    message.textContent='Consultando ligas…'; $('#shadowLeague').disabled=true;
    try { leaguesFound=await M11.SportsApi.buscarLigasPorPais(country); const featured=M11.ShadowEngine.FEATURED_COMPETITIONS.filter(c=>c.country===country); featured.forEach(c=>{if(!leaguesFound.some(l=>String(l.id)===c.id))leaguesFound.unshift(c);}); $('#shadowLeague').innerHTML='<option value="">Seleccione una liga…</option>'+leaguesFound.map(l=>`<option value="${l.id}">${escapeHtml(l.name)}</option>`).join(''); $('#shadowLeague').disabled=!leaguesFound.length; message.textContent=leaguesFound.length?`${leaguesFound.length} ligas encontradas${country!==countryWritten?` usando ${country} para consultar TheSportsDB`:''}.`:'No se encontraron ligas para ese país.'; }
    catch(_){message.textContent='No fue posible consultar TheSportsDB. Revise la conexión e intente nuevamente.';}
  }
  function selectFeatured() {
    const id=$('#shadowFeaturedCompetition').value, competition=M11.ShadowEngine.FEATURED_COMPETITIONS.find(c=>c.id===id), message=$('#shadowFormMessage');
    if(!competition)return;
    leaguesFound=[competition]; $('#shadowCountry').value=competition.country; $('#shadowLeague').innerHTML=`<option value="${competition.id}">${escapeHtml(competition.name)}</option>`; $('#shadowLeague').disabled=false; $('#shadowLeague').value=competition.id; message.textContent=`${competition.name} seleccionada directamente.`;
  }
  function addTournament(event) {
    event.preventDefault(); const id=$('#shadowLeague').value, league=leaguesFound.find(l=>String(l.id)===String(id)), message=$('#shadowFormMessage');
    if(!league){message.textContent='Seleccione una liga de la lista.';return;}
    const season=$('#shadowSeason').value.trim();
    const studyMode=$('#shadowStudyMode').value;
    try { M11.ShadowStore.addTournament({id:`${league.id}-${season||'actual'}-${studyMode}`,name:$('#shadowDisplayName').value.trim()||league.name,leagueId:league.id,country:$('#shadowCountry').value.trim(),season,studyMode,base:Number($('#shadowBase').value||1000),experimentalQuota:Number($('#shadowQuota').value||3.6),targetPercent:Number($('#shadowTarget').value||40)}); event.target.reset(); $('#shadowStudyMode').value='prospective'; $('#shadowQuota').value='3.60'; $('#shadowBase').value='1000'; $('#shadowTarget').value='40'; $('#shadowLeague').innerHTML='<option value="">Busque primero un país…</option>'; $('#shadowLeague').disabled=true; leaguesFound=[]; message.textContent=studyMode==='retrospective'?'Laboratorio retrospectivo guardado. Al sincronizar procesará los resultados publicados de la temporada.':'Campeonato prospectivo guardado. Solo contará partidos posteriores a este momento.'; render(); }
    catch(error){message.textContent=error.message;}
  }
  function handleListClick(event) {
    const card=event.target.closest('[data-shadow-id]'); if(!card)return; const id=card.dataset.shadowId, t=M11.ShadowStore.load().tournaments.find(x=>x.id===id);
    const reviewButton=event.target.closest('.shadow-review');
    if(reviewButton&&t){const row=reviewButton.closest('[data-shadow-event-id]'), result=reviewButton.dataset.shadowResult, labels={draw:'Empate',not_draw:'No empate',cancelled:'Cancelado',suspended:'Suspendido'};if(!row)return;if(!confirm(`¿Confirmar “${labels[result]}” para este partido? La decisión actualizará el laboratorio sombra y quedará registrada como revisión manual.`))return;try{M11.ShadowSync.resolvePending(id,row.dataset.shadowEventId,result);$('#shadowSyncMessage').textContent=`Revisión manual guardada: ${labels[result]}.`;render();}catch(error){$('#shadowSyncMessage').textContent=error.message;}return;}
    if(event.target.closest('.shadow-bet')&&t){const url=(localStorage.getItem('m11BetHouseUrl')||'').trim();if(!url){alert('No hay una casa de apuestas configurada. Agréguela en Configuración.');return;}openExternal(url);return;}
    if(event.target.closest('.shadow-flashscore')&&t){openExternal(flashscoreUrl(t));return;}
    if(event.target.closest('.shadow-pause')&&t){M11.ShadowStore.setTournamentStatus(id,t.status==='paused'?'active':'paused');render();if(M11.Notifications)M11.Notifications.sync();}
    if(event.target.closest('.shadow-remove')&&t){if(!confirm(`ELIMINAR CAMPEONATO\n\nSe borrará “${t.name}”, junto con sus niveles, resultados, cola cronológica y seguimiento ficticio.\n\nEsta acción no afecta la operación real, pero no se puede deshacer. ¿Confirma que desea eliminarlo?`))return;M11.ShadowStore.removeTournament(id);render();if(M11.Notifications)M11.Notifications.sync();}
  }
  let syncing=false;
  async function syncAll(force) {
    if(syncing)return; syncing=true; const button=$('#shadowSyncAll'), message=$('#shadowSyncMessage'); button.disabled=true; message.textContent='Consultando campeonatos y procesando resultados publicados…';
    try { const results=await M11.ShadowSync.syncAll({force:!!force}); const processed=results.reduce((sum,r)=>sum+(r.processed||0),0), planned=results.reduce((sum,r)=>sum+(r.planned||0),0), unplanned=results.reduce((sum,r)=>sum+(r.observedUnplanned||0),0), queued=results.reduce((sum,r)=>sum+(r.queued||0),0), live=results.reduce((sum,r)=>sum+(r.live||0),0), repaired=results.reduce((sum,r)=>sum+(r.repaired||0),0), simultaneousRepaired=results.reduce((sum,r)=>sum+(r.simultaneousRepaired||0),0), recovered=results.reduce((sum,r)=>sum+(r.recovered||0),0), relinked=results.reduce((sum,r)=>sum+(r.relinked||0),0), reconstructed=results.reduce((sum,r)=>sum+(r.reconstructed||0),0), rolledBack=results.reduce((sum,r)=>sum+(r.rolledBack||0),0), missing=results.reduce((sum,r)=>sum+(r.missing||0),0), scheduled=results.reduce((sum,r)=>sum+(r.scheduled||0),0), found=results.reduce((sum,r)=>sum+(r.eventsFound||0),0), ignored=results.reduce((sum,r)=>sum+(r.ignoredBeforeStart||0),0), pending=results.reduce((sum,r)=>sum+(r.pendingReview||0),0), errors=results.filter(r=>!r.ok).length; message.textContent=`Sincronización terminada: ${found} partidos encontrados; ${planned} apuestas ficticias nuevas preparadas; ${processed} operaciones liquidadas; ${live} partidos en curso sin liquidar; ${scheduled} programados esperando marcador; ${queued} eventos en cola cronológica; ${ignored} anteriores al corte ignorados${simultaneousRepaired?`; ${simultaneousRepaired} simultáneos mal numerados corregidos y cola reconstruida`:''}${relinked?`; ${relinked} partidos recuperados tras cambio de identificador`:''}${missing?`; ${missing} partidos numerados no localizados; la liquidación posterior quedó detenida`:''}${rolledBack?`; ${rolledBack} resultados posteriores retirados temporalmente y capital reconstruido`:''}${reconstructed?`; ${reconstructed} registros sombra reconstruidos como simulaciones automáticas`:''}${repaired?`; ${repaired} registros anteriores reparados sin cambiar capital`:''}${recovered?`; ${recovered} partidos elegibles recuperados desde la auditoría`:''}${unplanned?`; ${unplanned} resultados sin elegibilidad previa`:''}${pending?`; ${pending} contradicciones pendientes de revisión`:''}${errors?`; ${errors} campeonatos con error`:''}.`; render(); if(M11.Notifications)M11.Notifications.sync(); }
    finally { syncing=false; button.disabled=false; }
  }
  function init(){ $('#shadowSearchLeagues').addEventListener('click',searchLeagues); $('#shadowFeaturedCompetition').addEventListener('change',selectFeatured); $('#shadowForm').addEventListener('submit',addTournament); $('#shadowTournamentList').addEventListener('click',handleListClick); $('#shadowTournamentList').addEventListener('change',handleListClick); $('#shadowSyncAll').addEventListener('click',()=>syncAll(true)); const nav=document.querySelector('.nav-btn[data-view="shadowView"]');if(nav)nav.addEventListener('click',()=>{render();syncAll(false);});render(); }
  M11.ShadowUI={init,render,showTournament,showReport};
})(window.M11);
