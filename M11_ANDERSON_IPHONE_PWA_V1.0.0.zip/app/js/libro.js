/* =========================================================
   M11 · libro.js — Generador Automático de Plantillas M11
   -----------------------------------------------------------
   "Libro de Operaciones M11": una única estructura por partido
   (sección 14 del encargo), en vez de eventos sueltos. Cada partido
   se registra UNA sola vez, en el momento real de la operación
   (dentro de M11.Transiciones.registrarResultado, en state.js) y
   nunca se reconstruye ni se recalcula después con datos actuales.

   Este módulo NO decide reglas del Modelo M11 — solo registra,
   agrega y explica en palabras lo que el motor (m11-engine.js) ya
   calculó. No depende del DOM.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_KEY_BASE = 'm11Libro';
  const LS_CONTADOR_BASE = 'm11LibroContador';
  const LS_MIGRADO_BASE = 'm11LibroMigrado';
  const LS_MIGRACION_ERROR_BASE = 'm11LibroMigracionError';
  const LS_KEY_DEMO = 'm11LibroDemo';
  const LS_CONTADOR_DEMO = 'm11LibroContadorDemo';
  const NOMBRE = { general: 'General', pares: 'Pares', impares: 'Impares' };

  // Sprint V1.0.5 — el Libro de Operaciones (historial) pasa a ser propio
  // de cada OPERACIÓN (torneo), igual que ya son las estrategias y la
  // decisión pendiente (ver state.js). La operación migrada desde antes
  // de que existiera este concepto ('op-migrada-1') sigue usando las
  // claves clásicas de siempre (m11Libro, m11LibroContador, ...) para no
  // copiar ni renombrar nada de lo que el operador ya tenía guardado;
  // cualquier operación nueva usa claves propias derivadas de su id. El
  // Centro de Pruebas tiene su propio Libro aparte (m11LibroDemo), para
  // que ningún ciclo de prueba pueda mezclarse con el historial real de
  // ninguna operación.
  function esOperacionClasica(operacionId) { return !operacionId || operacionId === 'op-migrada-1'; }
  function claveLibro(operacionId) { return esOperacionClasica(operacionId) ? LS_KEY_BASE : LS_KEY_BASE + '__' + operacionId; }
  function claveContador(operacionId) { return esOperacionClasica(operacionId) ? LS_CONTADOR_BASE : LS_CONTADOR_BASE + '__' + operacionId; }
  function claveMigrado(operacionId) { return esOperacionClasica(operacionId) ? LS_MIGRADO_BASE : LS_MIGRADO_BASE + '__' + operacionId; }
  function claveMigracionError(operacionId) { return esOperacionClasica(operacionId) ? LS_MIGRACION_ERROR_BASE : LS_MIGRACION_ERROR_BASE + '__' + operacionId; }

  // Estas cuatro son las únicas que dependen de "cuál operación (o el
  // Centro de Pruebas) está activa ahora mismo" — se recalculan en cada
  // llamada porque ese activo puede cambiar entre una llamada y otra.
  function operacionIdActiva() { return M11.Operaciones ? M11.Operaciones.getActivaId() : null; }
  function LS_KEY() { return M11.Store && M11.Store.getCentroPruebas() ? LS_KEY_DEMO : claveLibro(operacionIdActiva()); }
  function LS_CONTADOR() { return M11.Store && M11.Store.getCentroPruebas() ? LS_CONTADOR_DEMO : claveContador(operacionIdActiva()); }
  function LS_MIGRADO() { return claveMigrado(operacionIdActiva()); } // la migración clásica solo aplica a la Operación real
  function LS_MIGRACION_ERROR() { return claveMigracionError(operacionIdActiva()); }

  function cargar(clave) {
    try { return JSON.parse(localStorage.getItem(clave) || '[]'); }
    catch (e) { return []; }
  }
  // "registros" es una caché del contenido de la clave activa: se
  // recarga sola cada vez que esa clave cambia (cambio de operación,
  // o entrar/salir del Centro de Pruebas) — así ninguna función de más
  // abajo necesita saber de operaciones, solo llamar a activo() primero.
  let claveCacheada = null;
  let registros = [];
  function activo() {
    const clave = LS_KEY();
    if (clave !== claveCacheada) { claveCacheada = clave; registros = cargar(clave); }
    return registros;
  }
  function persistir() { localStorage.setItem(claveCacheada, JSON.stringify(registros)); }

  function mismaClavePartido(a, p) {
    if (!a || !p) return false;
    if (p.externalId && a.externalId && String(a.externalId) === String(p.externalId)) return true;
    if (p.id && a.partidoId && String(a.partidoId) === String(p.id)) return true;
    const fechaP = p.timestampUTC || (p.fecha && p.hora ? `${p.fecha}T${p.hora}:00` : null);
    return !!fechaP && String(a.fechaHoraPartido || '') === String(fechaP) &&
      a.equipoLocal === p.equipoLocal && a.equipoVisitante === p.equipoVisitante;
  }

  function existePartido(partido) {
    activo();
    return registros.some(r => mismaClavePartido(r, partido));
  }

  // Devuelve el registro exacto que hace que un partido ya no sea una
  // oportunidad nueva. La pantalla de Operacion Real lo usa antes de
  // recomendar montos, no solamente al intentar guardar al final.
  function obtenerRegistroPartido(partido) {
    activo();
    return registros.find(r => mismaClavePartido(r, partido)) || null;
  }

  // Repara exclusivamente una omisión automática imposible: un partido
  // todavía futuro no puede figurar como "sin acción". No elimina nunca
  // una apuesta, una decisión "No aposté" ni un resultado introducido por
  // el operador. Este residuo era suficiente para bloquear el botón cinco
  // horas antes aunque el usuario no hubiera registrado ninguna decisión.
  function repararSinAccionFutura(partido, ahoraMs) {
    activo();
    if (!partido) return false;
    const inicio = new Date(partido.timestampUTC || (partido.fecha && partido.hora ? `${partido.fecha}T${partido.hora}:00` : '')).getTime();
    const ahora = Number.isFinite(Number(ahoraMs)) ? Number(ahoraMs) : Date.now();
    if (!Number.isFinite(inicio) || inicio <= ahora) return false;
    const antes = registros.length;
    registros = registros.filter(r => !(r.tipoOriginal === 'sin_accion' && mismaClavePartido(r, partido)));
    if (registros.length === antes) return false;
    persistir();
    return true;
  }

  function siguienteNumero() {
    const clave = LS_CONTADOR();
    const actual = Number(localStorage.getItem(clave) || '0') + 1;
    localStorage.setItem(clave, String(actual));
    return actual;
  }

  // Número operativo M11: cuenta exclusivamente apuestas realmente
  // confirmadas. Los partidos no apostados, sin acción o descartados se
  // conservan para auditoría, pero NO consumen turno par/impar.
  function siguienteNumeroApuestaM11() {
    activo();
    return registros.reduce((total, r) => total + (r.tipoOriginal === 'apostada' ? 1 : 0), 0) + 1;
  }

  function fmt(n) {
    if (n === null || n === undefined) return 'Dato no disponible en esta versión del registro.';
    return '$' + Math.round(n).toLocaleString('es-CO');
  }

  // ---- Frase operativa (sección 6) ---------------------------------------
  function fraseEstrategia(nombre, e, contexto) {
    const N = NOMBRE[nombre];
    if (contexto.tipoOriginal === 'descartado_simultaneidad') {
      return `Este partido fue descartado por simultaneidad: el operador eligió otro partido dentro de los 120 minutos para la secuencia. La estrategia ${N} no participa.`;
    }
    if (contexto.tipoOriginal === 'no_apostada' || contexto.tipoOriginal === 'sin_accion') {
      return 'La apuesta no fue realizada. El partido queda registrado, pero no modifica niveles ni capital.';
    }
    if (contexto.resultado === 'cancelado' || contexto.resultado === 'suspendido') {
      return 'El partido fue cancelado. Los niveles y los capitales permanecen sin cambios.';
    }
    if (!e.participa) {
      if (e.bloqueadaAntes) return `La estrategia ${N} está bloqueada por Nivel 11 y no participa hasta que se inicie una nueva secuencia.`;
      const explicitaParidad = nombre === 'pares'
        ? 'porque este corresponde a un partido cronológico impar'
        : (nombre === 'impares' ? 'porque este corresponde a un partido cronológico par' : '');
      return `La estrategia ${N} no participa en este partido${explicitaParidad ? ' ' + explicitaParidad : ''}.`;
    }
    if (e.montoApostado === null) return `La estrategia ${N}: dato no disponible en esta versión del registro.`;
    if (e.secuenciaFinalizada) return `La estrategia ${N} perdió la apuesta del Nivel 11 y su secuencia ha finalizado.`;
    if (e.gananciaNeta !== null && e.gananciaNeta >= 0 && e.retorno) {
      return `La estrategia ${N} obtuvo empate, recibió un retorno de ${fmt(e.retorno)} y reinicia en el Nivel 1.`;
    }
    if (e.nivelAntes !== null && e.nivelDespues !== null) {
      return `La estrategia ${N} no obtuvo empate y pasa del Nivel ${e.nivelAntes} al Nivel ${e.nivelDespues}.`;
    }
    return `La estrategia ${N}: dato no disponible en esta versión del registro.`;
  }

  // Estado legible para la columna "estado después" (sección 5)
  function estadoDespues(e, contexto) {
    if (contexto.tipoOriginal === 'descartado_simultaneidad') return 'no_participa';
    if (contexto.tipoOriginal === 'no_apostada' || contexto.tipoOriginal === 'sin_accion' || contexto.resultado === 'cancelado' || contexto.resultado === 'suspendido') return 'continua';
    if (!e.participa) return e.bloqueadaAntes ? 'bloqueada' : 'no_participa';
    if (e.secuenciaFinalizada) return 'secuencia_finalizada';
    if (e.gananciaNeta !== null && e.gananciaNeta >= 0 && e.retorno) return 'reinicia_nivel_1';
    if (e.nivelDespues !== null && e.nivelAntes !== null && e.nivelDespues > e.nivelAntes) return 'pasa_siguiente_nivel';
    return 'continua';
  }

  // ---- Validación (sección 15) --------------------------------------------
  // Comprueba, para cada estrategia con datos completos, que
  // saldoAntes − montoApostado + retorno = saldoDespues. No valida lo
  // que no está disponible (nunca inventa ni asume).
  function validar(registro) {
    const motivos = [];
    Object.keys(registro.estrategias).forEach(nombre => {
      const e = registro.estrategias[nombre];
      if (!e.participa) return;
      if (e.saldoAntes === null || e.saldoDespues === null || e.montoApostado === null || e.retorno === null) return;
      const esperado = e.saldoAntes - e.montoApostado + e.retorno;
      if (Math.abs(esperado - e.saldoDespues) > 1) {
        motivos.push(`${NOMBRE[nombre]}: saldo esperado ${fmt(esperado)}, registrado ${fmt(e.saldoDespues)}.`);
      }
    });
    if (registro.totalApostado !== null && registro.capitalTotalAntes !== null && registro.capitalTotalDespues !== null && registro.retornoTotal !== null) {
      const esperado = registro.capitalTotalAntes - registro.totalApostado + registro.retornoTotal;
      if (Math.abs(esperado - registro.capitalTotalDespues) > 1) {
        motivos.push(`Capital total: esperado ${fmt(esperado)}, registrado ${fmt(registro.capitalTotalDespues)}.`);
      }
    }
    return motivos;
  }

  // ---- Registrar un partido nuevo (llamado desde state.js) ---------------
  // datos: { partido, tipoOriginal, resultado, casaApuestas, cuotaConfirmada,
  //          montoApostadoConfirmado, capitalTotalAntes, capitalTotalDespues,
  //          totalApostado, retornoTotal, gananciaNetaTotal, estrategias,
  //          fechaRegistro }
  function registrarPartido(datos) {
    activo();
    const p = datos.partido || {};
    const existente = registros.find(r => mismaClavePartido(r, p));
    if (existente) return existente; // escritura idempotente por partido
    const registro = {
      numero: siguienteNumero(),
      cronologico: (typeof p.numeroCronologico === 'number') ? p.numeroCronologico : null,
      numeroApuestaM11: datos.tipoOriginal === 'apostada'
        ? (Number(datos.numeroApuestaM11 || p.numeroApuestaM11) || siguienteNumeroApuestaM11())
        : null,
      fechaHora: datos.fechaRegistro || new Date().toISOString(),
      fechaHoraPartido: p.timestampUTC || (p.fecha && p.hora ? `${p.fecha}T${p.hora}:00` : null),
      partidoId: p.id || null,
      externalId: p.externalId || null,
      torneo: p.torneo || null,
      equipoLocal: p.equipoLocal || null,
      equipoVisitante: p.equipoVisitante || null,
      tipoOriginal: datos.tipoOriginal,
      resultado: datos.resultado,
      cuotaConfirmada: datos.cuotaConfirmada,
      casaApuestas: datos.casaApuestas || null,
      montoApostadoConfirmado: datos.montoApostadoConfirmado,
      capitalTotalAntes: datos.capitalTotalAntes,
      totalApostado: datos.totalApostado,
      retornoTotal: datos.retornoTotal,
      gananciaNetaTotal: datos.gananciaNetaTotal,
      capitalTotalDespues: datos.capitalTotalDespues,
      estrategias: {},
      revisionRequerida: false,
      motivoRevision: null,
      origen: 'nuevo'
    };
    ['general', 'pares', 'impares'].forEach(nombre => {
      const e = datos.estrategias[nombre];
      registro.estrategias[nombre] = {
        ...e,
        estadoDespues: estadoDespues(e, { tipoOriginal: datos.tipoOriginal, resultado: datos.resultado }),
        explicacion: fraseEstrategia(nombre, e, { tipoOriginal: datos.tipoOriginal, resultado: datos.resultado })
      };
    });
    const motivos = validar(registro);
    if (motivos.length) { registro.revisionRequerida = true; registro.motivoRevision = motivos.join(' '); }
    registros.push(registro);
    persistir();
    if (M11.Evaluacion) M11.Evaluacion.verificarYRegistrar();
    return registro;
  }

  // Registra un partido cuya hora pasó sin que el usuario dejara una
  // decisión en el aplicativo. Es trazabilidad, no una apuesta: no toca
  // capital, niveles ni secuencias y evita huecos silenciosos.
  function registrarSinAccion(partido) {
    activo();
    const yaExiste = registros.some(r =>
      (partido.externalId && String(r.externalId) === String(partido.externalId)) ||
      (r.partidoId && r.partidoId === partido.id) ||
      (r.cronologico === partido.numeroCronologico && r.equipoLocal === partido.equipoLocal && r.equipoVisitante === partido.equipoVisitante)
    );
    if (yaExiste) return null;
    const estrategias = {};
    ['general', 'pares', 'impares'].forEach(nombre => {
      estrategias[nombre] = {
        participa:false, nivelAntes:null, bloqueadaAntes:null,
        montoRecomendado:null, montoApostado:null, cuota:null, retorno:null,
        gananciaNeta:null, nivelDespues:null, saldoAntes:null,
        saldoDespues:null, secuenciaFinalizada:false
      };
    });
    return registrarPartido({
      partido, tipoOriginal:'sin_accion', resultado:partido.resultadoSugerido || null,
      casaApuestas:null, cuotaConfirmada:null, montoApostadoConfirmado:null,
      capitalTotalAntes:null, capitalTotalDespues:null, totalApostado:null,
      retornoTotal:null, gananciaNetaTotal:null, estrategias,
      fechaRegistro:new Date().toISOString()
    });
  }

  // Corrige un resultado ya guardado por la fuente y reconstruye, en orden,
  // todo el capital y los niveles posteriores. Así Plantillas y Operación
  // Normal vuelven a compartir una sola verdad contable. Nunca actúa si hay
  // una apuesta nueva pendiente, porque no debe mover capital comprometido.
  function corregirResultadoYReconstruir(externalId, resultado, verificacion) {
    activo();
    if (!externalId || !['empate','no_empate','cancelado','suspendido'].includes(resultado)) return { ok:false, motivo:'DATO_INVALIDO' };
    const decision = M11.Store && M11.Store.getDecision ? M11.Store.getDecision() : null;
    if (decision && decision.estado === 'PENDIENTE_RESULTADO') return { ok:false, motivo:'OPERACION_PENDIENTE' };
    const objetivo = registros.find(r => String(r.externalId || '') === String(externalId));
    if (!objetivo) return { ok:false, motivo:'NO_ENCONTRADO' };
    if (objetivo.resultado === resultado && !(verificacion && verificacion.forzarIntegridad)) return { ok:true, cambiado:false };
    if (!objetivo.estrategias || objetivo.tipoOriginal !== 'apostada') {
      const anteriorSimple = objetivo.resultado;
      objetivo.resultado = resultado;
      objetivo.resultadoCorregido = { anterior:anteriorSimple, nuevo:resultado, fecha:new Date().toISOString(), verificacion:verificacion||null };
      persistir();
      return { ok:true, cambiado:true, reconstruido:false };
    }

    const anterior = objetivo.resultado;
    objetivo.resultado = resultado;
    const estados = {
      general:M11.Engine.nuevoEstadoEstrategia(),
      pares:M11.Engine.nuevoEstadoEstrategia(),
      impares:M11.Engine.nuevoEstadoEstrategia()
    };
    const ordenados = registros.slice().sort((a,b)=>(Number(a.numero)||0)-(Number(b.numero)||0));
    for (const r of ordenados) {
      if (r.tipoOriginal !== 'apostada') continue;
      if (!['empate','no_empate','cancelado','suspendido'].includes(r.resultado) || !r.estrategias) {
        objetivo.resultado = anterior;
        return { ok:false, motivo:'HISTORIAL_INCOMPLETO' };
      }
      const capitalAntes = estados.general.disponible + estados.pares.disponible + estados.impares.disponible;
      let totalApostado=0, retornoTotal=0, gananciaNetaTotal=0;
      ['general','pares','impares'].forEach(nombre => {
        const previo = r.estrategias[nombre] || {};
        const antes = estados[nombre];
        if (!previo.participa) {
          r.estrategias[nombre] = {...previo,participa:false,nivelAntes:antes.nivel,bloqueadaAntes:!!antes.bloqueada,nivelDespues:antes.nivel,saldoAntes:antes.disponible,saldoDespues:antes.disponible,estadoDespues:estadoDespues({...previo,participa:false,nivelAntes:antes.nivel,nivelDespues:antes.nivel,bloqueadaAntes:!!antes.bloqueada},{tipoOriginal:r.tipoOriginal,resultado:r.resultado}),explicacion:fraseEstrategia(nombre,{...previo,participa:false,nivelAntes:antes.nivel,nivelDespues:antes.nivel,bloqueadaAntes:!!antes.bloqueada},{tipoOriginal:r.tipoOriginal,resultado:r.resultado})};
          return;
        }
        const monto = Number.isFinite(Number(previo.montoApostado)) ? Number(previo.montoApostado) : M11.Engine.montoPorNivel(antes.nivel);
        const comprometido = M11.Engine.comprometer(antes,monto);
        const liquidado = r.resultado === 'empate' ? M11.Engine.resolver(comprometido,true,Number(r.cuotaConfirmada||previo.cuota||3.6)) : r.resultado === 'no_empate' ? M11.Engine.resolver(comprometido,false,null) : M11.Engine.liberarSinCambios(comprometido);
        estados[nombre]=liquidado.estado;
        const d=liquidado.detalle;
        totalApostado+=d.montoApostado;retornoTotal+=d.retorno;gananciaNetaTotal+=d.gananciaNeta;
        const nuevo={...previo,participa:true,nivelAntes:antes.nivel,bloqueadaAntes:!!antes.bloqueada,montoRecomendado:M11.Engine.montoPorNivel(antes.nivel),montoApostado:d.montoApostado,cuota:d.cuota,retorno:d.retorno,gananciaNeta:d.gananciaNeta,nivelDespues:d.nivelNuevo,saldoAntes:antes.disponible,saldoDespues:d.saldoDespues,secuenciaFinalizada:!!d.secuenciaFinalizada};
        nuevo.estadoDespues=estadoDespues(nuevo,{tipoOriginal:r.tipoOriginal,resultado:r.resultado});
        nuevo.explicacion=fraseEstrategia(nombre,nuevo,{tipoOriginal:r.tipoOriginal,resultado:r.resultado});
        r.estrategias[nombre]=nuevo;
      });
      r.capitalTotalAntes=capitalAntes;r.totalApostado=totalApostado;r.retornoTotal=retornoTotal;r.gananciaNetaTotal=gananciaNetaTotal;
      r.capitalTotalDespues=estados.general.disponible+estados.pares.disponible+estados.impares.disponible;
      r.revisionRequerida=false;r.motivoRevision=null;
    }
    ['general','pares','impares'].forEach(nombre=>M11.Store.setEstrategia(nombre,estados[nombre]));
    objetivo.resultadoCorregido={anterior,nuevo:resultado,fecha:new Date().toISOString(),verificacion:verificacion||null};
    objetivo.origenResultado='TheSportsDB · resultado final reconciliado';
    persistir();
    return { ok:true,cambiado:true,reconstruido:true,anterior,nuevo:resultado };
  }

  // Repara datos creados por versiones anteriores: elimina una segunda fila
  // del mismo partido, hace que la suma por estrategias coincida exactamente
  // con el monto confirmado por el operador y reconstruye capital/niveles.
  function repararIntegridad() {
    activo();
    const decision = M11.Store && M11.Store.getDecision ? M11.Store.getDecision() : null;
    if (decision && decision.estado === 'PENDIENTE_RESULTADO') return { ok:false, motivo:'OPERACION_PENDIENTE' };
    let cambio = false;
    const unicos = [];
    registros.slice().sort((a,b)=>(Number(a.numero)||0)-(Number(b.numero)||0)).forEach(r => {
      const indice = unicos.findIndex(x => mismaClavePartido(x, {
        id:r.partidoId, externalId:r.externalId, timestampUTC:r.fechaHoraPartido,
        equipoLocal:r.equipoLocal, equipoVisitante:r.equipoVisitante
      }));
      if (indice < 0) { unicos.push(r); return; }
      cambio = true;
      // Si una fila solo decía “sin acción” y la otra contiene la apuesta
      // real, se conserva la apuesta. Nunca se suman las dos.
      if (unicos[indice].tipoOriginal !== 'apostada' && r.tipoOriginal === 'apostada') unicos[indice] = r;
    });
    registros = unicos;

    registros.forEach(r => {
      if (r.tipoOriginal !== 'apostada' || !r.estrategias) return;
      const confirmado = Number(r.montoApostadoConfirmado);
      const participantes = ['general','pares','impares'].filter(n => r.estrategias[n] && r.estrategias[n].participa);
      if (!Number.isFinite(confirmado) || confirmado < 0 || !participantes.length) return;
      const actual = participantes.reduce((s,n)=>s+(Number(r.estrategias[n].montoApostado)||0),0);
      if (Math.abs(actual-confirmado) <= 1) return;
      let asignado = 0;
      participantes.forEach((n,i) => {
        const peso = actual > 0 ? (Number(r.estrategias[n].montoApostado)||0)/actual : 1/participantes.length;
        const monto = i === participantes.length-1 ? confirmado-asignado : Math.round(confirmado*peso);
        asignado += monto;
        r.estrategias[n].montoApostado = monto;
      });
      cambio = true;
    });
    if (!cambio) return { ok:true, cambiado:false };
    persistir();
    const pivote = registros.find(r => r.tipoOriginal === 'apostada' && r.externalId && ['empate','no_empate','cancelado','suspendido'].includes(r.resultado));
    if (!pivote) return { ok:true, cambiado:true, reconstruido:false };
    return corregirResultadoYReconstruir(pivote.externalId, pivote.resultado, { forzarIntegridad:true, motivo:'reparacion_v205' });
  }

  // V2.1.8 — auditoría determinista de TODAS las operaciones reales.
  // La participación nunca se hereda de una versión anterior: General
  // participa siempre y Pares/Impares dependen exclusivamente del ordinal
  // de las apuestas realmente realizadas. Un partido no apostado permanece
  // en el historial, pero no consume turno par/impar ni altera el M11.
  function repararTodasOperaciones() {
    if (!M11.Operaciones || !M11.Engine) return { reparadas:0, omitidas:0 };
    const baseAnterior = M11.Engine.CONFIG.BASE;
    let reparadas=0, omitidas=0;
    M11.Operaciones.listar().forEach(op => {
      const clasica=!op.id||op.id==='op-migrada-1';
      const libroKey=clasica?LS_KEY_BASE:LS_KEY_BASE+'__'+op.id;
      const estadoKey=clasica?'m11EstrategiasEngine':'m11EstrategiasEngine__'+op.id;
      const decisionKey=clasica?'m11DecisionPartido':'m11DecisionPartido__'+op.id;
      let decision=null, rows=[];
      try{decision=JSON.parse(localStorage.getItem(decisionKey)||'null');rows=JSON.parse(localStorage.getItem(libroKey)||'[]');}catch(_){omitidas++;return;}
      if(decision&&decision.estado==='PENDIENTE_RESULTADO'){omitidas++;return;}
      M11.Engine.CONFIG.BASE=Number(op.base)||baseAnterior;
      const estados={general:M11.Engine.nuevoEstadoEstrategia(),pares:M11.Engine.nuevoEstadoEstrategia(),impares:M11.Engine.nuevoEstadoEstrategia()};
      let numeroApuesta=0;
      rows.slice().sort((a,b)=>(Number(a.numero)||0)-(Number(b.numero)||0)).forEach(r=>{
        if(r.tipoOriginal!=='apostada'){r.numeroApuestaM11=null;return;}
        numeroApuesta+=1;
        r.numeroApuestaM11=numeroApuesta;
        if(!['empate','no_empate','cancelado','suspendido'].includes(r.resultado))return;
        const numero=numeroApuesta;
        const esperadas=['general',numero%2===0?'pares':'impares'].filter(n=>!estados[n].bloqueada);
        const capitalAntes=estados.general.disponible+estados.pares.disponible+estados.impares.disponible;
        const recomendadoTotal=esperadas.reduce((s,n)=>s+M11.Engine.montoPorNivel(estados[n].nivel),0);
        // Una reparación de paridad cambia qué estrategia participaba y su
        // nivel. Por ello NO se puede redistribuir el total antiguo: ese total
        // fue calculado por la asignación defectuosa y perpetuaría el error
        // financiero aunque los niveles ya se vieran bien. Se reconstruye la
        // apuesta M11 exacta desde la base y los niveles corregidos. La cuota
        // confirmada sí se conserva porque pertenece al partido, no a la
        // asignación equivocada.
        const total=recomendadoTotal;
        if(r.montoApostadoConfirmadoOriginal==null && Number.isFinite(Number(r.montoApostadoConfirmado)))r.montoApostadoConfirmadoOriginal=Number(r.montoApostadoConfirmado);
        r.montoApostadoConfirmado=total;
        let asignado=0,totalApostado=0,retornoTotal=0,gananciaNetaTotal=0;
        r.estrategias=r.estrategias||{};
        ['general','pares','impares'].forEach(nombre=>{
          const antes=estados[nombre],participa=esperadas.includes(nombre);
          if(!participa){const e={...(r.estrategias[nombre]||{}),participa:false,nivelAntes:antes.nivel,bloqueadaAntes:!!antes.bloqueada,montoRecomendado:null,montoApostado:null,cuota:null,retorno:null,gananciaNeta:null,nivelDespues:antes.nivel,saldoAntes:antes.disponible,saldoDespues:antes.disponible,secuenciaFinalizada:false};e.estadoDespues=estadoDespues(e,r);e.explicacion=fraseEstrategia(nombre,e,r);r.estrategias[nombre]=e;return;}
          const i=esperadas.indexOf(nombre),peso=recomendadoTotal?M11.Engine.montoPorNivel(antes.nivel)/recomendadoTotal:1/esperadas.length;
          const monto=i===esperadas.length-1?total-asignado:Math.round(total*peso);asignado+=monto;
          const comprometido=M11.Engine.comprometer(antes,monto);
          const liquidado=r.resultado==='empate'?M11.Engine.resolver(comprometido,true,Number(r.cuotaConfirmada||3.6)):r.resultado==='no_empate'?M11.Engine.resolver(comprometido,false,null):M11.Engine.liberarSinCambios(comprometido);
          estados[nombre]=liquidado.estado;const d=liquidado.detalle;totalApostado+=d.montoApostado;retornoTotal+=d.retorno;gananciaNetaTotal+=d.gananciaNeta;
          const e={...(r.estrategias[nombre]||{}),participa:true,nivelAntes:antes.nivel,bloqueadaAntes:!!antes.bloqueada,montoRecomendado:M11.Engine.montoPorNivel(antes.nivel),montoApostado:d.montoApostado,cuota:d.cuota,retorno:d.retorno,gananciaNeta:d.gananciaNeta,nivelDespues:d.nivelNuevo,saldoAntes:antes.disponible,saldoDespues:d.saldoDespues,secuenciaFinalizada:!!d.secuenciaFinalizada};e.estadoDespues=estadoDespues(e,r);e.explicacion=fraseEstrategia(nombre,e,r);r.estrategias[nombre]=e;
        });
        r.capitalTotalAntes=capitalAntes;r.totalApostado=totalApostado;r.retornoTotal=retornoTotal;r.gananciaNetaTotal=gananciaNetaTotal;r.capitalTotalDespues=estados.general.disponible+estados.pares.disponible+estados.impares.disponible;r.revisionRequerida=false;r.motivoRevision=null;r.auditoriaV216='paridad_por_apuestas_reconstruida';
      });
      localStorage.setItem(libroKey,JSON.stringify(rows));
      // Actualiza también el almacén en memoria. Sin esto la reconstrucción
      // quedaba correcta en localStorage, pero la vista activa podía seguir
      // mostrando y liquidando con el nivel antiguo hasta otro reinicio.
      if(M11.Store&&M11.Store.setEstrategiasDeOperacion)M11.Store.setEstrategiasDeOperacion(op.id,estados);
      else localStorage.setItem(estadoKey,JSON.stringify(estados));
      localStorage.setItem('m11_integridad_v218__'+op.id,JSON.stringify({fecha:new Date().toISOString(),apuestas:numeroApuesta,niveles:{general:estados.general.nivel,pares:estados.pares.nivel,impares:estados.impares.nivel},capital:estados.general.disponible+estados.pares.disponible+estados.impares.disponible}));reparadas++;
      if(libroKey===claveCacheada)registros=rows;
    });
    M11.Engine.CONFIG.BASE=baseAnterior;
    return {reparadas,omitidas};
  }

  // Registra en el Libro un partido descartado por simultaneidad (Sprint
  // 006, sección 2): el operador eligió otro partido dentro de la misma
  // ventana de 120 minutos. Conserva su propio número de partido y su
  // trazabilidad completa — nunca desaparece del Libro, solo queda
  // marcado con este tipo y sin ninguna estrategia participando.
  function registrarDescartadoPorSimultaneidad(partido) {
    activo();
    const registro = {
      numero: siguienteNumero(),
      cronologico: (typeof partido.numeroCronologico === 'number') ? partido.numeroCronologico : null,
      fechaHora: new Date().toISOString(),
      torneo: partido.torneo || null,
      equipoLocal: partido.equipoLocal || null,
      equipoVisitante: partido.equipoVisitante || null,
      tipoOriginal: 'descartado_simultaneidad',
      resultado: null,
      cuotaConfirmada: null,
      casaApuestas: null,
      montoApostadoConfirmado: null,
      capitalTotalAntes: null,
      totalApostado: null,
      retornoTotal: null,
      gananciaNetaTotal: null,
      capitalTotalDespues: null,
      estrategias: {},
      revisionRequerida: false,
      motivoRevision: null,
      origen: 'nuevo'
    };
    const contexto = { tipoOriginal: 'descartado_simultaneidad', resultado: null };
    ['general', 'pares', 'impares'].forEach(nombre => {
      const e = {
        participa: false, nivelAntes: null, bloqueadaAntes: null, montoRecomendado: null,
        montoApostado: null, cuota: null, retorno: null, gananciaNeta: null, nivelDespues: null,
        saldoAntes: null, saldoDespues: null, secuenciaFinalizada: false
      };
      registro.estrategias[nombre] = {
        ...e,
        estadoDespues: estadoDespues(e, contexto),
        explicacion: fraseEstrategia(nombre, e, contexto)
      };
    });
    registros.push(registro);
    persistir();
    if (M11.Evaluacion) M11.Evaluacion.verificarYRegistrar();
    return registro;
  }

  // ---- Migración desde el historial antiguo (sección 13) ------------------
  // Se ejecuta una sola vez (marcada con LS_MIGRADO). Lee M11.Audit (formato
  // anterior) y construye un registro por cada entrada 'resultado' o
  // 'no_apostada' que todavía no tenga su lugar en el Libro. Nunca inventa
  // cifras: lo que no está disponible en el formato anterior queda marcado
  // explícitamente como "Dato no disponible en esta versión del registro."
  function migrarDesdeHistorialAntiguo() {
    activo();
    if (localStorage.getItem(LS_MIGRADO()) === 'done') return { yaEstaba: true };
    if (!M11.Audit) { return { error: 'M11.Audit no disponible todavía; se reintentará en la próxima apertura.' }; }

    let antiguos;
    try {
      antiguos = M11.Audit.listar().slice().reverse(); // más viejo primero
    } catch (err) {
      localStorage.setItem(LS_MIGRACION_ERROR(), 'No se pudo leer el historial antiguo: ' + err.message);
      return { error: err.message };
    }

    // Desde aquí, cualquier entrada corrupta (incluida una que ni siquiera
    // sea un objeto válido) debe frenar TODA la migración sin marcarla
    // completada — nunca un resultado parcial. Por eso el filtro y la
    // construcción quedan bajo el mismo try/catch.
    const nuevosRegistros = [];
    let migrablesCount = 0;
    let numeroBase = Number(localStorage.getItem(LS_CONTADOR()) || '0');
    try {
      const migrables = antiguos.filter(x => x && (x.tipo === 'resultado' || x.tipo === 'no_apostada'));
      migrablesCount = migrables.length;
      migrables.forEach(x => {
        numeroBase += 1;
        nuevosRegistros.push(construirRegistroMigrado(x, numeroBase));
      });
    } catch (err) {
      // No se marca como completada: el historial antiguo queda intacto
      // (nunca se tocó) y se podrá reintentar en la siguiente apertura.
      localStorage.setItem(LS_MIGRACION_ERROR(), 'Migración interrumpida al procesar un registro: ' + err.message);
      return { error: err.message };
    }

    if (!migrablesCount) {
      // Nada pendiente de migrar (instalación nueva, o ya no queda
      // historial antiguo sin procesar): se puede marcar como terminado.
      localStorage.setItem(LS_MIGRADO(), 'done');
      localStorage.removeItem(LS_MIGRACION_ERROR());
      return { migrados: 0 };
    }

    if (nuevosRegistros.length !== migrablesCount) {
      localStorage.setItem(LS_MIGRACION_ERROR(), `Verificación fallida: se esperaban ${migrablesCount} registros y se construyeron ${nuevosRegistros.length}.`);
      return { error: 'verificación de cantidad fallida' };
    }

    // Verificado: recién ahora se escribe de forma atómica y se marca.
    registros = registros.concat(nuevosRegistros);
    localStorage.setItem(LS_CONTADOR(), String(numeroBase));
    persistir();
    localStorage.setItem(LS_MIGRADO(), 'done');
    localStorage.removeItem(LS_MIGRACION_ERROR());
    return { migrados: nuevosRegistros.length };
  }

  // Construye (sin escribir nada) el registro migrado de UNA entrada
  // antigua. Separado de migrarDesdeHistorialAntiguo para poder rodear
  // todo el lote con un único try/catch y no marcar nada como terminado
  // si alguno falla.
  function construirRegistroMigrado(x, numero) {
    const partes = (x.match || '').split(' vs ');
    const equipoLocal = partes[0] || null;
    const equipoVisitante = partes[1] || null;

    const registro = {
      numero,
      cronologico: null,
      fechaHora: x.date || null,
      torneo: null,
      equipoLocal,
      equipoVisitante,
      tipoOriginal: x.tipo === 'no_apostada' ? 'no_apostada' : (x.huboApuestaVálida ? 'apostada' : 'no_apostada'),
      resultado: x.tipo === 'resultado' ? x.resultado : null,
      cuotaConfirmada: null,
      casaApuestas: null,
      montoApostadoConfirmado: null,
      capitalTotalAntes: null,
      totalApostado: null,
      retornoTotal: null,
      gananciaNetaTotal: null,
      capitalTotalDespues: null,
      estrategias: {},
      revisionRequerida: false,
      motivoRevision: null,
      origen: 'migrado'
    };

    const detalle = (x.tipo === 'resultado' && x.detalle) ? x.detalle : {};
    let totalApostado = 0, retornoTotal = 0, gananciaNetaTotal = 0, hayTotales = false;
    ['general', 'pares', 'impares'].forEach(nombre => {
      const d = detalle[nombre] || null;
      const participa = !!d;
      let saldoAntes = null;
      if (d && typeof d.saldoDespues === 'number' && typeof d.retorno === 'number' && typeof d.montoApostado === 'number') {
        // Misma fórmula de auditoría (sección 11), aplicada hacia atrás
        // con los valores que sí quedaron guardados en su momento —
        // no es una cifra inventada, es la que exige esa fórmula.
        saldoAntes = d.saldoDespues - d.retorno + d.montoApostado;
      }
      const e = {
        participa,
        nivelAntes: d ? d.nivelAnterior : null,
        bloqueadaAntes: null,
        montoRecomendado: null,
        montoApostado: d ? d.montoApostado : null,
        cuota: d ? d.cuota : null,
        retorno: d ? d.retorno : null,
        gananciaNeta: d ? d.gananciaNeta : null,
        nivelDespues: d ? d.nivelNuevo : null,
        saldoAntes,
        saldoDespues: d ? d.saldoDespues : null,
        secuenciaFinalizada: d ? !!d.secuenciaFinalizada : false
      };
      if (d) { totalApostado += d.montoApostado; retornoTotal += d.retorno; gananciaNetaTotal += d.gananciaNeta; hayTotales = true; }
      registro.estrategias[nombre] = {
        ...e,
        estadoDespues: estadoDespues(e, { tipoOriginal: registro.tipoOriginal, resultado: registro.resultado }),
        explicacion: fraseEstrategia(nombre, e, { tipoOriginal: registro.tipoOriginal, resultado: registro.resultado })
      };
    });
    if (hayTotales) {
      registro.totalApostado = totalApostado;
      registro.retornoTotal = retornoTotal;
      registro.gananciaNetaTotal = gananciaNetaTotal;
    }
    return registro;
  }

  // ---- Resumen general (sección 9) ----------------------------------------
  function resumenGeneral() {
    const todos = activo();
    const apostados = todos.filter(r => r.tipoOriginal === 'apostada').length;
    const noApostados = todos.filter(r => r.tipoOriginal === 'no_apostada' || r.tipoOriginal === 'sin_accion').length;
    const empates = todos.filter(r => r.resultado === 'empate').length;
    const noEmpates = todos.filter(r => r.resultado === 'no_empate').length;
    const cancelados = todos.filter(r => r.resultado === 'cancelado' || r.resultado === 'suspendido').length;

    const est = M11.Store ? M11.Store.getEstrategias() : null;
    const capitalInicial = M11.Store && M11.Store.getCapitalInicialDeclarado()
      ? M11.Store.getCapitalInicialDeclarado()
      : (M11.Engine ? M11.Engine.presupuestoCompleto() * 3 : null);
    const capitalDisponible = est ? est.general.disponible + est.pares.disponible + est.impares.disponible : null;
    const capitalComprometido = est ? est.general.comprometido + est.pares.comprometido + est.impares.comprometido : null;

    // Ganancia/pérdida acumulada: una sola fórmula, sin duplicar retornos
    // ni contar transferencias internas — suma de gananciaNetaTotal de
    // cada partido que sí tiene ese dato (los migrados sin datos suficientes
    // no se cuentan, para no inventar).
    let gananciaAcumulada = 0, totalApostadoAcum = 0, totalRetornadoAcum = 0, maximoUtilizado = 0, capitalSecuencia = 0, maximoCapitalRequerido = 0, hayDatosGanancia = false;
    todos.forEach(r => {
      if (typeof r.gananciaNetaTotal === 'number') { gananciaAcumulada += r.gananciaNetaTotal; hayDatosGanancia = true; }
      if (typeof r.totalApostado === 'number') { totalApostadoAcum += r.totalApostado; capitalSecuencia += r.totalApostado; maximoUtilizado = Math.max(maximoUtilizado, r.totalApostado); maximoCapitalRequerido=Math.max(maximoCapitalRequerido,capitalSecuencia); }
      if (typeof r.retornoTotal === 'number') totalRetornadoAcum += r.retornoTotal;
      if (r.tipoOriginal === 'apostada' && r.resultado === 'empate') capitalSecuencia=0;
    });

    const primerRegistro = todos.find(r => r.torneo) || todos[0] || null;

    return {
      torneo: primerRegistro ? primerRegistro.torneo : null,
      fechaInicio: todos.length ? todos[0].fechaHora : null,
      totalPartidos: todos.length,
      apostados, noApostados, empates, noEmpates, cancelados,
      capitalInicial, capitalDisponible, capitalComprometido,
      patrimonioActual: est ? capitalDisponible + capitalComprometido : null,
      retirableAhora: capitalDisponible,
      maximoUtilizado: Math.max(maximoUtilizado, capitalComprometido || 0),
      maximoCapitalRequerido: Math.max(maximoCapitalRequerido, capitalSecuencia + (capitalComprometido || 0)),
      totalApostadoAcum, totalRetornadoAcum,
      gananciaAcumulada: hayDatosGanancia ? gananciaAcumulada : null,
      porcentajeReservaExigida: capitalInicial ? Math.max(maximoCapitalRequerido, capitalSecuencia + (capitalComprometido || 0)) / capitalInicial * 100 : null,
      rendimientoSobreMovilizado: totalApostadoAcum && hayDatosGanancia ? gananciaAcumulada / totalApostadoAcum * 100 : null,
      saldoGeneral: est ? est.general.disponible : null,
      saldoPares: est ? est.pares.disponible : null,
      saldoImpares: est ? est.impares.disponible : null,
      nivelGeneral: est ? est.general.nivel : null,
      nivelPares: est ? est.pares.nivel : null,
      nivelImpares: est ? est.impares.nivel : null,
      estrategiasActivas: est ? ['general', 'pares', 'impares'].filter(n => !est[n].bloqueada).map(n => NOMBRE[n]) : [],
      estrategiasFinalizadas: est ? ['general', 'pares', 'impares'].filter(n => est[n].bloqueada).map(n => NOMBRE[n]) : []
    };
  }

  // ---- Informe de Rentabilidad (Sprint 006, sección 3) --------------------
  // Reutiliza resumenGeneral (no duplica la lógica de capital/empates/
  // estrategias); solo agrega el capital actual (disponible + comprometido,
  // porque lo comprometido sigue siendo parte del capital del operador,
  // no está perdido) y la rentabilidad acumulada en %, con una única
  // fórmula: capital actual − capital inicial. Siempre disponible, para
  // que el operador decida libremente si continúa o se detiene.
  function informeRentabilidad() {
    const r = resumenGeneral();
    const capitalActual = (r.capitalDisponible !== null && r.capitalComprometido !== null)
      ? r.capitalDisponible + r.capitalComprometido : null;
    const gananciaAcumulada = (capitalActual !== null && r.capitalInicial !== null)
      ? capitalActual - r.capitalInicial : null;
    const rentabilidadPct = (gananciaAcumulada !== null && r.capitalInicial)
      ? (gananciaAcumulada / r.capitalInicial) * 100 : null;
    // "Partidos jugados": los que sí llegaron a una decisión real
    // (apostada o no apostada) — un descartado por simultaneidad nunca
    // se llegó a jugar, aunque conserve su número en el Libro.
    const partidosJugados = registros.filter(x => x.tipoOriginal === 'apostada' || x.tipoOriginal === 'no_apostada' || x.tipoOriginal === 'sin_accion').length;
    return {
      capitalInicial: r.capitalInicial,
      capitalActual,
      gananciaAcumulada,
      rentabilidadPct,
      partidosJugados,
      empates: r.empates,
      noEmpates: r.noEmpates,
      estrategiasActivas: r.estrategiasActivas,
      estrategiasFinalizadas: r.estrategiasFinalizadas
    };
  }

  M11.Libro = {
    registrarPartido,
    registrarSinAccion,
    siguienteNumeroApuestaM11,
    existePartido,
    obtenerRegistroPartido,
    repararSinAccionFutura,
    repararIntegridad,
    repararTodasOperaciones,
    corregirResultadoYReconstruir,
    registrarDescartadoPorSimultaneidad,
    migrarDesdeHistorialAntiguo,
    listar() { activo(); return registros.slice(); },
    resumenGeneral,
    informeRentabilidad,
    fraseEstrategia,
    fmt,
    getErrorMigracion() { return localStorage.getItem(LS_MIGRACION_ERROR()); },

    // Reinicia el Libro junto con el resto del torneo demo (llamado desde
    // M11.Transiciones.reiniciarTorneoDemo). Solo ocurre si el usuario lo
    // pide expresamente y confirma. Ese botón solo es visible con el
    // Centro de Pruebas activo, así que activo() siempre resuelve al
    // Libro del Centro de Pruebas acá, nunca al de una operación real.
    reiniciar() {
      activo();
      registros = [];
      localStorage.setItem(LS_CONTADOR(), '0');
      localStorage.setItem(LS_MIGRADO(), 'done'); // no volver a migrar lo ya borrado a propósito
      localStorage.removeItem(LS_MIGRACION_ERROR());
      persistir();
    },

    // Sprint V1.0.5 — reinicia el Libro de UNA operación puntual por su
    // id, sin importar si es la activa ahora mismo (usado por "Reiniciar
    // Liga demostrativa"). Nunca toca ninguna otra operación.
    reiniciarOperacion(operacionId) {
      const clave = claveLibro(operacionId);
      localStorage.setItem(clave, JSON.stringify([]));
      localStorage.setItem(claveContador(operacionId), '0');
      localStorage.setItem(claveMigrado(operacionId), 'done');
      localStorage.removeItem(claveMigracionError(operacionId));
      if (clave === claveCacheada) registros = [];
    }
  };

})(window.M11);
