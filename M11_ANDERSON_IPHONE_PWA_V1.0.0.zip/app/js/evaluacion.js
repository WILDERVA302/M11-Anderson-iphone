/* =========================================================
   M11 · evaluacion.js — Evaluación de recorrido M11
   -----------------------------------------------------------
   Cada 20 partidos completados (numeración natural del Libro de
   Operaciones — nunca se renumera nada), evalúa tres condiciones
   sobre el RECORRIDO DEPORTIVO observado, no sobre el apostador:

   C1: al menos 5 empates en los 20 partidos del bloque.
   C2: el primer empate ocurrió antes de la posición 12 del bloque.
   C3: al menos una pareja de empates consecutivos entre las
       posiciones 16 y 20 del bloque.

   Un partido cancelado o suspendido ocupa su lugar en el bloque
   pero nunca cuenta como empate. Un partido "No apostada" también
   ocupa su lugar y SÍ participa del conteo de empates/no empates
   si el operador registró un resultado real para él (empate o no
   empate) — solo no afectó capital. Esto se resuelve solo, sin
   casos especiales: se usa siempre el campo `resultado` tal como
   quedó guardado en el registro del Libro.

   Módulo desacoplado a propósito (sin depender de dónde se
   muestre) para poder trasladarlo a un futuro módulo de Reportes
   sin tocar su lógica — ver evaluacion-ui.js para el renderizado.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_KEY_BASE = 'm11Evaluaciones';
  const LS_AVISOS_BASE = 'm11EvaluacionAvisosPendientes';
  const LS_KEY_DEMO = 'm11EvaluacionesDemo';
  const LS_AVISOS_DEMO = 'm11EvaluacionAvisosPendientesDemo';
  const TAMANO_BLOQUE = 20;
  const DISCLAIMER = 'Este resultado corresponde únicamente al bloque analizado y no constituye garantía sobre el comportamiento futuro del torneo ni sobre la rentabilidad final de la operación.';

  // Sprint V1.0.5 — el diagnóstico también es propio de cada OPERACIÓN
  // (torneo), con el mismo criterio que ya se usó para el Libro
  // (libro.js): la operación migrada ('op-migrada-1') sigue usando las
  // claves clásicas; cualquier operación nueva usa claves propias; el
  // Centro de Pruebas tiene las suyas aparte.
  function esOperacionClasica(operacionId) { return !operacionId || operacionId === 'op-migrada-1'; }
  function operacionIdActiva() { return M11.Operaciones ? M11.Operaciones.getActivaId() : null; }
  // operacionId explícito = esa operación puntual (para reiniciarOperacion,
  // sin importar si es la activa ahora mismo); sin argumento = la activa.
  function claveEvaluaciones(operacionId) {
    if (operacionId === undefined && M11.Store && M11.Store.getCentroPruebas()) return LS_KEY_DEMO;
    const opId = operacionId !== undefined ? operacionId : operacionIdActiva();
    return esOperacionClasica(opId) ? LS_KEY_BASE : LS_KEY_BASE + '__' + opId;
  }
  function claveAvisos(operacionId) {
    if (operacionId === undefined && M11.Store && M11.Store.getCentroPruebas()) return LS_AVISOS_DEMO;
    const opId = operacionId !== undefined ? operacionId : operacionIdActiva();
    return esOperacionClasica(opId) ? LS_AVISOS_BASE : LS_AVISOS_BASE + '__' + opId;
  }

  function cargar(key) {
    try { return JSON.parse(localStorage.getItem(key) || '[]'); }
    catch (e) { return []; }
  }
  // Caché de la operación activa — se recarga sola en cuanto cambia cuál
  // operación (o el Centro de Pruebas) está activa, igual que en libro.js.
  let claveCacheada = null;
  let evaluaciones = [];
  let avisosPendientes = [];
  function activo() {
    const clave = claveEvaluaciones();
    if (clave !== claveCacheada) {
      claveCacheada = clave;
      evaluaciones = cargar(clave);
      avisosPendientes = cargar(claveAvisos());
    }
  }
  function persistirEvaluaciones() { localStorage.setItem(claveCacheada, JSON.stringify(evaluaciones)); }
  function persistirAvisos() { localStorage.setItem(claveAvisos(), JSON.stringify(avisosPendientes)); }

  function mensajePorCondiciones(n) {
    const base = {
      0: 'Evaluación completada. En este bloque no se presentaron las condiciones favorables definidas para el recorrido M11. Continúa aplicando el Modelo con disciplina.',
      1: 'Una condición favorable identificada. Continúa registrando la operación con disciplina.',
      2: 'Buen comportamiento del recorrido. En este bloque se cumplieron dos condiciones favorables del Modelo M11.',
      3: 'Excelente recorrido observado. En este bloque se cumplieron las tres condiciones favorables definidas por el Modelo M11.'
    }[n];
    return `${base} ${DISCLAIMER}`;
  }

  // Evalúa un bloque de exactamente TAMANO_BLOQUE registros consecutivos
  // del Libro (en orden ascendente por número de partido).
  function evaluarBloque(numeroBloque, registros) {
    const posicionesEmpate = [];
    registros.forEach((r, i) => { if (r.resultado === 'empate') posicionesEmpate.push(i + 1); }); // 1..20

    const empates = posicionesEmpate.length;
    const porcentajeEmpates = Math.round((empates / TAMANO_BLOQUE) * 1000) / 10;

    const cumpleC1 = empates >= 5;
    const primerEmpatePosicion = posicionesEmpate.length ? posicionesEmpate[0] : null;
    const cumpleC2 = primerEmpatePosicion !== null && primerEmpatePosicion < 12;
    let cumpleC3 = false;
    for (let p = 16; p <= 19; p++) {
      if (posicionesEmpate.includes(p) && posicionesEmpate.includes(p + 1)) { cumpleC3 = true; break; }
    }

    const condicionesCumplidas = [cumpleC1, cumpleC2, cumpleC3].filter(Boolean).length;

    return {
      bloque: numeroBloque,
      desde: registros[0].numero,
      hasta: registros[registros.length - 1].numero,
      empates,
      porcentajeEmpates,
      primerEmpatePosicion,
      cumpleC1, cumpleC2, cumpleC3,
      condicionesCumplidas,
      mensaje: mensajePorCondiciones(condicionesCumplidas),
      fechaEvaluacion: new Date().toISOString()
    };
  }

  // Revisa si hay bloques de 20 completos sin evaluar todavía (según el
  // Libro de Operaciones actual) y los calcula/persiste. Idempotente:
  // se puede llamar después de cada partido nuevo y también al abrir la
  // app (para ponerse al día con datos ya existentes) sin duplicar ni
  // recalcular un bloque ya evaluado. Devuelve solo las evaluaciones
  // NUEVAS de esta llamada, para poder avisar de un bloque recién
  // cerrado sin volver a avisar de los anteriores.
  function verificarYRegistrar() {
    if (!M11.Libro) return [];
    activo();
    const todos = M11.Libro.listar(); // orden ascendente por numero
    const bloquesCompletos = Math.floor(todos.length / TAMANO_BLOQUE);
    const yaEvaluados = evaluaciones.length;
    const nuevas = [];
    for (let b = yaEvaluados + 1; b <= bloquesCompletos; b++) {
      const inicio = (b - 1) * TAMANO_BLOQUE;
      const registrosBloque = todos.slice(inicio, inicio + TAMANO_BLOQUE);
      const evaluacion = evaluarBloque(b, registrosBloque);
      evaluaciones.push(evaluacion);
      nuevas.push(evaluacion);
    }
    if (nuevas.length) {
      persistirEvaluaciones();
      nuevas.forEach(e => { if (!avisosPendientes.includes(e.bloque)) avisosPendientes.push(e.bloque); });
      persistirAvisos();
    }
    return nuevas;
  }

  M11.Evaluacion = {
    verificarYRegistrar,
    listar() { activo(); return evaluaciones.slice(); },
    ultima() { activo(); return evaluaciones.length ? evaluaciones[evaluaciones.length - 1] : null; },
    obtener(bloque) { activo(); return evaluaciones.find(e => e.bloque === bloque) || null; },

    // Avisos: bloques recién cerrados que todavía no se le mostraron al
    // operador (para el aviso no invasivo, una sola vez).
    avisosPendientes() { activo(); return avisosPendientes.slice(); },
    marcarAvisoMostrado(bloque) {
      activo();
      avisosPendientes = avisosPendientes.filter(b => b !== bloque);
      persistirAvisos();
    },

    // Se reinicia junto con el torneo demo (M11.Transiciones.reiniciarTorneoDemo) —
    // ese botón solo es visible con el Centro de Pruebas activo, así que
    // activo() siempre resuelve al diagnóstico del Centro de Pruebas acá.
    reiniciar() {
      activo();
      evaluaciones = [];
      avisosPendientes = [];
      persistirEvaluaciones();
      persistirAvisos();
    },

    // Sprint V1.0.5 — reinicia el diagnóstico de UNA operación puntual por
    // su id, sin importar si es la activa ahora mismo (usado por
    // "Reiniciar Liga demostrativa" y por cualquier reinicio dirigido a
    // una operación específica). Nunca toca ninguna otra operación.
    reiniciarOperacion(operacionId) {
      const claveEval = claveEvaluaciones(operacionId);
      const claveAv = claveAvisos(operacionId);
      localStorage.setItem(claveEval, JSON.stringify([]));
      localStorage.setItem(claveAv, JSON.stringify([]));
      if (claveEval === claveCacheada) { evaluaciones = []; avisosPendientes = []; }
    },

    TAMANO_BLOQUE,
    // Expuesta para pruebas automatizadas.
    _evaluarBloque: evaluarBloque
  };

})(window.M11);
