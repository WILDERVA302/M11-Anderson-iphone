/* =========================================================
   M11 · sports-api.js  (Sprint 019)
   -----------------------------------------------------------
   Único módulo que habla con TheSportsDB. No conoce el motor de
   reglas M11, no conoce el Centro de Operaciones y NUNCA modifica
   capital, niveles ni estrategias — eso corresponde exclusivamente
   a m11-engine.js y a las decisiones del operador en state.js.

   Este módulo es ESTRICTAMENTE informativo (alcance aprobado del
   Sprint 019): ligas, calendario, próximos partidos y resultados
   PUBLICADOS. Un resultado que llega de aquí es siempre un dato
   "detectado, pendiente de confirmación" — el operador decide y
   confirma manualmente en el Centro de Decisiones (ver
   M11.Transiciones.registrarResultado en state.js); este archivo
   nunca llama a esa función por sí solo.

   TheSportsDB V1 gratuita: clave pública documentada "123", límite
   oficial de 30 solicitudes/min. Se usa 25/min como margen interno
   de seguridad (SPORTS_API_CONFIG.maxRequestsPerMinute). No se usa
   V2 ni marcadores en vivo — quedan fuera de este sprint.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const SPORTS_API_CONFIG = Object.freeze({
    provider: 'TheSportsDB',
    version: 'v1',
    baseUrl: 'https://www.thesportsdb.com/api/v1/json',
    apiKey: '123',
    sport: 'Soccer',
    timeoutMs: 12000,
    cacheMinutes: 30,
    maxRequestsPerMinute: 25
  });

  // ---- Límite interno de solicitudes (25/min) ---------------------------
  // Ventana deslizante en memoria: se reinicia al recargar la app, lo cual
  // es aceptable porque el propio patrón de uso (sincronizar una liga cada
  // cierto tiempo) está muy por debajo del límite oficial del proveedor.
  const _marcasDeTiempo = [];
  const RESPONSE_CACHE_KEY = 'm11_sports_response_cache_v220';
  const CACHE_FRESH_MS = 30 * 60 * 1000;
  const CACHE_STALE_MS = 7 * 24 * 60 * 60 * 1000;
  const _solicitudesEnCurso = new Map();

  function _serviceUrl() {
    try {
      const cfg=JSON.parse(localStorage.getItem('m11_ai_admin_config_v1')||'{}');
      return String(cfg.serviceUrl||'').trim();
    } catch (_) { return ''; }
  }

  async function _solicitarPuente(endpoint,params) {
    const serviceUrl=_serviceUrl();
    if(!serviceUrl)throw _error('PUENTE_NO_CONFIGURADO','El puente de calendario no está configurado.');
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),SPORTS_API_CONFIG.timeoutMs+5000);
    try{
      const response=await fetch(serviceUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'sports_schedule',context:{endpoint,params:params||{}}}),signal:controller.signal});
      let payload=null;try{payload=await response.json();}catch(_){}
      if(!response.ok||!payload||payload.ok===false)throw _error('PUENTE_NO_DISPONIBLE',(payload&&payload.error)||`El puente respondió ${response.status}.`);
      return payload.data;
    }catch(err){
      if(err&&err.codigoM11)throw err;
      if(err&&err.name==='AbortError')throw _error('TIEMPO_AGOTADO','El puente de calendario no respondió a tiempo.',err);
      throw _error('SIN_CONEXION','No fue posible contactar el puente de calendario.',err);
    }finally{clearTimeout(timer);}
  }

  function _leerCache() {
    try { return JSON.parse(localStorage.getItem(RESPONSE_CACHE_KEY) || '{}'); }
    catch (_) { return {}; }
  }
  function _guardarCache(cache) {
    try {
      const entradas=Object.entries(cache).sort((a,b)=>Number(b[1]&&b[1].savedAt||0)-Number(a[1]&&a[1].savedAt||0)).slice(0,80);
      localStorage.setItem(RESPONSE_CACHE_KEY,JSON.stringify(Object.fromEntries(entradas)));
    } catch (_) {}
  }
  function _cacheKey(endpoint,params) {
    return `${endpoint}?${Object.entries(params||{}).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('&')}`;
  }
  function _puedeSolicitar() {
    const ahora = Date.now();
    while (_marcasDeTiempo.length && ahora - _marcasDeTiempo[0] > 60000) _marcasDeTiempo.shift();
    return _marcasDeTiempo.length < SPORTS_API_CONFIG.maxRequestsPerMinute;
  }
  function _registrarSolicitud() { _marcasDeTiempo.push(Date.now()); }

  function buildSportsApiUrl(endpoint, params = {}) {
    const url = new URL(`${SPORTS_API_CONFIG.baseUrl}/${SPORTS_API_CONFIG.apiKey}/${endpoint}`);
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, String(value));
      }
    });
    return url.toString();
  }

  // Errores clasificados: la capa que consume esto (league-service.js)
  // traduce cada código a uno de los "Estados de conexión" que exige la
  // interfaz (sección 16 del encargo) — nunca deja la pantalla vacía.
  function _error(codigo, mensaje, causa) {
    const e = new Error(mensaje);
    e.codigoM11 = codigo;
    if (causa) e.causaOriginal = causa;
    return e;
  }

  // Única función de bajo nivel que llega a la red. Aplica el límite
  // interno, el tiempo de espera (AbortController) y clasifica errores;
  // nunca inventa datos si algo falla.
  async function _solicitarRed(endpoint, params) {
    if (!_puedeSolicitar()) {
      throw _error('LIMITE_LOCAL', 'Se alcanzó el margen interno de solicitudes por minuto. Intente de nuevo en unos segundos.');
    }
    // En Android se prioriza el puente privado. Este camino NO usa OpenAI;
    // solo retransmite y conserva la respuesta pública de TheSportsDB.
    // Si aún no se desplegó el puente 2.2.1, se conserva la ruta directa.
    if(_serviceUrl()){
      try{return await _solicitarPuente(endpoint,params);}
      catch(puenteError){console.warn('M11: puente deportivo no disponible; intentando proveedor directo',puenteError&&puenteError.message);}
    }
    const url = buildSportsApiUrl(endpoint, params);
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), SPORTS_API_CONFIG.timeoutMs);
    _registrarSolicitud();
    let respuesta;
    try {
      respuesta = await fetch(url, { signal: controlador.signal });
    } catch (err) {
      if (err && err.name === 'AbortError') {
        throw _error('TIEMPO_AGOTADO', 'TheSportsDB no respondió a tiempo.', err);
      }
      throw _error('SIN_CONEXION', 'No fue posible contactar a TheSportsDB.', err);
    } finally {
      clearTimeout(temporizador);
    }
    if (respuesta.status === 429) {
      throw _error('LIMITE_PROVEEDOR', 'TheSportsDB indicó demasiadas solicitudes (429).');
    }
    if (!respuesta.ok) {
      throw _error('SERVICIO_NO_DISPONIBLE', `TheSportsDB respondió con estado ${respuesta.status}.`);
    }
    let datos;
    try {
      datos = await respuesta.json();
    } catch (err) {
      throw _error('RESPUESTA_INVALIDA', 'TheSportsDB devolvió una respuesta que no se pudo interpretar.', err);
    }
    if (datos === null) return null;
    return datos;
  }

  // Una misma consulta nunca se repite mientras otra copia esté en curso.
  // Además, si la red falla se conserva hasta siete días la última respuesta
  // publicada. La caché solo contiene datos del proveedor: jamás capital,
  // niveles, decisiones ni resultados introducidos por el usuario.
  async function _solicitar(endpoint, params, opciones) {
    const opts=opciones||{},key=_cacheKey(endpoint,params),cache=_leerCache(),entry=cache[key],now=Date.now();
    const freshMs=Number(opts.freshMs)||CACHE_FRESH_MS;
    if(!opts.force&&entry&&now-Number(entry.savedAt||0)<freshMs)return entry.data;
    if(_solicitudesEnCurso.has(key))return _solicitudesEnCurso.get(key);
    const request=(async()=>{
      try{
        const data=await _solicitarRed(endpoint,params);
        cache[key]={savedAt:Date.now(),data};_guardarCache(cache);return data;
      }catch(error){
        if(entry&&now-Number(entry.savedAt||0)<CACHE_STALE_MS){
          console.warn('M11: usando información deportiva guardada por falla de red',endpoint,error&&error.message);
          return entry.data;
        }
        throw error;
      }finally{_solicitudesEnCurso.delete(key);}
    })();
    _solicitudesEnCurso.set(key,request);return request;
  }

  // ---- Endpoints autorizados (sección 4 del encargo) ---------------------

  // search_all_leagues.php?c=PAIS&s=Soccer — filtra por deporte fútbol,
  // ordena alfabéticamente y devuelve solo los campos que la interfaz
  // necesita. El operador nunca escribe ni ve el idLeague como dato
  // principal.
  // Sprint V1.0.5, sección 11: "priorizar ligas según país y selección
  // del usuario" — dentro de un país, TheSportsDB puede devolver la
  // liga principal mezclada alfabéticamente con categorías femeninas,
  // juveniles o de reserva. Estas se muestran igual (no se ocultan,
  // el operador puede necesitarlas), pero se ordenan después de las
  // ligas "principales", para que la más buscada normalmente no quede
  // enterrada en la lista.
  const PALABRAS_LIGA_SECUNDARIA = ['women', 'femenino', 'femenina', 'youth', 'juvenil', 'reserve', 'reserva', ' u23', ' u21', ' u20', ' u19', ' u18', ' u17', 'sub-23', 'sub-21', 'sub-20', 'sub-19', 'sub-18', 'sub-17'];
  function _esLigaSecundaria(nombre) {
    const n = (' ' + (nombre || '').toLowerCase());
    return PALABRAS_LIGA_SECUNDARIA.some(p => n.includes(p));
  }

  async function buscarLigasPorPais(pais) {
    const datos = await _solicitar('search_all_leagues.php', { c: pais, s: SPORTS_API_CONFIG.sport });
    const lista = (datos && Array.isArray(datos.countries)) ? datos.countries : [];
    return lista
      .filter(l => (l.strSport || '').toLowerCase() === SPORTS_API_CONFIG.sport.toLowerCase())
      .map(l => ({
        id: l.idLeague,
        name: l.strLeague,
        alternateName: l.strLeagueAlternate || '',
        country: l.strCountry,
        sport: l.strSport,
        gender: l.strGender || '',
        badge: l.strBadge || l.strLogo || ''
      }))
      .sort((a, b) => a.name.localeCompare(b.name, 'es'))
      .sort((a, b) => Number(_esLigaSecundaria(a.name)) - Number(_esLigaSecundaria(b.name)));
  }

  const INTERNACIONAL = /\b(uefa|fifa|conmebol|concacaf|caf|afc|ofc|world cup|copa america|copa am[eé]rica|libertadores|sudamericana|nations league|champions league|europa league|conference league|european championship|gold cup|asian cup|africa cup of nations)\b/i;
  async function buscarCompeticionesInternacionales() {
    const datos=await _solicitar('all_leagues.php',{});
    const lista=datos&&Array.isArray(datos.leagues)?datos.leagues:[];
    return lista.filter(l=>(l.strSport||'').toLowerCase()===SPORTS_API_CONFIG.sport.toLowerCase())
      .filter(l=>INTERNACIONAL.test(`${l.strLeague||''} ${l.strLeagueAlternate||''}`))
      .map(l=>({id:l.idLeague,name:l.strLeague,alternateName:l.strLeagueAlternate||'',country:l.strCountry||'Internacional',sport:l.strSport,gender:l.strGender||'',badge:l.strBadge||l.strLogo||''}))
      .sort((a,b)=>a.name.localeCompare(b.name,'es'));
  }

  // lookupleague.php?id=ID_LIGA
  async function consultarLiga(idLiga) {
    const datos = await _solicitar('lookupleague.php', { id: idLiga });
    const lista = (datos && Array.isArray(datos.leagues)) ? datos.leagues : [];
    return lista[0] || null;
  }

  // lookupevent.php?id=ID_EVENTO — segunda comprobación para una operación
  // sombra abierta cuando el resumen de la liga todavía no se ha actualizado.
  async function consultarPartido(idEvento) {
    const datos = await _solicitar('lookupevent.php', { id: idEvento });
    const lista = (datos && Array.isArray(datos.events)) ? datos.events : [];
    return lista[0] || null;
  }

  // searchevents.php?e=NOMBRE — respaldo para eventos cuyo identificador
  // cambió o dejó de aparecer en los resúmenes de la liga. La selección
  // segura por competición, equipos, localía y fecha se realiza en
  // shadow-sync.js; esta función solo devuelve datos publicados.
  async function buscarPartidosPorNombre(nombre) {
    if (!nombre) return [];
    const datos = await _solicitar('searchevents.php', { e: nombre });
    return (datos && Array.isArray(datos.event)) ? datos.event :
      (datos && Array.isArray(datos.events)) ? datos.events : [];
  }

  // eventsnextleague.php?id=ID_LIGA
  async function proximosPartidosLiga(idLiga) {
    const datos = await _solicitar('eventsnextleague.php', { id: idLiga });
    return (datos && Array.isArray(datos.events)) ? datos.events : [];
  }

  // eventspastleague.php?id=ID_LIGA
  async function partidosAnterioresLiga(idLiga) {
    const datos = await _solicitar('eventspastleague.php', { id: idLiga });
    return (datos && Array.isArray(datos.results)) ? datos.results : (datos && Array.isArray(datos.events)) ? datos.events : [];
  }

  // Calendario publicado de una temporada. Se consume únicamente desde
  // laboratorios retrospectivos y nunca modifica capital por sí mismo.
  async function partidosTemporadaLiga(idLiga, temporada) {
    if (!temporada) throw _error('TEMPORADA_REQUERIDA', 'El laboratorio retrospectivo requiere una temporada.');
    const datos = await _solicitar('eventsseason.php', { id: idLiga, s: temporada });
    return (datos && Array.isArray(datos.events)) ? datos.events : [];
  }

  // Respaldo del calendario normal. eventsnextleague/eventspastleague pueden
  // devolver una lista vacía aun cuando existen encuentros ese día. Esta
  // consulta obtiene el tablero diario completo y luego cada consumidor
  // filtra estrictamente por id de liga. Gracias a la caché, los once
  // campeonatos comparten la misma descarga.
  async function partidosDelDia(fecha) {
    const datos=await _solicitar('eventsday.php',{d:fecha,s:SPORTS_API_CONFIG.sport},{freshMs:2*60*60*1000});
    return (datos&&Array.isArray(datos.events))?datos.events:[];
  }

  function _fechaBogota(offsetDias) {
    const d=new Date(Date.now()+(Number(offsetDias)||0)*86400000);
    const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Bogota',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(d);
    const out={};parts.forEach(p=>out[p.type]=p.value);return `${out.year}-${out.month}-${out.day}`;
  }

  async function partidosVentanaDiaria() {
    const dias=[-1,0,1].map(_fechaBogota);
    const respuestas=await Promise.all(dias.map(fecha=>partidosDelDia(fecha).catch(()=>[])));
    const porId=new Map();respuestas.flat().forEach(e=>{if(e&&e.idEvent)porId.set(String(e.idEvent),e);});
    return Array.from(porId.values());
  }

  // ---- Normalización (sección 7 y 8 del encargo) --------------------------

  function parseNullableNumber(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  // Number(null) y Number('') devuelven 0. Antes de convertir, se exige
  // que ambos valores del marcador hayan sido publicados realmente.
  function hasPublishedScore(event) {
    return event.intHomeScore !== null && event.intHomeScore !== undefined && event.intHomeScore !== '' &&
      event.intAwayScore !== null && event.intAwayScore !== undefined && event.intAwayScore !== '' &&
      Number.isFinite(Number(event.intHomeScore)) && Number.isFinite(Number(event.intAwayScore));
  }

  // La documentación de TheSportsDB indica que sus fechas/horas están en
  // UTC. Se conserva ese instante exacto en timestampUTC (nunca se altera)
  // y se deriva por separado la fecha/hora LOCAL del usuario, que es lo
  // que el resto de la app (calendar.js, ui.js, countdown.js) ya sabe leer.
  //
  // Sprint 020 — corrección del desfase de 5 horas: si strTimestamp NO
  // trae marca de zona explícita (ni "Z" ni un desplazamiento +HH:MM/
  // -HH:MM), NO se debe asumir que ya es la hora local del navegador —
  // ese fue exactamente el origen del bug reportado. Se normaliza y se
  // fuerza la interpretación como UTC, tal como documenta el proveedor.
  function _pareceTenerZonaHoraria(cadena) {
    return /Z$/i.test(cadena) || /[+-]\d{2}:?\d{2}$/.test(cadena);
  }

  function buildEventTimestamp(event) {
    if (event.strTimestamp) {
      let valor = String(event.strTimestamp).trim();
      if (!_pareceTenerZonaHoraria(valor)) {
        valor = valor.replace(' ', 'T') + 'Z';
      }
      const parsed = new Date(valor);
      if (!Number.isNaN(parsed.getTime())) return parsed.toISOString();
    }
    if (!event.dateEvent) return null;
    const time = event.strTime || '00:00:00';
    const parsed = new Date(`${event.dateEvent}T${time}Z`);
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
  }

  // ---- Presentación en la zona horaria de Colombia (Sprint 020) ---------
  // No se usa la zona del sistema operativo/navegador para presentar la
  // hora al usuario: exactamente eso causó el desfase de 5 horas
  // reportado (un equipo con la hora del sistema en UTC hacía que
  // getHours()/toLocaleString() sin zona explícita mostraran la hora UTC
  // cruda en vez de convertirla). Se usa Intl.DateTimeFormat con
  // timeZone:'America/Bogota' EXPLÍCITO sobre el instante absoluto en
  // milisegundos — ese instante ya es correcto sin importar cómo se haya
  // calculado (ver nota en ui.js/calendar.js: la aritmética interna de
  // fecha/hora es autoconsistente y no se toca en este sprint), así que
  // esta es la única corrección necesaria para mostrarlo bien.
  const ZONA_HORARIA_DISPLAY = 'America/Bogota';

  function formatearFechaHora(ms, opciones) {
    if (ms === null || ms === undefined || Number.isNaN(ms)) return '—';
    const base = { timeZone: ZONA_HORARIA_DISPLAY, weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' };
    return new Date(ms).toLocaleString('es-CO', Object.assign({}, base, opciones || {}));
  }

  function _fechaHoraLocal(timestampUTC) {
    if (!timestampUTC) return { fecha: null, hora: null };
    const d = new Date(timestampUTC);
    const pad = n => String(n).padStart(2, '0');
    return {
      fecha: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
      hora: `${pad(d.getHours())}:${pad(d.getMinutes())}`
    };
  }

  // Solo informativo: NUNCA se usa para mover capital ni niveles por sí
  // solo. Es el dato que se muestra como "resultado detectado, pendiente
  // de confirmación" (sección 13) hasta que el operador lo confirme a
  // través del selector normal de EST-06 (dc-resultado-selector, en
  // ui.js/events.js) — el mismo camino que un cierre manual.
  function resultadoSugerido(event) {
    if (!hasPublishedScore(event)) return null;
    const home = Number(event.intHomeScore);
    const away = Number(event.intAwayScore);
    if (!Number.isFinite(home) || !Number.isFinite(away)) return null;
    return home === away ? 'empate' : 'no_empate';
  }

  // Estado del evento tal como lo informa TheSportsDB, reducido a lo que
  // la interfaz necesita para no dejar nunca la pantalla ambigua.
  function normalizeEventStatus(event, timestampUTC) {
    const estadoTexto = (event.strStatus || '').toLowerCase();
    if (estadoTexto.includes('postponed') || estadoTexto.includes('aplazado')) return 'aplazado';
    if (estadoTexto.includes('cancel')) return 'cancelado';
    if (estadoTexto.includes('susp') || estadoTexto.includes('stopped') || estadoTexto.includes('abandon') || estadoTexto.includes('interrupted') || estadoTexto.includes('parado')) return 'suspendido';
    const finalExplicito=estadoTexto.includes('match finished')||estadoTexto.includes('finished')||['ft','aet','pen'].includes(estadoTexto.trim());
    if(finalExplicito)return 'finalizado';
    const enCurso=estadoTexto.includes('live')||estadoTexto.includes('in progress')||['1h','2h','ht','et'].includes(estadoTexto.trim());
    if(enCurso)return 'en_curso';
    // Respaldo para V1 gratuita: si trae marcador pero omite el estado, solo
    // se considera definitivo tres horas después de la hora programada.
    const kickoff=timestampUTC?new Date(timestampUTC).getTime():NaN;
    if(hasPublishedScore(event)&&Number.isFinite(kickoff))return Date.now()-kickoff>=3*60*60*1000?'finalizado':'en_curso';
    return 'programado';
  }

  // Sprint 020, sección 9: "si existe contradicción entre marcador y
  // estado, mostrar una advertencia y pedir verificación manual" — en
  // vez de sugerir un resultado que podría estar mal. Dos contradicciones
  // conocidas: el proveedor marca el partido como no comenzado pero ya
  // trae marcador, o lo marca cancelado/suspendido pero también trae
  // marcador. En cualquiera de los dos casos no se sugiere resultado.
  function detectarContradiccion(event, estadoNormalizado) {
    const estadoTexto = (event.strStatus || '').toLowerCase();
    const hayMarcador = hasPublishedScore(event);
    const noComenzado = estadoTexto.includes('not started') || estadoTexto.includes('ns') === true && estadoTexto.trim() === 'ns';
    if (hayMarcador && noComenzado) return true;
    if (hayMarcador && (estadoNormalizado === 'cancelado' || estadoNormalizado === 'suspendido' || estadoNormalizado === 'aplazado')) return true;
    if (!hayMarcador && estadoNormalizado === 'finalizado') return true;
    return false;
  }

  function normalizeSportsDbEvent(event, leagueConfig) {
    const timestampUTC = buildEventTimestamp(event);
    const { fecha, hora } = _fechaHoraLocal(timestampUTC);
    const status = normalizeEventStatus(event, timestampUTC);
    const contradiccion = detectarContradiccion(event, status);
    return {
      externalId: String(event.idEvent || ''),
      provider: SPORTS_API_CONFIG.provider,
      leagueId: String(event.idLeague || (leagueConfig && leagueConfig.leagueId) || ''),
      leagueName: event.strLeague || (leagueConfig && leagueConfig.leagueName) || '',
      season: event.strSeason || (leagueConfig && leagueConfig.season) || '',
      round: event.intRound || null,
      eventName: event.strEvent || '',
      homeTeam: event.strHomeTeam || '',
      awayTeam: event.strAwayTeam || '',
      homeTeamId: event.idHomeTeam || null,
      awayTeamId: event.idAwayTeam || null,
      homeScore: parseNullableNumber(event.intHomeScore),
      awayScore: parseNullableNumber(event.intAwayScore),
      fecha,
      hora,
      timestampUTC,
      venue: event.strVenue || '',
      status,
      // Un marcador visible NO equivale a resultado. Muchos proveedores
      // publican 0-0 antes o durante el partido. Solo exponemos una
      // liquidación cuando el propio estado normalizado es FINALIZADO.
      resultadoSugerido: (!contradiccion && status === 'finalizado') ? resultadoSugerido(event) : null,
      resultadoContradictorio: contradiccion,
      sourceData: event
    };
  }

  M11.SportsApi = {
    CONFIG: SPORTS_API_CONFIG,
    ZONA_HORARIA_DISPLAY,
    buildSportsApiUrl,
    buscarLigasPorPais,
    buscarCompeticionesInternacionales,
    consultarLiga,
    consultarPartido,
    buscarPartidosPorNombre,
    proximosPartidosLiga,
    partidosAnterioresLiga,
    partidosTemporadaLiga,
    partidosDelDia,
    partidosVentanaDiaria,
    normalizeSportsDbEvent,
    buildEventTimestamp,
    formatearFechaHora,
    resultadoSugerido
  };

})(window.M11);
