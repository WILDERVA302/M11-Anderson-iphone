/* Persistencia exclusiva de Operación Sombra. Nunca toca datos reales/demo. */
window.M11 = window.M11 || {};
(function (M11) {
  'use strict';
  const STORAGE_KEY = 'm11_shadow_operation_v1';
  let memory = null;
  function emptyExperiment() { return M11.ShadowEngine.createExperiment(); }
  function load() {
    if (memory) return memory;
    try { memory = JSON.parse(localStorage.getItem(STORAGE_KEY)) || emptyExperiment(); }
    catch (_) { memory = emptyExperiment(); }
    if (memory.mode !== 'shadow' || !Array.isArray(memory.tournaments)) memory = emptyExperiment();
    return memory;
  }
  function save(experiment) {
    memory = experiment || load();
    memory.updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
    return memory;
  }
  function addTournament(input) {
    const experiment = load();
    M11.ShadowEngine.addTournament(experiment, input);
    save(experiment);
    return experiment.tournaments[experiment.tournaments.length - 1];
  }
  function removeTournament(id) {
    const experiment = load();
    const before = experiment.tournaments.length;
    experiment.tournaments = experiment.tournaments.filter(t => t.id !== String(id));
    if (experiment.tournaments.length !== before) save(experiment);
    return experiment.tournaments.length !== before;
  }
  function setTournamentStatus(id, status) {
    const tournament = load().tournaments.find(t => t.id === String(id));
    if (!tournament || !['active', 'paused'].includes(status)) return false;
    tournament.status = status; save(load()); return true;
  }
  function processResult(id, event) {
    const experiment = load();
    const tournament = experiment.tournaments.find(t => t.id === String(id));
    if (!tournament) throw new Error('Campeonato sombra no encontrado.');
    const response = M11.ShadowEngine.processResult(tournament, event);
    if (response.applied) save(experiment);
    return response;
  }
  M11.ShadowStore = { STORAGE_KEY, load, save, addTournament, removeTournament, setTournamentStatus, processResult };
})(window.M11);
