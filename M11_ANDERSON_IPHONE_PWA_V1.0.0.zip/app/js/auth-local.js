/* =========================================================
   M11 · auth-local.js  (Sprint V1.0.5, sección 3)
   -----------------------------------------------------------
   IMPORTANTE — léalo antes de tocar este archivo: esto NO es
   autenticación real. No hay servidor, no hay verificación de
   correo, no hay recuperación real de contraseña. Todo vive en
   localStorage de este dispositivo. Cualquiera con acceso físico al
   dispositivo o a sus herramientas de desarrollador puede leer o
   modificar esta información. Es exactamente lo que el encargo pidió
   para esta beta: "no presentar un login demostrativo como
   autenticación real."

   Qué SÍ hace esta capa:
   - Permite crear una cuenta local (nombre, correo, contraseña) y
     usarla para entrar, en vez de depender solo del correo/clave de
     demostración fijos.
   - Guarda la contraseña con un hash simple (no criptográfico: solo
     para no guardarla en texto plano por descuido) — NO es
     protección real. Ver hashSimple() más abajo.
   - Mantiene "Recordar sesión" y "Salir" exactamente como ya
     funcionaban.
   - Conserva el acceso de demostración
     (director@m11.demo / m11demo) para que la beta siga siendo
     accesible sin crear una cuenta.

   Qué NO hace (requiere backend, fuera de este sprint):
   - Verificar que el correo realmente existe o pertenece a quien
     se registra.
   - Recuperar una contraseña olvidada de verdad (enviar un correo,
     un enlace de restablecimiento, etc.).
   - Sincronizar la cuenta entre dispositivos.
   - Proteger contra alguien con acceso al propio dispositivo.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_USUARIOS = 'm11_usuarios_locales_v1';
  const LS_USUARIO_ACTUAL = 'm11_usuario_actual_v1';

  const CUENTA_DEMO = { correo: 'director@m11.demo', clave: 'm11demo', nombre: 'Director (demostración)' };

  // Hash simple (djb2), NO criptográfico — ver el aviso arriba. Sirve
  // solo para no dejar la contraseña en texto plano en localStorage.
  function hashSimple(texto) {
    let h = 5381;
    for (let i = 0; i < texto.length; i++) { h = ((h * 33) ^ texto.charCodeAt(i)) >>> 0; }
    return 'h' + h.toString(16);
  }

  function leerUsuarios() {
    try {
      const raw = localStorage.getItem(LS_USUARIOS);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }
  function guardarUsuarios(obj) { localStorage.setItem(LS_USUARIOS, JSON.stringify(obj)); }

  function normalizarCorreo(correo) { return (correo || '').trim().toLowerCase(); }

  // Devuelve { ok:true } o { ok:false, motivo } — nunca revela cuál
  // campo falló al mostrarlo (eso lo decide la interfaz, ver events.js).
  function registrar({ nombre, correo, clave }) {
    const correoN = normalizarCorreo(correo);
    if (!nombre || !nombre.trim()) return { ok: false, motivo: 'nombre' };
    if (!correoN || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correoN)) return { ok: false, motivo: 'correo' };
    if (!clave || clave.length < 6) return { ok: false, motivo: 'clave_corta' };
    if (correoN === CUENTA_DEMO.correo) return { ok: false, motivo: 'correo_reservado' };
    const usuarios = leerUsuarios();
    if (usuarios[correoN]) return { ok: false, motivo: 'correo_existente' };
    usuarios[correoN] = { nombre: nombre.trim(), correo: correoN, claveHash: hashSimple(clave), fechaRegistro: new Date().toISOString() };
    guardarUsuarios(usuarios);
    return { ok: true, usuario: { nombre: usuarios[correoN].nombre, correo: correoN } };
  }

  // Valida contra las cuentas locales registradas O la cuenta de
  // demostración. Un solo resultado genérico (sin decir cuál campo
  // falló) — la interfaz ya lo maneja así desde la versión 1.0.3.
  function validar({ correo, clave }) {
    const correoN = normalizarCorreo(correo);
    if (correoN === CUENTA_DEMO.correo && clave === CUENTA_DEMO.clave) {
      return { ok: true, usuario: { nombre: CUENTA_DEMO.nombre, correo: CUENTA_DEMO.correo, demo: true } };
    }
    const usuarios = leerUsuarios();
    const u = usuarios[correoN];
    if (u && u.claveHash === hashSimple(clave)) {
      return { ok: true, usuario: { nombre: u.nombre, correo: u.correo, demo: false } };
    }
    return { ok: false };
  }

  function setUsuarioActual(usuario) { localStorage.setItem(LS_USUARIO_ACTUAL, JSON.stringify(usuario)); }
  function getUsuarioActual() {
    try {
      const raw = localStorage.getItem(LS_USUARIO_ACTUAL);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function cerrarSesion() { localStorage.removeItem(LS_USUARIO_ACTUAL); }

  M11.AuthLocal = {
    CUENTA_DEMO_CORREO: CUENTA_DEMO.correo,
    registrar,
    validar,
    setUsuarioActual,
    getUsuarioActual,
    cerrarSesion
  };

})(window.M11);
