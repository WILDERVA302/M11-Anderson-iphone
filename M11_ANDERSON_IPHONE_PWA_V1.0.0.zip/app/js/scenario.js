/* Simulador educativo independiente: nunca persiste ni modifica operaciones. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.M11=root.M11||{};root.M11.Scenario=api;})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const MAX_LEVEL=11,NAMES=['general','pares','impares'];
  function amount(base,level){return base*Math.pow(2,level-1);}
  function budget(base){return base*(Math.pow(2,MAX_LEVEL)-1);}
  function simulate(input){
    const matches=Math.max(1,Math.min(100,Number(input.matches)||22)),base=Math.max(1,Number(input.base)||1000),quota=Math.max(1.01,Number(input.quota)||3.6);
    const draws=new Set((input.draws||[]).map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=matches));
    const strategies={general:{level:1,balance:budget(base),closed:false,closedAt:null},pares:{level:1,balance:budget(base),closed:false,closedAt:null},impares:{level:1,balance:budget(base),closed:false,closedAt:null}};
    let totalUsed=0,maximumUsed=0;const simultaneousLosses=[];
    for(let number=1;number<=matches;number++){
      const participants=['general',number%2===0?'pares':'impares'].filter(name=>!strategies[name].closed),isDraw=draws.has(number),closing=[];
      const used=participants.reduce((sum,name)=>sum+amount(base,strategies[name].level),0);totalUsed+=used;maximumUsed=Math.max(maximumUsed,used);
      participants.forEach(name=>{const s=strategies[name],stake=amount(base,s.level);if(isDraw){s.balance+=stake*(quota-1);s.level=1;}else{s.balance-=stake;if(s.level===MAX_LEVEL){s.closed=true;s.closedAt=number;closing.push(name);}else s.level+=1;}});
      if(closing.length>=2)simultaneousLosses.push({match:number,strategies:closing.slice()});
    }
    const patrimonio=NAMES.reduce((sum,name)=>sum+strategies[name].balance,0);
    return {matches,draws:Array.from(draws).sort((a,b)=>a-b),base,quota,initialCapital:budget(base)*3,totalUsed,maximumUsed,patrimonio,strategies,simultaneousLosses};
  }
  return {MAX_LEVEL,simulate};
});
