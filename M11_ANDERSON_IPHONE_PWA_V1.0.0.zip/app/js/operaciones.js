/* =========================================================
   M11 · operaciones.js  (Sprint V1.0.5)
   -----------------------------------------------------------
   "Operación" = un torneo/liga que el operador está siguiendo con
   el Modelo M11. Cada operación tiene su PROPIO capital, base,
   niveles de General/Pares/Impares, historial de partidos y
   apuesta pendiente — completamente separados de cualquier otra
   operación y del Centro de Pruebas (ver state.js,
   almacenEstrategiasActivo/almacenDecisionActivo).

   Este módulo NO decide ninguna regla del Modelo M11: solo
   administra CUÁL conjunto de datos (cuál operación) está activo en
   cada momento. Las reglas (progresión, Nivel 11, paridad, etc.)
   siguen viviendo exclusivamente en m11-engine.js, sin cambios.

   Ciclo de vida de una operación:
   - 'activa'    : la que recibe apuestas y resultados ahora mismo.
                   Solo puede haber una activa a la vez.
   - 'pausada'   : no es la activa en este momento, pero el operador
                   puede volver a ella libremente en cualquier
                   momento — no reinicia nada.
   - 'finalizada': el operador la cerró explícitamente. Queda en modo
                   consulta (de solo lectura): no admite apuestas
                   nuevas hasta una reapertura explícita, y ninguna
                   estrategia que haya quedado bloqueada en Nivel 11
                   puede reactivarse jamás, se reabra o no la
                   operación — esa regla vive en el propio dato de la
                   estrategia (bloqueada), que esta capa nunca toca.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_OPERACIONES = 'm11_operaciones_v1';
  const LS_ACTIVA = 'm11_operacion_activa_v1';
  const LS_MIGRADO = 'm11_operaciones_migrado_v1';

  function leerOperaciones() {
    try {
      const raw = localStorage.getItem(LS_OPERACIONES);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }
  function guardarOperaciones(obj) { localStorage.setItem(LS_OPERACIONES, JSON.stringify(obj)); }

  function nuevoId() { return 'op-' + Date.now() + '-' + Math.floor(Math.random() * 1000); }

  function listar() {
    const obj = leerOperaciones();
    return Object.keys(obj).map(id => obj[id]).sort((a, b) => new Date(b.fechaInicio) - new Date(a.fechaInicio));
  }

  function obtener(id) { return leerOperaciones()[id] || null; }

  function getActivaId() { return localStorage.getItem(LS_ACTIVA); }

  function getActiva() {
    const id = getActivaId();
    return id ? obtener(id) : null;
  }

  // Sincroniza M11.Engine.CONFIG.BASE con la operación indicada — mismo
  // mecanismo que onboarding.js ya usaba una sola vez; ahora se repite
  // cada vez que cambia la operación activa, para que el nivel 1 de esa
  // operación específica recomiende su propia base ($1.000, $2.000, la
  // que haya declarado).
  function sincronizarBaseConEngine(operacion) {
    if (operacion && typeof operacion.base === 'number' && operacion.base > 0) {
      M11.Engine.CONFIG.BASE = operacion.base;
    }
  }

  // ---- Crear ---------------------------------------------------------------
  // Advertencia de capital (sección 4 del encargo): se devuelve como texto
  // para que la interfaz la muestre antes de confirmar — este módulo no
  // impide crear la operación, solo advierte; no hay forma de comprobar
  // desde el navegador si ese dinero ya está comprometido en otro lado.
  const AVISO_CAPITAL = 'Cada torneo es una operación independiente. No asigne a este torneo capital que ya esté comprometido en otra operación activa.';

  function crear({ nombre, base, capitalInicial, activarInmediatamente, leagueId, country, season, leagueName, badge }) {
    const ops = leerOperaciones();
    const id = nuevoId();
    const operacion = {
      id,
      nombre: nombre || 'Operación sin nombre',
      base: (typeof base === 'number' && base > 0) ? base : 1000,
      capitalInicial: (typeof capitalInicial === 'number' && capitalInicial > 0) ? capitalInicial : null,
      fechaInicio: new Date().toISOString(),
      estado: 'pausada',
      fechaFinalizacion: null
      ,leagueId: leagueId ? String(leagueId) : null
      ,country: country || ''
      ,season: season || ''
      ,leagueName: leagueName || nombre || ''
      ,badge: badge || ''
    };
    ops[id] = operacion;
    guardarOperaciones(ops);
    if (activarInmediatamente !== false) activar(id);
    return operacion;
  }

  // ---- Activar / pausar / finalizar / reabrir ------------------------------
  // Solo una operación puede estar "activa" a la vez: al activar una, las
  // demás que estuvieran activas pasan a "pausada" (nunca se pierden ni se
  // mezclan, solo dejan de ser la que recibe apuestas nuevas).
  function activar(id) {
    const ops = leerOperaciones();
    const objetivo = ops[id];
    if (!objetivo) return null;
    if (objetivo.estado === 'finalizada') return null; // requiere reabrir() explícito, no activar()
    Object.keys(ops).forEach(k => { if (ops[k].estado === 'activa') ops[k].estado = 'pausada'; });
    objetivo.estado = 'activa';
    guardarOperaciones(ops);
    localStorage.setItem(LS_ACTIVA, id);
    sincronizarBaseConEngine(objetivo);
    return objetivo;
  }

  function pausar(id) {
    const ops = leerOperaciones();
    if (!ops[id] || ops[id].estado !== 'activa') return null;
    ops[id].estado = 'pausada';
    guardarOperaciones(ops);
    return ops[id];
  }

  function finalizar(id) {
    const ops = leerOperaciones();
    if (!ops[id]) return null;
    ops[id].estado = 'finalizada';
    ops[id].fechaFinalizacion = new Date().toISOString();
    guardarOperaciones(ops);
    return ops[id];
  }

  // Reapertura explícita y segura: NUNCA reactiva una estrategia bloqueada
  // en Nivel 11 (esa protección vive en el propio dato de la estrategia —
  // esta función no la toca en absoluto, solo cambia el estado del
  // torneo de 'finalizada' a 'pausada', dejándolo disponible para
  // activar() como cualquier otra operación pausada).
  function reabrir(id) {
    const ops = leerOperaciones();
    if (!ops[id] || ops[id].estado !== 'finalizada') return null;
    ops[id].estado = 'pausada';
    ops[id].fechaFinalizacion = null;
    guardarOperaciones(ops);
    return ops[id];
  }

  // ---- Migración desde la versión anterior (una sola operación global) ----
  // Antes de esta versión existía una sola operación real implícita (las
  // claves m11EstrategiasEngine / m11DecisionPartido / m11Libro, sin
  // concepto de torneo). Se ejecuta una única vez: si el operador ya tenía
  // datos, se crea la primera operación con ellos EXACTAMENTE donde
  // estaban (mismas claves de almacenamiento — ver state.js), así que no
  // hay copia ni riesgo de duplicar/perder nada; solo se registra el
  // metadato de la operación y se marca esa clave como "la operación
  // migrada". Si no había datos (instalación nueva), no crea nada — la
  // primera operación real se crea al terminar la configuración inicial
  // guiada (ver crearDesdeConfiguracionInicial).
  function inicializar() {
    if (localStorage.getItem(LS_MIGRADO) === 'done') {
      // Ya migrado: solo asegura que el puntero de "activa" siga apuntando
      // a algo que existe (por si se borró a mano en algún momento).
      const activaId = getActivaId();
      if (!activaId || !obtener(activaId)) {
        const primera = listar().find(o => o.estado === 'activa') || listar()[0];
        if (primera) { localStorage.setItem(LS_ACTIVA, primera.id); sincronizarBaseConEngine(primera); }
      } else {
        sincronizarBaseConEngine(obtener(activaId));
      }
      return;
    }

    const config = M11.Store.getConfiguracionInicial();
    const habiaDatosReales = !!localStorage.getItem('m11EstrategiasEngine') || !!localStorage.getItem('m11DecisionPartido') || !!localStorage.getItem('m11Libro');

    if (config || habiaDatosReales) {
      const ops = leerOperaciones();
      const id = 'op-migrada-1';
      ops[id] = {
        id,
        nombre: (config && config.torneo) || 'Operación inicial',
        base: (config && config.base) || 1000,
        capitalInicial: (config && config.capitalDeclarado) || null,
        fechaInicio: new Date().toISOString(),
        estado: 'activa',
        fechaFinalizacion: null,
        migrada: true
      };
      guardarOperaciones(ops);
      localStorage.setItem(LS_ACTIVA, id);
      // Las claves reales (m11EstrategiasEngine, m11DecisionPartido)
      // pasan a pertenecerle a esta operación tal cual estaban — ver
      // state.js: almacenEstrategiasRealDe('op-migrada-1') apunta
      // exactamente a esas claves clásicas, sin copiar nada.
      sincronizarBaseConEngine(ops[id]);
    }
    localStorage.setItem(LS_MIGRADO, 'done');
  }

  // Se llama al terminar la configuración inicial guiada (onboarding),
  // cuando NO había datos previos que migrar — crea la primera operación
  // real desde cero con lo que el operador acaba de declarar.
  function crearDesdeConfiguracionInicial() {
    if (localStorage.getItem(LS_MIGRADO) === 'done' && getActivaId()) return getActiva();
    const config = M11.Store.getConfiguracionInicial();
    const operacion = crear({
      nombre: (config && config.torneo) || 'Mi primera operación',
      base: (config && config.base) || 1000,
      capitalInicial: (config && config.capitalDeclarado) || null
    });
    localStorage.setItem(LS_MIGRADO, 'done');
    return operacion;
  }

  // Sprint V1.0.5 — limpia el capital inicial declarado de una operación
  // puntual (usado por "Reiniciar Liga demostrativa"). No cambia nada
  // más de su metadato (nombre, fecha, estado).
  function limpiarCapitalInicial(id) {
    const ops = leerOperaciones();
    if (!ops[id]) return null;
    ops[id].capitalInicial = null;
    guardarOperaciones(ops);
    return ops[id];
  }

  M11.Operaciones = {
    AVISO_CAPITAL,
    inicializar,
    crearDesdeConfiguracionInicial,
    crear,
    activar,
    pausar,
    finalizar,
    reabrir,
    listar,
    obtener,
    getActiva,
    getActivaId,
    limpiarCapitalInicial
  };

})(window.M11);
