/* =========================================================
   M11 · liga-ui.js  (Sprint 019)
   -----------------------------------------------------------
   Renderizado de la sección "Liga y calendario" (Configuración ->
   Operación real) y de la pestaña Partidos. No decide nada del
   Modelo M11 — solo pinta lo que M11.LeagueService y M11.Calendario
   ya calcularon, y delega toda acción del usuario a los manejadores
   cableados en events.js (mismo patrón que libro-ui.js/evaluacion-ui.js).
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);

  const ETIQUETA_CONEXION = {
    CONECTADO: { texto: 'Conectado', clase: 'verde' },
    ACTUALIZANDO: { texto: 'Actualizando…', clase: 'gris' },
    INFORMACION_GUARDADA: { texto: 'Información guardada', clase: 'gris' },
    SIN_CONEXION: { texto: 'Sin conexión', clase: 'rojo' },
    SERVICIO_NO_DISPONIBLE: { texto: 'Servicio temporalmente no disponible', clase: 'rojo' },
    LIGA_SIN_CALENDARIO: { texto: 'Liga sin calendario disponible', clase: 'gris' }
  };

  const ETIQUETA_ESTADO_PARTIDO = {
    finalizado: 'Finalizado', cancelado: 'Cancelado', suspendido: 'Suspendido',
    descartado_simultaneidad: 'Descartado por simultaneidad'
  };

  function pintarPill(el, estadoConexion) {
    if (!el) return;
    const meta = ETIQUETA_CONEXION[estadoConexion] || ETIQUETA_CONEXION.INFORMACION_GUARDADA;
    el.textContent = meta.texto;
    el.className = 'pill ' + meta.clase;
  }

  function formatearFechaHora(p) {
    if (!p.fecha || !p.hora) return 'Sin fecha confirmada';
    // Sprint 020: zona horaria de Colombia explícita — ver sports-api.js.
    return M11.SportsApi.formatearFechaHora(new Date(`${p.fecha}T${p.hora}:00`).getTime());
  }

  function bannerResultadoDetectado(p) {
    if (p && p.resultadoContradictorio) {
      return `<p class="resultado-detectado resultado-contradictorio">⚠️ TheSportsDB envió datos contradictorios para este partido (marcador y estado no coinciden). Verifique manualmente antes de confirmar el resultado.</p>`;
    }
    if (!p || !p.resultadoSugerido) return '';
    const marcador = p.marcadorDetectado ? `${p.equipoLocal} ${p.marcadorDetectado.home}–${p.marcadorDetectado.away} ${p.equipoVisitante}` : `${p.equipoLocal} vs ${p.equipoVisitante}`;
    const texto = p.resultadoSugerido === 'empate' ? 'EMPATE' : 'NO EMPATE';
    return `<p class="resultado-detectado">⚽ TheSportsDB publicó este marcador: <strong>${marcador}</strong>. Esto corresponde a <strong>${texto}</strong>. Confirme el resultado antes de actualizar niveles y capital.</p>`;
  }

  function tarjetaPartido(p, opciones) {
    const esProximo = opciones && opciones.esProximo;
    const etiquetaEstado = p.estado !== 'programado' ? (ETIQUETA_ESTADO_PARTIDO[p.estado] || p.estado) : (esProximo ? 'Próximo partido M11' : 'Programado');
    const pillClase = (p.estado === 'programado' && esProximo) ? 'gris' : (p.estado === 'programado' ? '' : 'gris');
    const resultadoFinal = (p.estado === 'finalizado' && p.marcadorDetectado)
      ? `<div class="dist-row"><span>Resultado</span><span>${p.marcadorDetectado.home}–${p.marcadorDetectado.away}</span></div>` : '';
    const jornada = p.round ? `<div class="dist-row"><span>Jornada</span><span>${p.round}</span></div>` : '';
    return `<article class="partido-card ${esProximo ? 'partido-proximo' : ''}">
      <div class="partido-card-head"><strong>${p.equipoLocal} vs ${p.equipoVisitante}</strong><span class="pill ${pillClase}">${etiquetaEstado}</span></div>
      <div class="dist-row"><span>Fecha y hora</span><span>${formatearFechaHora(p)}</span></div>
      <div class="dist-row"><span>Torneo</span><span>${p.torneo}${p.numeroCronologico ? ' · Cron. ' + p.numeroCronologico : ''}</span></div>
      ${jornada}
      ${resultadoFinal}
      ${p.provider === 'manual' ? '<p class="legal-note">Cargado manualmente (carga de emergencia).</p>' : ''}
      ${bannerResultadoDetectado(p)}
    </article>`;
  }

  // ---- Pestaña Partidos ----------------------------------------------------
  function render() {
    const box = $('#partidosGrupos');
    if (!box) return;

    const liga = M11.LeagueService.getLigaActiva();
    const nombreEl = $('#partidosLigaNombre');
    const actualizacionEl = $('#partidosUltimaActualizacion');
    const pillEl = $('#partidosEstadoConexionPill');
    pintarPill(pillEl, M11.LeagueService.getEstadoConexion());

    if (nombreEl) nombreEl.textContent = liga ? liga.displayName : 'Sin liga configurada';
    if (actualizacionEl) {
      actualizacionEl.textContent = liga && liga.lastSyncAt
        ? 'Última actualización: ' + M11.SportsApi.formatearFechaHora(new Date(liga.lastSyncAt).getTime(), { weekday: undefined, day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })
        : 'Todavía no se ha sincronizado.';
    }

    const btnActualizar = $('#actualizarCalendarioBtn');
    if (btnActualizar) btnActualizar.disabled = !liga || M11.LeagueService.estaSincronizando();

    if (!liga) {
      box.innerHTML = `<div class="empty">Configure un campeonato desde el catálogo para consultar aquí su calendario oficial.</div>`;
      return;
    }

    const lista = M11.Calendario.listar();
    const proximo = M11.Calendario.proximoPartido();
    const sinFecha = lista.filter(p => !p.fecha || !p.hora);
    const programados = lista.filter(p => p.estado === 'programado' && p.fecha && p.hora)
      .sort((a, b) => new Date(`${a.fecha}T${a.hora}:00`) - new Date(`${b.fecha}T${b.hora}:00`));
    const recientes = lista.filter(p => p.estado !== 'programado' && p.fecha && p.hora)
      .sort((a, b) => new Date(`${b.fecha}T${b.hora}:00`) - new Date(`${a.fecha}T${a.hora}:00`))
      .slice(0, 15);

    const partidoProximo = programados.find(p => proximo && p.id === proximo.id) || null;
    const proximosEncuentros = programados.filter(p => !partidoProximo || p.id !== partidoProximo.id);

    let html = '';
    if (partidoProximo) {
      html += '<h3 class="grupo-titulo">Próximo partido</h3>' + tarjetaPartido(partidoProximo, { esProximo: true });
    }
    if (proximosEncuentros.length) {
      html += '<h3 class="grupo-titulo">Próximos encuentros</h3>' + proximosEncuentros.map(p => tarjetaPartido(p, {})).join('');
    }
    if (recientes.length) {
      html += '<h3 class="grupo-titulo">Resultados recientes</h3>' + recientes.map(p => tarjetaPartido(p, {})).join('');
    }
    if (sinFecha.length) {
      html += '<h3 class="grupo-titulo">Sin fecha confirmada</h3>' + sinFecha.map(p => tarjetaPartido(p, {})).join('');
    }
    if (!html) {
      html = `<div class="empty">"${liga.displayName}" todavía no tiene partidos publicados para esta temporada. El Asistente volverá a consultar automáticamente.</div>`;
    }
    box.innerHTML = html;

    const aviso = $('#partidosAvisoError');
    if (aviso) {
      const err = M11.LeagueService.getEstadoConexion();
      if (err === 'SIN_CONEXION' || err === 'SERVICIO_NO_DISPONIBLE') {
        aviso.classList.remove('hidden');
        aviso.textContent = 'No fue posible actualizar el calendario. El Asistente sigue mostrando la última información guardada correctamente. Los cálculos y registros M11 no se vieron afectados.';
      } else {
        aviso.classList.add('hidden');
      }
    }
  }

  // ---- Sección "Liga y calendario" en Configuración -------------------------
  let paisOptionsListas = false;
  function asegurarPaisOptions() {
    if (paisOptionsListas) return;
    const sel = $('#ligaPaisSelect');
    if (!sel) return;
    const otroOpt = sel.querySelector('option[value="__otro__"]');
    M11.LeagueService.PAISES_SUGERIDOS.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.valorApi;
      opt.textContent = p.label;
      sel.insertBefore(opt, otroOpt);
    });
    paisOptionsListas = true;
  }

  function renderConfiguracion() {
    asegurarPaisOptions();

    const liga = M11.LeagueService.getLigaActiva();
    const resumenBox = $('#ligaGuardadaResumen');
    const formBox = $('#ligaSeleccionForm');
    const cambiarBtn = $('#cambiarLigaBtn');
    if (!resumenBox || !formBox) return;

    if (liga) {
      formBox.classList.add('hidden');
      resumenBox.classList.remove('hidden');
      if (cambiarBtn) cambiarBtn.classList.remove('hidden');
      resumenBox.innerHTML = `
        <div class="dist-row"><span>País</span><span>${liga.country}</span></div>
        <div class="dist-row"><span>Liga</span><span>${liga.leagueName}</span></div>
        ${liga.season ? `<div class="dist-row"><span>Temporada</span><span>${liga.season}</span></div>` : ''}
        <div class="dist-row"><span>Nombre visible en M11</span><span>${liga.displayName}</span></div>`;
    } else {
      resumenBox.classList.add('hidden');
      formBox.classList.remove('hidden');
      if (cambiarBtn) cambiarBtn.classList.add('hidden');
    }

    pintarPill($('#ligaEstadoConexionPill'), M11.LeagueService.getEstadoConexion());
    const actualizacionEl = $('#ligaUltimaActualizacion');
    if (actualizacionEl) {
      actualizacionEl.textContent = liga && liga.lastSyncAt
        ? 'Última actualización: ' + M11.SportsApi.formatearFechaHora(new Date(liga.lastSyncAt).getTime(), { weekday: undefined, day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })
        : 'Sin sincronizar todavía.';
    }
    const aviso = $('#ligaAvisoError');
    if (aviso) {
      const err = M11.LeagueService.getEstadoConexion();
      if (err === 'SIN_CONEXION' || err === 'SERVICIO_NO_DISPONIBLE') {
        aviso.classList.remove('hidden');
        aviso.textContent = 'No fue posible actualizar el calendario. El Asistente seguirá utilizando la última información guardada correctamente. Los cálculos y registros M11 no fueron afectados.';
      } else {
        aviso.classList.add('hidden');
      }
    }
  }

  M11.LigaUI = {
    render,
    renderConfiguracion,
    formatearFechaHora
  };

})(window.M11);
