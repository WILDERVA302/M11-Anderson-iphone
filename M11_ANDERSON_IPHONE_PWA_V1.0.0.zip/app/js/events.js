/* =========================================================
   M11 · events.js
   -----------------------------------------------------------
   Cableado de la interfaz. Cada acción del usuario que cambia el
   estado pasa por M11.Transiciones (y, cuando corresponde,
   M11.Audit) y termina en M11.UI.render().
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const $ = s => document.querySelector(s);
  const $$ = s => document.querySelectorAll(s);

  function showPrivate(on) {
    if (on && M11.OnboardingUI && !M11.Store.getConfiguracionInicial()) {
      // Primer ingreso real: antes de mostrar el Centro de Operaciones,
      // completar la configuración guiada (sección 5). No es una pantalla
      // más del login — es un módulo aparte que solo aparece una vez.
      $('#publicModule').classList.add('hidden');
      $('#privateModule').classList.add('hidden');
      $('#onboardingModule').classList.remove('hidden');
      M11.OnboardingUI.init();
      return;
    }
    $('#onboardingModule') && $('#onboardingModule').classList.add('hidden');
    $('#publicModule').classList.toggle('hidden', on);
    $('#privateModule').classList.toggle('hidden', !on);
  }

  function matchLabel() {
    const p = M11.getPartidoActual();
    return p ? `${p.equipoLocal} vs ${p.equipoVisitante}` : 'Partido no disponible';
  }

  // Cola de estrategias que acaban de cerrar su secuencia en Nivel 11 y
  // esperan la decisión del operador (puede haber más de una a la vez:
  // General y la estrategia secundaria del partido podrían bloquearse
  // en el mismo resultado). El sistema nunca decide solo — solo informa
  // y espera a que el operador elija.
  let colaSecuenciasFinalizadas = [];

  function mostrarSiguienteModalSecuencia() {
    M11.UI.mostrarModalSecuencia(colaSecuenciasFinalizadas[0] || null);
  }

  // Punto único para registrar un resultado (empate/no_empate/cancelado/
  // suspendido), sea desde el selector normal de EST-06 o desde los
  // botones del Centro de Pruebas M11. Detecta si alguna estrategia
  // cerró su secuencia en Nivel 11 y encola el diálogo correspondiente.
  function registrarResultadoYRevisarBloqueos(resultado) {
    const r = M11.Transiciones.registrarResultado(resultado);
    M11.Audit.registrarResultado({
      match: matchLabel(),
      resultado,
      detallePorEstrategia: r.detallePorEstrategia,
      huboApuestaVálida: r.huboApuestaVálida
    });
    M11.UI.registrarResultadoUI(resultado, r.detallePorEstrategia);
    Object.keys(r.detallePorEstrategia).forEach(nombre => {
      if (r.detallePorEstrategia[nombre].secuenciaFinalizada) colaSecuenciasFinalizadas.push(nombre);
    });
    if (colaSecuenciasFinalizadas.length) mostrarSiguienteModalSecuencia();
    M11.UI.render();
    M11.UI.enfocarCentroDecisiones();
  }

  function pintarUsuarioActual() {
    const el = $('#usuarioActualNombre');
    if (!el || !M11.AuthLocal) return;
    const u = M11.AuthLocal.getUsuarioActual();
    el.textContent = u ? u.nombre : '';
  }

  // V2.2.2: el acceso se cablea antes que las migraciones y los módulos de
  // operación. Así, un registro antiguo defectuoso nunca puede dejar
  // congelados "Mostrar", "Entrar" o la recuperación de contraseña.
  let authInicializada = false;
  function initAuth() {
    if (authInicializada) return;
    authInicializada = true;

    $('#loginForm').addEventListener('submit', e => {
      e.preventDefault();
      const correo = $('#email').value.trim();
      const clave = $('#password').value;
      const r = M11.AuthLocal ? M11.AuthLocal.validar({ correo, clave }) : { ok: false };
      if (r.ok) {
        $('#loginError').classList.add('hidden');
        M11.AuthLocal.setUsuarioActual(r.usuario);
        if ($('#remember').checked) localStorage.setItem('m11Session', 'active');
        pintarUsuarioActual();
        showPrivate(true);
        document.dispatchEvent(new CustomEvent('m11:authenticated'));
        // El render operativo se difiere un turno. Así el botón de acceso
        // responde y la pantalla privada aparece antes de cualquier cálculo
        // de calendario o historial, incluso con operaciones muy extensas.
        setTimeout(() => {
          try { M11.UI.render(); } catch (error) { console.error('[M11] render posterior al acceso', error); }
        }, 0);
      } else {
        $('#loginError').classList.remove('hidden');
      }
    });

    $('#togglePasswordBtn').addEventListener('click', () => {
      const input = $('#password');
      const mostrando = input.type === 'text';
      input.type = mostrando ? 'password' : 'text';
      $('#togglePasswordBtn').textContent = mostrando ? 'Mostrar' : 'Ocultar';
    });
    $('#forgotPasswordLink').addEventListener('click', e => {
      e.preventDefault();
      $('#forgotPasswordMsg').classList.toggle('hidden');
    });
    $('#mostrarRegistroLink').addEventListener('click', e => {
      e.preventDefault();
      $('#loginForm').classList.add('hidden');
      $('#registroForm').classList.remove('hidden');
      $('#registroError').classList.add('hidden');
    });
    $('#mostrarLoginLink').addEventListener('click', e => {
      e.preventDefault();
      $('#registroForm').classList.add('hidden');
      $('#loginForm').classList.remove('hidden');
    });
    $('#toggleRegistroPasswordBtn').addEventListener('click', () => {
      const input = $('#registroClave');
      const mostrando = input.type === 'text';
      input.type = mostrando ? 'password' : 'text';
      $('#toggleRegistroPasswordBtn').textContent = mostrando ? 'Mostrar' : 'Ocultar';
    });

    const MENSAJE_ERROR_REGISTRO = {
      nombre: 'Escriba su nombre completo.', correo: 'Escriba un correo válido.',
      clave_corta: 'La contraseña debe tener al menos 6 caracteres.',
      correo_reservado: 'Ese correo está reservado para el acceso de demostración. Use otro.',
      correo_existente: 'Ya existe una cuenta local con ese correo. Inicie sesión en vez de crear una nueva.',
      clave_no_coincide: 'Las contraseñas no coinciden.'
    };
    $('#registroForm').addEventListener('submit', e => {
      e.preventDefault();
      const nombre = $('#registroNombre').value;
      const correo = $('#registroCorreo').value;
      const clave = $('#registroClave').value;
      const confirmar = $('#registroClaveConfirmar').value;
      const errBox = $('#registroError');
      if (clave !== confirmar) {
        errBox.textContent = MENSAJE_ERROR_REGISTRO.clave_no_coincide;
        errBox.classList.remove('hidden');
        return;
      }
      const r = M11.AuthLocal.registrar({ nombre, correo, clave });
      if (!r.ok) {
        errBox.textContent = MENSAJE_ERROR_REGISTRO[r.motivo] || 'No se pudo crear la cuenta. Revise los datos.';
        errBox.classList.remove('hidden');
        return;
      }
      errBox.classList.add('hidden');
      M11.AuthLocal.setUsuarioActual(r.usuario);
      localStorage.setItem('m11Session', 'active');
      pintarUsuarioActual();
      e.target.reset();
      $('#registroForm').classList.add('hidden');
      $('#loginForm').classList.remove('hidden');
      showPrivate(true);
    });

    $('#logoutBtn').addEventListener('click', () => {
      localStorage.removeItem('m11Session');
      if (M11.AuthLocal) M11.AuthLocal.cerrarSesion();
      pintarUsuarioActual();
      showPrivate(false);
    });
  }

  function init() {
    // Sprint V1.0.5, sección 3: el acceso ahora valida contra cuentas
    // locales reales (M11.AuthLocal) además del correo de demostración
    // fijo — sigue siendo local, no un backend, y nunca se revela cuál
    // de los dos campos falló.
    initAuth();

    // EF-006: el botón nunca ejecuta una apuesta; abre la URL configurada
    // por el usuario en un navegador controlado (sección 5, Sprint
    // V1.0.5): en Android usa el navegador integrado de Capacitor —así no
    // depende del botón físico/gestual de Android para volver—, y fuera
    // de Android sigue abriendo una pestaña nueva y segura como siempre.
    // Si no hay URL configurada, no falla en silencio: avisa con un
    // mensaje claro.
    $('#betHouseBtn').addEventListener('click', () => {
      const url = (localStorage.getItem('m11BetHouseUrl') || '').trim();
      if (!url) {
        const msg = 'No hay una casa de apuestas configurada. Agréguela en Configuración.';
        if (M11.Store.getAlertasVisuales()) {
          alert(msg);
          M11.UI.setAvisoConfirmacion('');
        } else {
          M11.UI.setAvisoConfirmacion(msg);
        }
      } else {
        // La confirmación se persiste ANTES de abrir el navegador. En
        // Android, Browser.open() puede poner en pausa el WebView en esa
        // misma instrucción; cualquier cambio hecho después podía no
        // ejecutarse y, al regresar, la app volvía a ofrecer la apuesta.
        // Este orden hace que "APOSTÉ / NO APOSTÉ" ya esté guardado y
        // visible aunque el proceso sea suspendido inmediatamente.
        const confirmacionAbierta = M11.Transiciones.irACasaDeApuestas();
        if (!confirmacionAbierta) {
          alert('Este partido ya no está disponible para iniciar una apuesta. La aplicación mostrará la siguiente oportunidad válida.');
          M11.UI.render();
          M11.UI.enfocarCentroDecisiones();
          return;
        }
        M11.UI.render();
        const instruccion = 'Cuando termine, pulse X o Volver para regresar al Asistente M11.';
        if (M11.Store.getAlertasVisuales()) alert(instruccion);
        M11.UI.setAvisoConfirmacion(M11.Store.getAlertasVisuales() ? '' : instruccion);
        if (M11.Android) {
          M11.Android.abrirCasaDeApuestas(url, () => {
            M11.UI.render();
            M11.UI.enfocarCentroDecisiones();
          });
        } else {
          window.open(url, '_blank', 'noopener,noreferrer');
        }
      }
    });

    // "Sí" solo MUESTRA el formulario (ver M11.UI.mostrarFormularioApuesta).
    // No cambia de estado ni guarda nada todavía — eso ocurre recién al
    // enviar el formulario, en #betForm 'submit' más abajo.
    $('#yesBtn').addEventListener('click', () => {
      const p=M11.getPartidoActual(),confirmacion=M11.Store.getPartidoEnConfirmacion();
      if(!p||!confirmacion||String(confirmacion.id)!==String(p.id)){alert('No existe una apuesta iniciada para confirmar.');M11.UI.render();return;}
      M11.UI.mostrarFormularioApuesta();
      M11.UI.render();
      M11.UI.enfocarCentroDecisiones();
    });

    $('#cancelBetBtn').addEventListener('click', () => {
      M11.UI.ocultarFormularioApuesta();
      M11.UI.render();
    });

    // "No" cierra la decisión de este partido: pasa a EST-05 (igual
    // que "Sí" tras guardar) y ya no vuelve a proponer la misma apuesta.
    // No pide el resultado de inmediato ni toca capital o niveles.
    $('#noBtn').addEventListener('click', () => {
      const partidoNoApostado = matchLabel();
      const estrategiasNoApostadas = M11.getEstrategiasParticipantesActual();
      M11.UI.ocultarFormularioApuesta();
      try { M11.Transiciones.declararNoApostada(); }
      catch(error) { alert(error.message); M11.UI.render(); return; }
      M11.Audit.registrarNoApostada({ match: partidoNoApostado, strategies: estrategiasNoApostadas });
      M11.UI.render();
      M11.UI.enfocarCentroDecisiones();
    });

    // Guarda la apuesta ANTES de tocar la interfaz: primero la
    // transición (que persiste en localStorage), luego el registro de
    // auditoría, y solo al final se oculta el formulario y se refresca
    // la pantalla.
    $('#betForm').addEventListener('submit', e => {
      e.preventDefault();
      const partido=M11.getPartidoActual();
      if(!partido){alert('No hay un partido seleccionado. Actualice el calendario antes de guardar.');return;}
      const montoApostado = Number($('#bfMontoApostado').value);
      const cuota = Number($('#bfCuota').value);
      const casaDeApuestas = $('#casaApuestasInput').value.trim() || null;
      const hora=M11.SportsApi.formatearFechaHora(new Date(partido.timestampUTC||`${partido.fecha}T${partido.hora}:00`).getTime());
      if(!confirm(`CONFIRMACIÓN DE APUESTA\n\nPartido: ${partido.equipoLocal} vs ${partido.equipoVisitante}\nHora: ${hora}\nMonto: $${Math.round(montoApostado).toLocaleString('es-CO')}\nCuota: ${cuota}\n\n¿Este es exactamente el partido que desea registrar?`))return;
      try{M11.Transiciones.confirmarApostada({ montoApostado, cuota, casaDeApuestas,partidoIdEsperado:partido.id });}
      catch(error){alert(error.message);return;}
      M11.Audit.registrarApuesta({ match: matchLabel(), operacion: M11.Store.getDecision() });
      M11.UI.ocultarFormularioApuesta();
      M11.UI.render();
      M11.UI.enfocarCentroDecisiones();
    });

    // EST-05 -> EST-06: salida manual segura cuando la fuente deportiva
    // todavía no publicó el resultado. Evita que la operación real quede
    // bloqueada y no sustituye la sincronización automática normal.
    const actualizarResultadoReal = async () => {
      const btn=$('#refreshRealResultBtn'),status=$('#realResultStatus');
      if(btn){btn.disabled=true;btn.textContent='CONSULTANDO RESULTADO…';}
      if(status)status.textContent='Consultando el resultado de esta operación real…';
      try{
        const out=M11.RealSync?await M11.RealSync.syncNow(true):{settled:0};
        const pendiente=M11.Store.getDecision();
        if(out&&out.settled){if(status)status.textContent='Resultado encontrado. Capital, niveles e historial quedaron actualizados.';}
        else if(pendiente&&pendiente.estado==='PENDIENTE_RESULTADO'){if(status)status.textContent='La fuente todavía no publicó un resultado final verificable. Puede reintentar o usar INGRESAR RESULTADO MANUAL.';}
        else if(status)status.textContent='La operación real ya no tiene un resultado pendiente.';
        if(M11.LabHub)M11.LabHub.render();
        M11.UI.render();
        return !!(out&&out.settled);
      }catch(_){
        if(status)status.textContent='No fue posible consultar la fuente ahora. La apuesta continúa guardada sin cambios; puede reintentar o ingresar el resultado manualmente.';
        return false;
      }finally{if(btn){btn.disabled=false;btn.textContent='ACTUALIZAR RESULTADO AHORA';}}
    };
    $('#refreshRealResultBtn').addEventListener('click', actualizarResultadoReal);

    $('#registerResultBtn').addEventListener('click', () => {
      const decision = M11.Store.getDecision();
      if (!decision) {
        if (!confirm('La aplicación quedó esperando un resultado, pero no existe una apuesta asociada.\n\nSe liberará la operación sin cambiar capital, niveles ni historial. ¿Desea continuar?')) return;
        M11.Transiciones.continuarDespuesDeFinalizado();
        M11.UI.render();
        M11.UI.enfocarCentroDecisiones();
        return;
      }
      if (decision && decision.estado === 'NO_APOSTADA') {
        // No tiene sentido pedir Empate/No empate/Cancelado/Suspendido
        // para un partido en el que el operador ya dijo que no participó.
        // Cierra directo, reutilizando el mismo registrarResultado ya
        // probado (con la estrategia vacía, no toca capital ni niveles).
        registrarResultadoYRevisarBloqueos(null);
        return;
      }
      // Este botón es exclusivamente manual. La consulta automática tiene
      // su propio control visible y no debe impedir que se abra el selector.
      const partido=M11.getPartidoActual(),inicio=partido?new Date(partido.timestampUTC||`${partido.fecha}T${partido.hora}:00`).getTime():NaN;
      if(Number.isFinite(inicio)&&Date.now()<inicio+105*60000){alert(`Todavía no puede registrar Empate o No empate.\n\nLa apuesta pendiente corresponde a ${partido.equipoLocal} vs ${partido.equipoVisitante}. Espere a que el partido haya finalizado.`);return;}
      M11.Transiciones.abrirCierre();
      M11.UI.render();
      M11.UI.enfocarCentroDecisiones();
    });

    // Botones de resultado dentro de EST-06 (delegado, porque no
    // existen todavía cuando arranca la página).
    $('#dc-resultado-selector').addEventListener('click', e => {
      const btn = e.target.closest('.resultado-btn');
      if (!btn) return;
      const etiqueta = ({ empate:'Empate', no_empate:'No empate', cancelado:'Cancelado', suspendido:'Suspendido' })[btn.dataset.resultado] || btn.dataset.resultado;
      const partido=M11.getPartidoActual(),inicio=partido?new Date(partido.timestampUTC||`${partido.fecha}T${partido.hora}:00`).getTime():NaN;
      if(['empate','no_empate'].includes(btn.dataset.resultado)&&Number.isFinite(inicio)&&Date.now()<inicio+105*60000){alert('El partido aún no ha alcanzado su hora estimada de finalización. No se aplicó ningún resultado.');return;}
      const nombre=partido?`${partido.equipoLocal} vs ${partido.equipoVisitante}`:'partido pendiente';
      if (!M11.Store.getCentroPruebas() && !confirm(`CONFIRMACIÓN DE RESULTADO\n\nPartido: ${nombre}\nResultado: ${etiqueta}\n\nEsto actualizará capital, niveles e historial únicamente para este partido. ¿Confirma?`)) return;
      registrarResultadoYRevisarBloqueos(btn.dataset.resultado);
    });

    // Botones dentro del banner de "Objetivo alcanzado" (sección 10):
    // se generan dinámicamente, por eso van delegados desde la tarjeta
    // contenedora, igual que los botones de resultado en EST-06.
    $('#objetivosRentabilidadCard').addEventListener('click', e => {
      if (e.target.closest('#continuarOperacionBtn')) {
        M11.UI.render(); // no cambia nada: solo confirma que sigue operando con la meta visible
      }
      if (e.target.closest('#finalizarOperacionBtn')) {
        if (!confirm('Esto da por finalizada la operación. El Libro de Operaciones conserva el historial completo, pero el Asistente dejará de mostrar la próxima acción operativa. ¿Confirma que quiere finalizar?')) return;
        M11.Store.finalizarOperacionPorOperador();
        M11.UI.render();
      }
    });

    $('#continueBtn').addEventListener('click', () => {
      M11.Transiciones.continuarDespuesDeFinalizado();
      M11.UI.render();
      M11.UI.enfocarCentroDecisiones();
    });

    // Diálogo de secuencia finalizada (Nivel 11): el sistema informa que
    // la estrategia quedó cerrada para este torneo; el operador solo
    // puede reconocerlo ("Entendido"). Nunca se cierra el modal solo.
    $('#modalFinalizarBtn').addEventListener('click', () => {
      const nombre = colaSecuenciasFinalizadas.shift();
      if (nombre) M11.Audit.registrarDecisionSecuencia({ estrategia: nombre, decision: 'finalizar' });
      mostrarSiguienteModalSecuencia();
      M11.UI.render();
    });
    // Sprint V1.0.5: se retiró por completo el botón "Iniciar una nueva
    // secuencia" (y su manejador) de este modal. Permitía recargar una
    // estrategia ya agotada en Nivel 11 dentro del MISMO torneo, tomando
    // el monto de "capital operativo disponible" — exactamente lo que la
    // regla "prohibición de recargar una estrategia agotada" prohíbe, y
    // que todos los encargos anteriores (incluido este) reafirman como
    // regla inalterable. La única acción posible ahora es "Entendido"
    // (ver más abajo): la estrategia queda cerrada para este torneo, sin
    // excepción ni camino alterno.

    // Partidos simultáneos (Sprint 006): el sistema nunca elige solo.
    // Habilita "Continuar" recién cuando el operador marcó una opción.
    $('#simultaneidadOpciones').addEventListener('change', e => {
      if (e.target.name === 'simultaneidadElegido') $('#simultaneidadContinuarBtn').disabled = false;
    });
    $('#simultaneidadContinuarBtn').addEventListener('click', () => {
      const elegido = document.querySelector('input[name="simultaneidadElegido"]:checked');
      if (!elegido) return;
      const cal = M11.calendarioActivo();
      const grupo = cal.grupoSimultaneoPendiente();
      if (!grupo) return;
      grupo.forEach(p => {
        if (p.id !== elegido.value) {
          cal.marcarEstado(p.id, 'descartado_simultaneidad');
          M11.Libro.registrarDescartadoPorSimultaneidad(p);
        }
      });
      M11.UI.render();
    });

    let confirmacionConfigTimeout = null;

    // ---- Casa de apuestas por país (Sprint V1.0.5, sección 4) -----------
    if (M11.CasasUI) {
      const paisSelect = $('#casaPaisSelect');
      const listaBox = $('#casaCatalogoLista');
      const otraWrap = $('#casaOtraWrap');
      const resumen = $('#casaSeleccionadaResumen');

      function pintarResumenCasa() {
        const nombre = localStorage.getItem('m11BetHouseNombre') || '';
        const url = localStorage.getItem('m11BetHouseUrl') || '';
        resumen.textContent = nombre ? `Casa elegida: ${nombre}${url ? ' (' + url + ')' : ''}` : 'Todavía no ha elegido una casa de apuestas.';
      }

      function elegirCasa(nombre, url) {
        $('#betHouseNombre').value = nombre || '';
        $('#betHouseUrl').value = url || '';
        localStorage.setItem('m11BetHouseNombre', nombre || '');
        localStorage.setItem('m11BetHouseUrl', url || '');
        pintarResumenCasa();
      }

      function renderCatalogoPais(pais) {
        const casas = M11.CasasUI.casasDePais(pais);
        otraWrap.classList.add('hidden');
        const nombreGuardado = localStorage.getItem('m11BetHouseNombre') || '';
        let html = casas.map(c => `<label class="inline"><input type="radio" name="casaElegida" value="${c.nombre}" data-url="${c.enlace || ''}" ${c.nombre === nombreGuardado ? 'checked' : ''}> ${c.nombre}</label>`).join('');
        html += `<label class="inline"><input type="radio" name="casaElegida" value="__otra__" ${nombreGuardado && !casas.some(c => c.nombre === nombreGuardado) ? 'checked' : ''}> Otra (escribir manualmente)</label>`;
        html += `<label class="inline"><input type="radio" name="casaElegida" value="__ninguna__" ${!nombreGuardado ? 'checked' : ''}> No deseo configurarla ahora</label>`;
        listaBox.innerHTML = html || '<p class="legal-note">Sin casas precargadas para este país todavía. Use "Otra" para escribirla manualmente.</p>';
        if (nombreGuardado && !casas.some(c => c.nombre === nombreGuardado)) otraWrap.classList.remove('hidden');
      }

      listaBox.addEventListener('change', e => {
        if (e.target.name !== 'casaElegida') return;
        const valor = e.target.value;
        if (valor === '__otra__') {
          otraWrap.classList.remove('hidden');
          elegirCasa($('#betHouseNombre').value.trim(), $('#betHouseUrl').value.trim());
        } else if (valor === '__ninguna__') {
          otraWrap.classList.add('hidden');
          elegirCasa('', '');
        } else {
          otraWrap.classList.add('hidden');
          elegirCasa(valor, e.target.dataset.url);
        }
      });

      paisSelect.addEventListener('change', () => {
        if (paisSelect.value) renderCatalogoPais(paisSelect.value);
        else { listaBox.innerHTML = ''; otraWrap.classList.add('hidden'); }
      });

      M11.CasasUI.cargarCatalogo().then(() => {
        const errorBox = $('#casaCatalogoError');
        if (M11.CasasUI.getEstado() === 'error') {
          // Requisito explícito: nunca dejar el selector vacío en
          // silencio. Se avisa con claridad y se habilita igual la
          // escritura manual, para que el operador no quede bloqueado.
          errorBox.classList.remove('hidden');
          paisSelect.disabled = true;
          otraWrap.classList.remove('hidden');
          pintarResumenCasa();
          return;
        }
        errorBox.classList.add('hidden');
        M11.CasasUI.paisesDisponibles().forEach(pais => {
          const opt = document.createElement('option');
          opt.value = pais; opt.textContent = pais;
          paisSelect.appendChild(opt);
        });
        // Si ya hay un país guardado de una sesión anterior, lo preselecciona.
        const paisGuardado = localStorage.getItem('m11BetHousePais');
        if (paisGuardado && M11.CasasUI.paisesDisponibles().includes(paisGuardado)) {
          paisSelect.value = paisGuardado;
          renderCatalogoPais(paisGuardado);
        }
        pintarResumenCasa();
      });
      paisSelect.addEventListener('change', () => { if (paisSelect.value) localStorage.setItem('m11BetHousePais', paisSelect.value); });
    }

    $('#saveConfigBtn').addEventListener('click', () => {
      const up = Number($('#umbralProximoInput').value);
      const ua = Number($('#umbralApostarInput').value);
      if (Number.isFinite(up) && up > 0) M11.Store.setUmbralProximoMin(up);
      if (Number.isFinite(ua) && ua >= 0) M11.Store.setUmbralApostarMin(ua);
      M11.Store.setAlertasVisuales($('#alertasVisualesCheckbox').checked);
      localStorage.setItem('m11BetHouseNombre', $('#betHouseNombre').value.trim());
      localStorage.setItem('m11BetHouseUrl', $('#betHouseUrl').value.trim());

      const msg = $('#configSavedMsg');
      msg.classList.remove('hidden');
      clearTimeout(confirmacionConfigTimeout);
      confirmacionConfigTimeout = setTimeout(() => msg.classList.add('hidden'), 3000);
      M11.UI.render();
    });

    $('#clearHistory').addEventListener('click', () => {
      if (!confirm('Esto borra el historial de auditoría de esta demostración de forma permanente. No afecta el Libro de Operaciones ni las estrategias. ¿Confirma que quiere borrarlo?')) return;
      M11.Audit.limpiar();
      M11.UI.render();
    });

    $('#resetDemoBtn').addEventListener('click', () => {
      if (!confirm('Esto reinicia estrategias, capital y calendario a su punto de partida de demostración. ¿Continuar?')) return;
      M11.Transiciones.reiniciarDemostracion();
      M11.UI.render();
    });

    // Centro de Pruebas M11: efecto inmediato, no depende de "Guardar
    // cambios" — es un interruptor de uso, no una preferencia a confirmar.
    // Al activarlo, se explica qué son estos controles (para no confundir
    // demostración con funcionamiento normal), salvo que el operador ya
    // haya pedido no volver a verlo. No cambia ningún comportamiento del
    // panel — es solo una ayuda.
    $('#centroPruebasCheckbox').addEventListener('change', e => {
      M11.Store.setCentroPruebas(e.target.checked);
      if (e.target.checked && !M11.Store.getCentroPruebasAyudaOcultar()) {
        $('#modalAyudaCentroPruebas').classList.remove('hidden');
      }
      M11.UI.render();
    });
    $('#ayudaCentroPruebasCerrarBtn').addEventListener('click', () => {
      if ($('#ayudaCentroPruebasNoMostrar').checked) M11.Store.setCentroPruebasAyudaOcultar(true);
      $('#modalAyudaCentroPruebas').classList.add('hidden');
    });

    $('#cpSiguienteEstadoBtn').addEventListener('click', () => {
      M11.Transiciones.centroPruebasSiguienteEstado();
      M11.UI.render();
    });
    $('#cpSiguientePartidoBtn').addEventListener('click', () => {
      M11.Transiciones.centroPruebasSiguientePartido();
      M11.UI.render();
    });
    $('#cpEmpateBtn').addEventListener('click', () => registrarResultadoYRevisarBloqueos('empate'));
    $('#cpNoEmpateBtn').addEventListener('click', () => registrarResultadoYRevisarBloqueos('no_empate'));
    $('#cpCanceladoBtn').addEventListener('click', () => registrarResultadoYRevisarBloqueos('cancelado'));
    $('#cpReiniciarTorneoBtn').addEventListener('click', () => {
      if (!confirm('Esto reinicia partidos, cronología, historial y las tres estrategias a Nivel 1 con $2.047.000 cada una. ¿Continuar?')) return;
      M11.Transiciones.reiniciarTorneoDemo();
      M11.UI.render();
    });

    // Minimizar / cerrar / reabrir: el panel nunca debe quedar atrapando
    // al operador. Cerrar NO apaga el Centro de Pruebas M11 (sigue
    // activado), solo esconde el panel; queda un botón flotante y una
    // opción en Configuración para volver a mostrarlo.
    $('#cpMinimizarBtn').addEventListener('click', () => {
      M11.Store.setCentroPruebasMinimizado(true);
      M11.UI.render();
    });
    $('#centroPruebasMinimizadoBar').addEventListener('click', () => {
      M11.Store.setCentroPruebasMinimizado(false);
      M11.UI.render();
    });
    $('#cpCerrarBtn').addEventListener('click', () => {
      M11.Store.setCentroPruebasOculto(true);
      M11.Store.setCentroPruebasMinimizado(false);
      M11.UI.render();
    });
    $('#centroPruebasReabrirBtn').addEventListener('click', () => {
      M11.Store.setCentroPruebasOculto(false);
      M11.UI.render();
    });
    $('#mostrarCentroPruebasBtn').addEventListener('click', () => {
      M11.Store.setCentroPruebas(true);
      M11.Store.setCentroPruebasOculto(false);
      M11.Store.setCentroPruebasMinimizado(false);
      M11.UI.render();
    });

    // Panel arrastrable: para que nunca tape el Centro de Decisiones. Se
    // avisa a ui.js mientras se arrastra para que el redibujado
    // periódico (cada segundo) no pise la posición en curso — el mismo
    // problema que ya se corrigió con el formulario de apuesta.
    (function habilitarArrastrePanel() {
      const panel = $('#centroPruebasPanel');
      const handle = $('#cpDragHandle');
      let offsetX = 0, offsetY = 0, activo = false;

      function iniciar(x, y) {
        const rect = panel.getBoundingClientRect();
        offsetX = x - rect.left;
        offsetY = y - rect.top;
        panel.style.left = rect.left + 'px';
        panel.style.top = rect.top + 'px';
        activo = true;
        M11.UI.setArrastrandoCentroPruebas(true);
      }
      function mover(x, y) {
        if (!activo) return;
        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        const left = Math.max(0, Math.min(x - offsetX, Math.max(0, maxX)));
        const top = Math.max(0, Math.min(y - offsetY, Math.max(0, maxY)));
        panel.style.left = left + 'px';
        panel.style.top = top + 'px';
      }
      function terminar() {
        if (!activo) return;
        activo = false;
        M11.UI.setArrastrandoCentroPruebas(false);
        M11.Store.setCentroPruebasPosicion({ left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) });
      }

      handle.addEventListener('mousedown', e => { iniciar(e.clientX, e.clientY); e.preventDefault(); });
      window.addEventListener('mousemove', e => mover(e.clientX, e.clientY));
      window.addEventListener('mouseup', terminar);

      handle.addEventListener('touchstart', e => { const t = e.touches[0]; iniciar(t.clientX, t.clientY); }, { passive: true });
      window.addEventListener('touchmove', e => { if (!activo) return; const t = e.touches[0]; mover(t.clientX, t.clientY); }, { passive: true });
      window.addEventListener('touchend', terminar);
    })();

    // Modo de demostración: mismo mecanismo que las transiciones
    // normales (ver M11.Transiciones.irAEstadoDemo), así que después
    // de saltar a un estado los botones normales siguen funcionando.
    $('#demoModeSelect').addEventListener('change', e => {
      M11.Transiciones.irAEstadoDemo(e.target.value);
      M11.UI.render();
    });

    // ---- Apariencia: tema claro/oscuro/automático (Sprint 020) --------
    function pintarSelectorTema() {
      if (!M11.Theme) return;
      const actual = M11.Theme.getPreferencia();
      $$('.tema-btn').forEach(btn => btn.classList.toggle('activo', btn.dataset.temaValor === actual));
    }
    $$('.tema-btn').forEach(btn => btn.addEventListener('click', () => {
      M11.Theme.set(btn.dataset.temaValor);
      pintarSelectorTema();
    }));
    pintarSelectorTema();

    // ---- Sonidos y alertas (Sprint 021) --------------------------------
    // Desbloqueo por gesto (sección 6.4): Android/los navegadores no dejan
    // reproducir audio sin una interacción real primero. Se engancha en el
    // primer toque de TODA la aplicación (no solo en Configuración), para
    // que las alertas ya funcionen aunque el operador nunca abra esa
    // pantalla — "Recordar sesión" hace que el primer toque real sea
    // cualquier botón del Centro de Operaciones, no necesariamente el
    // formulario de acceso.
    if (M11.Sonidos) {
      const desbloquearUnaVez = () => {
        M11.Sonidos.desbloquearConGesto();
        document.removeEventListener('pointerdown', desbloquearUnaVez);
        document.removeEventListener('keydown', desbloquearUnaVez);
      };
      document.addEventListener('pointerdown', desbloquearUnaVez, { once: true });
      document.addEventListener('keydown', desbloquearUnaVez, { once: true });

      function pintarSonidos() {
        const pref = M11.Sonidos.getPreferencias();
        $('#sonidosActivadosCheckbox').checked = pref.activado;
        $('#sonidosVolumenRange').value = Math.round(pref.volumen * 100);
      }
      $('#sonidosActivadosCheckbox').addEventListener('change', e => {
        M11.Sonidos.setActivado(e.target.checked);
      });
      $('#sonidosVolumenRange').addEventListener('input', e => {
        M11.Sonidos.setVolumen(Number(e.target.value) / 100);
      });
      $('#probarSonidoBtn').addEventListener('click', () => {
        M11.Sonidos.probar();
      });
      pintarSonidos();
    }

    // Alarmas nativas de la APK: permisos y preferencias independientes del
    // tono interno de la aplicación.
    if (M11.Notifications) {
      const p=M11.Notifications.prefs();
      $('#notificacionesActivadasCheckbox').checked=p.enabled;
      $('#notificacion15Checkbox').checked=p.at15;
      $('#notificacion5Checkbox').checked=p.at5;
      $('#notificacionVibracionCheckbox').checked=p.vibration;
      const actualizarControlesAlarmas=()=>{const on=$('#notificacionesActivadasCheckbox').checked;['notificacion15Checkbox','notificacion5Checkbox','notificacionVibracionCheckbox'].forEach(id=>{$('#'+id).disabled=!on;});};
      actualizarControlesAlarmas();
      const mostrarEstadoAlarmas=async(prefijo)=>{const out=await M11.Notifications.sync();const planes=out&&out.plans||[];const plan=planes.slice().sort((a,b)=>a.at-b.at)[0];const detalle=plan?` Próximo aviso real: ${new Date(plan.at).toLocaleString('es-CO')}.`:'';let texto;if(out&&out.permission==='disabled')texto='Alarmas de partidos desactivadas. No quedará ningún aviso programado.';else if(out&&out.permission==='granted')texto=`${out.scheduled} alarma(s) programada(s) para operación real.${detalle}`;else texto='Android no autorizó las notificaciones; habilítelas desde Ajustes de la aplicación.';$('#notificacionesEstado').textContent=((prefijo||'')+' '+texto).trim();};
      const guardarAlarmas=()=>{actualizarControlesAlarmas();M11.Notifications.save({enabled:$('#notificacionesActivadasCheckbox').checked,at15:$('#notificacion15Checkbox').checked,at5:$('#notificacion5Checkbox').checked,vibration:$('#notificacionVibracionCheckbox').checked});mostrarEstadoAlarmas('Configuración guardada.').catch(()=>{});};
      ['notificacionesActivadasCheckbox','notificacion15Checkbox','notificacion5Checkbox','notificacionVibracionCheckbox'].forEach(id=>$('#'+id).addEventListener('change',guardarAlarmas));
      $('#activarNotificacionesBtn').addEventListener('click',async()=>{const state=await M11.Notifications.enableFromUser();if(state==='granted')await mostrarEstadoAlarmas('Notificaciones autorizadas.');else $('#notificacionesEstado').textContent='Android no autorizó las notificaciones; habilítelas desde Ajustes de la aplicación.';});
      $('#probarNotificacionBtn').addEventListener('click',async()=>{try{await M11.Notifications.test();$('#notificacionesEstado').textContent='Alarma de prueba enviada.';}catch(error){$('#notificacionesEstado').textContent=error.message;}});
      mostrarEstadoAlarmas().catch(()=>{$('#notificacionesEstado').textContent='No fue posible comprobar las alarmas.';});
    }

    // ---- Operaciones (torneos) — Sprint V1.0.5 -------------------------
    // Ningún manejador de aquí decide reglas del Modelo M11: todos llaman
    // a una función de M11.Operaciones ya existente y vuelven a pintar.
    if (M11.Operaciones && M11.OperacionesUI) {
      $('#operacionPausarBtn').addEventListener('click', () => {
        const op = M11.Operaciones.getActiva();
        if (op) M11.Operaciones.pausar(op.id);
        M11.OperacionesUI.render();
      });
      $('#operacionFinalizarBtn').addEventListener('click', () => {
        const op = M11.Operaciones.getActiva();
        if (!op) return;
        if (!confirm(`Esto finaliza "${op.nombre}". Quedará disponible en modo consulta; no admitirá apuestas nuevas hasta una reapertura explícita. El historial y el diagnóstico se conservan completos. ¿Confirma que quiere finalizarla?`)) return;
        M11.Operaciones.finalizar(op.id);
        M11.UI.render();
        M11.OperacionesUI.render();
      });
      $('#operacionNuevaMostrarBtn').addEventListener('click', () => {
        const form = $('#operacionNuevaForm');
        form.classList.toggle('hidden');
        const aviso = $('#operacionAvisoCapital');
        if (!form.classList.contains('hidden') && M11.Operaciones.AVISO_CAPITAL) {
          aviso.textContent = M11.Operaciones.AVISO_CAPITAL;
          aviso.classList.remove('hidden');
        }
      });
      $('#operacionCrearConfirmarBtn').addEventListener('click', () => {
        const nombre = $('#operacionNuevaNombre').value.trim();
        if (!nombre) { alert('Escriba un nombre para el torneo (por ejemplo, "Liga Colombiana").'); return; }
        const capitalTxt = $('#operacionNuevaCapital').value;
        const baseTxt = $('#operacionNuevaBase').value;
        M11.Operaciones.crear({
          nombre,
          capitalInicial: capitalTxt ? Number(capitalTxt) : null,
          base: baseTxt ? Number(baseTxt) : undefined
        });
        $('#operacionNuevaNombre').value = '';
        $('#operacionNuevaCapital').value = '';
        $('#operacionNuevaBase').value = '';
        $('#operacionNuevaForm').classList.add('hidden');
        M11.Store.limpiarDecision();
        M11.UI.render();
        M11.OperacionesUI.render();
      });
      // Delegación: los botones "Cambiar a esta"/"Reabrir" se generan
      // dinámicamente (una tarjeta por operación), así que se escucha en
      // el contenedor en vez de engancharse a cada botón por separado.
      $('#operacionesListaActivas').addEventListener('click', e => {
        const btnCambiar = e.target.closest('.operacion-cambiar-btn');
        if (btnCambiar) {
          M11.Operaciones.activar(btnCambiar.dataset.opId);
          M11.UI.render();
          M11.OperacionesUI.render();
          return;
        }
        // Sprint V1.0.5: "Reiniciar Liga demostrativa" (o el nombre que
        // tenga la operación migrada). Solo existe este botón para
        // operaciones con migrada:true — nunca para una operación real
        // genuina (ver operaciones-ui.js). Se verifica de nuevo acá antes
        // de llamar a M11.Transiciones.reiniciarOperacionMigrada, que a su
        // vez lo vuelve a verificar por tercera vez — ninguna operación
        // real puede reiniciarse por error con este botón.
        const btnReiniciar = e.target.closest('.operacion-reiniciar-migrada-btn');
        if (btnReiniciar) {
          const id = btnReiniciar.dataset.opId;
          const op = M11.Operaciones.obtener(id);
          if (!op || !op.migrada) return;
          const esLaActiva = id === M11.Operaciones.getActivaId();
          if (!confirm(`¿Reiniciar "${op.nombre}"? Esto borra su historial, niveles, apuesta pendiente y capital inicial declarado — únicamente de esta operación. Ninguna otra operación (real o no) se ve afectada. Después de reiniciar, General e Impares vuelven a Nivel 1 ($1.000 + $1.000 = $2.000). Esta acción no se puede deshacer.`)) return;
          M11.Transiciones.reiniciarOperacionMigrada(id);
          if (esLaActiva) M11.UI.render();
          M11.OperacionesUI.render();
        }
      });
      $('#operacionesListaFinalizadas').addEventListener('click', e => {
        const btn = e.target.closest('.operacion-reabrir-btn');
        if (!btn) return;
        const op = M11.Operaciones.obtener(btn.dataset.opId);
        if (!op) return;
        if (!confirm(`¿Reabrir "${op.nombre}"? Quedará pausada, lista para activarla cuando quiera seguir operando. Ninguna estrategia que haya quedado agotada en Nivel 11 se reactiva.`)) return;
        M11.Operaciones.reabrir(op.id);
        M11.OperacionesUI.render();
      });
    }

    // ---- Liga y calendario (Sprint 019) ------------------------------
    // Capa exclusivamente informativa: ningún manejador de aquí llama a
    // M11.Transiciones.confirmarApostada ni a registrarResultado. Solo
    // eligen la liga y sincronizan M11.Calendario (Operación real) con
    // TheSportsDB.
    let ligaElegida = null; // { id, name, alternateName, country } de la liga resaltada, sin guardar todavía

    function paisApiActual() {
      const sel = $('#ligaPaisSelect');
      if (!sel) return '';
      return sel.value === '__otro__' ? $('#ligaPaisOtroInput').value.trim() : sel.value;
    }

    async function buscarLigasParaPaisActual() {
      const pais = paisApiActual();
      const selLiga = $('#ligaSelect');
      const estadoBusqueda = $('#ligaEstadoBusqueda');
      ligaElegida = null;
      $('#ligaTemporadaWrap').classList.add('hidden');
      $('#ligaNombreVisibleWrap').classList.add('hidden');
      $('#guardarLigaBtn').disabled = true;
      if (!pais) {
        selLiga.innerHTML = '<option value="">Elija primero un país…</option>';
        selLiga.disabled = true;
        estadoBusqueda.classList.add('hidden');
        return;
      }
      selLiga.disabled = true;
      selLiga.innerHTML = '<option value="">Consultando ligas…</option>';
      estadoBusqueda.textContent = 'Consultando ligas…';
      estadoBusqueda.classList.remove('hidden');
      try {
        let ligas = await M11.LeagueService.buscarLigas(pais);
        // Sprint V1.0.5, sección 11: si el operador ya había elegido una
        // liga de este país antes (liga activa u operaciones guardadas),
        // esa opción sube al principio — es la que probablemente busca
        // de nuevo.
        const previas = new Set();
        const ligaActivaPrevia = M11.LeagueService.getLigaActiva();
        if (ligaActivaPrevia && ligaActivaPrevia.country === pais) previas.add(String(ligaActivaPrevia.leagueId));
        if (M11.Operaciones) {
          M11.Operaciones.listar().forEach(op => { if (op.leagueId) previas.add(String(op.leagueId)); });
        }
        if (previas.size) {
          ligas = ligas.slice().sort((a, b) => Number(previas.has(String(b.id))) - Number(previas.has(String(a.id))));
        }
        if (!ligas.length) {
          selLiga.innerHTML = '<option value="">Sin ligas de fútbol encontradas</option>';
          selLiga.disabled = true;
          estadoBusqueda.textContent = 'No se encontraron ligas de fútbol para ese país en TheSportsDB. Verifique el nombre (en inglés) o pruebe con otro país.';
          return;
        }
        selLiga.innerHTML = '<option value="">Seleccione una liga…</option>' +
          ligas.map(l => `<option value="${l.id}">${l.name}${l.alternateName ? ' (' + l.alternateName + ')' : ''}</option>`).join('');
        selLiga.dataset.ligas = JSON.stringify(ligas);
        selLiga.disabled = false;
        estadoBusqueda.classList.add('hidden');
      } catch (err) {
        selLiga.innerHTML = '<option value="">No fue posible consultar TheSportsDB</option>';
        selLiga.disabled = true;
        estadoBusqueda.textContent = 'No fue posible consultar TheSportsDB en este momento. Verifique su conexión e intente de nuevo.';
      }
    }

    $('#ligaPaisSelect').addEventListener('change', () => {
      const esOtro = $('#ligaPaisSelect').value === '__otro__';
      $('#ligaPaisOtroWrap').classList.toggle('hidden', !esOtro);
      if (!esOtro) buscarLigasParaPaisActual();
      else {
        $('#ligaSelect').innerHTML = '<option value="">Escriba el país y pulse Buscar…</option>';
        $('#ligaSelect').disabled = true;
      }
    });
    $('#ligaPaisOtroBuscarBtn').addEventListener('click', buscarLigasParaPaisActual);

    $('#ligaSelect').addEventListener('change', async () => {
      const sel = $('#ligaSelect');
      $('#guardarLigaBtn').disabled = true;
      $('#ligaTemporadaWrap').classList.add('hidden');
      $('#ligaNombreVisibleWrap').classList.add('hidden');
      if (!sel.value) { ligaElegida = null; return; }
      const ligas = JSON.parse(sel.dataset.ligas || '[]');
      ligaElegida = ligas.find(l => String(l.id) === String(sel.value)) || null;
      if (!ligaElegida) return;
      $('#ligaNombreVisibleWrap').classList.remove('hidden');
      $('#ligaNombreVisibleInput').value = ligaElegida.name;
      $('#guardarLigaBtn').disabled = false;
      try {
        const temporadas = await M11.LeagueService.detectarTemporadas(ligaElegida.id);
        if (temporadas.length) {
          $('#ligaTemporadaSelect').innerHTML = temporadas.map(t => `<option value="${t}">${t}</option>`).join('');
          $('#ligaTemporadaWrap').classList.remove('hidden');
          $('#ligaNombreVisibleInput').value = `${ligaElegida.name} ${temporadas[temporadas.length - 1]}`;
        }
      } catch (err) { /* la temporada no es obligatoria: se deja en blanco */ }
    });

    $('#guardarLigaBtn').addEventListener('click', async () => {
      if (!ligaElegida) return;
      const btn = $('#guardarLigaBtn');
      btn.disabled = true;
      btn.textContent = 'Guardando y sincronizando…';
      const paisTexto = $('#ligaPaisSelect').selectedOptions[0] && $('#ligaPaisSelect').value !== '__otro__'
        ? $('#ligaPaisSelect').selectedOptions[0].textContent
        : paisApiActual();
      const temporadaSel = $('#ligaTemporadaWrap').classList.contains('hidden') ? '' : $('#ligaTemporadaSelect').value;
      await M11.LeagueService.guardarLigaYSincronizar({
        country: paisTexto,
        leagueId: ligaElegida.id,
        leagueName: ligaElegida.name,
        season: temporadaSel,
        displayName: $('#ligaNombreVisibleInput').value.trim() || ligaElegida.name
      });
      btn.textContent = 'GUARDAR LIGA Y CALENDARIO';
      ligaElegida = null;
      M11.UI.render();
    });

    function confirmarCambioLiga() {
      const decision = M11.Store.getDecision();
      if (decision && decision.estado === 'PENDIENTE_RESULTADO') {
        alert('Hay una operación pendiente de resultado para el partido actual. Regístrela (Empate / No empate / Cancelado / Suspendido) en el Centro de Decisiones antes de cambiar de liga.');
        return false;
      }
      if (!confirm('Esto deja de mostrar los partidos de la liga actual (el Libro de Operaciones conserva todo el historial ya registrado). ¿Confirma que quiere cambiar de liga?')) return false;
      M11.LeagueService.limpiarLigaActiva();
      M11.UI.render();
      return true;
    }
    $('#cambiarLigaBtn').addEventListener('click', confirmarCambioLiga);
    $('#cambiarLigaDesdePartidosBtn').addEventListener('click', () => {
      if (!confirmarCambioLiga()) return;
      const btnConfig = document.querySelector('.nav-btn[data-view="settingsView"]');
      if (btnConfig) btnConfig.click();
    });

    $('#actualizarCalendarioBtn').addEventListener('click', async () => {
      $('#actualizarCalendarioBtn').disabled = true;
      M11.UI.render();
      await M11.LeagueService.sincronizar({ forzar: true });
      M11.UI.render();
    });

    // Sprint V1.0.5, sección 8: cada pestaña debe abrir "desde arriba", no
    // donde haya quedado el scroll de la pestaña anterior. .view/.view.active
    // ya ocultan por completo la vista anterior (nunca se apilan una sobre
    // otra); lo que faltaba era resetear el desplazamiento al cambiar.
    $$('.nav-btn').forEach(btn => btn.addEventListener('click', () => {
      $$('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      $$('.view').forEach(v => v.classList.remove('active'));
      const vistaNueva = $('#' + btn.dataset.view);
      vistaNueva.classList.add('active');
      const shell=document.querySelector('.app-shell');
      if(shell)shell.dataset.activeView=btn.dataset.view;
      $$('.view').forEach(v=>v.setAttribute('aria-hidden',v===vistaNueva?'false':'true'));
      window.scrollTo(0, 0);
      vistaNueva.scrollTop = 0;
      const decisionCenter = $('#decisionCenter');
      if (decisionCenter) decisionCenter.scrollTop = 0;
      M11.UI.render();
      if (btn.dataset.view === 'libroView') { M11.LibroUI.render(); if (M11.EvaluacionUI) M11.EvaluacionUI.render(); }
      // Al entrar a Partidos o Configuración, se intenta refrescar el
      // calendario si la caché de 30 minutos ya venció (sección 16: nunca
      // se consulta la API en cada render, solo al abrir con caché vencida
      // o cuando el operador pulsa "Actualizar calendario" explícitamente).
      if (btn.dataset.view === 'matchesView' || btn.dataset.view === 'settingsView') {
        M11.LeagueService.sincronizarSiHaceFalta().then(() => M11.UI.render());
      }
    }));

    // --- Libro de Operaciones M11 -------------------------------------
    $('#libroVistaResumidaBtn').addEventListener('click', () => M11.LibroUI.setVista('resumida'));
    $('#libroVistaDetalladaBtn').addEventListener('click', () => M11.LibroUI.setVista('detallada'));
    $('#libroOrdenBtn').addEventListener('click', () => M11.LibroUI.toggleOrden());

    ['libroFiltroEstrategia', 'libroFiltroResultado', 'libroFiltroFinalizadas', 'libroFiltroFechaDesde', 'libroFiltroFechaHasta'].forEach(id => {
      $('#' + id).addEventListener('change', () => M11.LibroUI.render());
    });
    ['libroBusquedaEquipo', 'libroFiltroDesde', 'libroFiltroHasta'].forEach(id => {
      $('#' + id).addEventListener('input', () => M11.LibroUI.render());
    });
    $('#libroLimpiarFiltrosBtn').addEventListener('click', () => {
      $('#libroFiltroEstrategia').value = 'todos';
      $('#libroFiltroResultado').value = 'todos';
      $('#libroFiltroFinalizadas').checked = false;
      $('#libroBusquedaEquipo').value = '';
      $('#libroFiltroDesde').value = '';
      $('#libroFiltroHasta').value = '';
      $('#libroFiltroFechaDesde').value = '';
      $('#libroFiltroFechaHasta').value = '';
      M11.LibroUI.render();
    });

    // Filas de la vista resumida: pulsar una la expande/colapsa (delegado,
    // porque se reconstruyen en cada render).
    $('#libroContenido').addEventListener('click', e => {
      const fila = e.target.closest('.libro-fila');
      if (!fila) return;
      M11.LibroUI.toggleFila(Number(fila.dataset.numero));
    });

    // Imprimir respeta exactamente la vista y los filtros activos — no se
    // toca nada antes de imprimir (Sprint V1.0). Se conserva para PC
    // (sección 10: "en PC debe mantenerse impresión y descarga PDF").
    $('#libroImprimirBtn').addEventListener('click', () => {
      window.print();
    });

    // Sprint V1.0.5, sección 10 (prioritaria): en Android no se depende de
    // window.print() — se genera un PDF real y se guarda/comparte con las
    // capacidades de Capacitor. Fuera de Android, cae a la descarga
    // normal del navegador.
    if (M11.PdfShare) {
      $('#libroGuardarPdfBtn').addEventListener('click', async () => {
        const btn = $('#libroGuardarPdfBtn');
        const textoOriginal = btn.textContent;
        btn.disabled = true; btn.textContent = 'Generando…';
        try {
          const r = await M11.PdfShare.guardarPdf();
          alert(r.metodo === 'dispositivo' ? `PDF guardado en el dispositivo: ${r.archivo}` : `PDF descargado: ${r.archivo}`);
        } catch (err) {
          alert('No fue posible generar el PDF: ' + err.message);
        } finally {
          btn.disabled = false; btn.textContent = textoOriginal;
        }
      });
      $('#libroCompartirBtn').addEventListener('click', async () => {
        const btn = $('#libroCompartirBtn');
        const textoOriginal = btn.textContent;
        btn.disabled = true; btn.textContent = 'Preparando…';
        try {
          const r = await M11.PdfShare.compartirResumen();
          if (r.metodo === 'descarga') alert('Se descargó el PDF del resumen (no hay una hoja de compartir del sistema disponible aquí).');
        } catch (err) {
          alert('No fue posible compartir el resumen: ' + err.message);
        } finally {
          btn.disabled = false; btn.textContent = textoOriginal;
        }
      });
    }

    // Aviso de Evaluación de recorrido M11: se reconstruye dinámicamente,
    // así que el botón de cerrar se cablea por delegación.
    $('#avisoEvaluacion').addEventListener('click', e => {
      if (e.target.id !== 'avisoEvaluacionCerrarBtn') return;
      const bloque = Number($('#avisoEvaluacion').dataset.bloque);
      if (M11.Evaluacion) M11.Evaluacion.marcarAvisoMostrado(bloque);
      $('#avisoEvaluacion').classList.add('hidden');
    });

    if (M11.OnboardingUI) {
      M11.OnboardingUI.alTerminar = () => {
        if (M11.Operaciones) M11.Operaciones.crearDesdeConfiguracionInicial();
        $('#onboardingModule').classList.add('hidden');
        $('#publicModule').classList.add('hidden');
        $('#privateModule').classList.remove('hidden');
        M11.UI.render();
      };
    }

    pintarUsuarioActual();
    showPrivate(localStorage.getItem('m11Session') === 'active');
    M11.UI.render();

    // Si ya hay una liga configurada de una sesión anterior y la caché de
    // 30 minutos venció, se sincroniza una sola vez al abrir la app (no en
    // cada segundo) — sección 16 del encargo.
    if (M11.LeagueService) M11.LeagueService.sincronizarSiHaceFalta().then(() => M11.UI.render());

    // El render completo es costoso (calendario, libro e informes). Antes se
    // reconstruía cada segundo aun en el login y en pestañas ocultas, lo que
    // podía bloquear Android cuando una liga publicaba muchos encuentros a
    // la vez. Cinco segundos mantienen el contador útil sin saturar la UI;
    // además no se ejecuta mientras el módulo privado esté oculto.
    setInterval(() => {
      const privado = $('#privateModule');
      if (!privado || privado.classList.contains('hidden') || document.hidden) return;
      try { M11.UI.render(); } catch (error) { console.error('[M11] render periódico', error); }
    }, 5000);

    // Punto 3 del encargo: al volver de la casa de apuestas (pestaña
    // externa), el estado ya está persistido (no se asume nada nuevo:
    // solo se relee) pero la posición de scroll y el layout pueden haber
    // quedado desalineados. Se fuerza un render limpio y se lleva la
    // vista al comienzo del Centro de Decisiones, sin importar por cuál
    // de los tres eventos volvió el navegador.
    function alVolverAlAsistente() {
      if (document.visibilityState && document.visibilityState !== 'visible') return;
      M11.UI.render();
      window.scrollTo(0, 0);
      M11.UI.enfocarCentroDecisiones();
    }
    window.addEventListener('focus', alVolverAlAsistente);
    document.addEventListener('visibilitychange', alVolverAlAsistente);
    window.addEventListener('pageshow', alVolverAlAsistente);
  }

  M11.Events = { initAuth, init };

})(window.M11);
