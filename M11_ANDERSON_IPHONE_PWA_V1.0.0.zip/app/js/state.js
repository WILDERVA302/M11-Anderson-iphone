/* =========================================================
   M11 · state.js
   -----------------------------------------------------------
   Estado central del Centro de Operaciones: los 6 estados
   oficiales (EST-01..EST-06), su relación con el calendario de
   partidos (calendar.js) y el motor de reglas (m11-engine.js), y
   la persistencia local de todo eso.

   Nomenclatura: "EST-01".."EST-06" son los estados de esta máquina
   y son intencionalmente distintos de los requisitos funcionales
   "EF-001".."EF-015" de 03_ESPECIFICACION_FUNCIONAL.md.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  M11.ESTADOS = {
    LISTO: 'EST-01',
    PROXIMO: 'EST-02',
    APOSTAR: 'EST-03',
    ESPERANDO_CONFIRMACION: 'EST-04',
    ESPERANDO_RESULTADO: 'EST-05',
    FINALIZADO: 'EST-06'
  };

  M11.ESTADO_META = {
    'EST-01': { titulo: 'Todo está listo', desc: 'No hay una operación inmediata. El Asistente M11 está preparando el próximo partido.', color: 'ok' },
    'EST-02': { titulo: 'Próximo partido', desc: 'Todavía no es momento de apostar.', color: 'info' },
    'EST-03': { titulo: 'Es momento de apostar', desc: 'El Centro de Decisiones M11 tiene una recomendación lista.', color: 'attention' },
    'EST-04': { titulo: 'Confirmación', desc: '¿Realizó la apuesta?', color: 'info' },
    'EST-05': { titulo: 'Operación pendiente de resultado', desc: 'Quedó guardada. El Asistente consultará el marcador final y actualizará la operación automáticamente.', color: 'attention' },
    'EST-06': { titulo: 'Revisión excepcional', desc: 'La fuente entregó datos contradictorios; revise el resultado para cerrar el ciclo.', color: 'attention' }
  };

  // Variables configurables (no son reglas del Modelo M11, solo de
  // esta demostración: cuándo el motor por tiempo cambia de estado).
  M11.CONFIG = {
    UMBRAL_PROXIMO_MIN_DEFAULT: 90,
    UMBRAL_APOSTAR_MIN_DEFAULT: 15,
    // Conserva el partido visible y operable durante cinco minutos desde
    // el saque inicial. Evita que un retraso mínimo cambie silenciosamente
    // la recomendación al partido siguiente.
    GRACIA_APUESTA_EN_VIVO_MIN: 5,
    DEFAULT_ADELANTO_MIN: 100, // a cuántos minutos se reprograma el partido semilla
    // Punto de partida de una OPERACIÓN REAL nueva (Sprint V1.0.5):
    // Nivel 1 en las tres estrategias — General e Impares participan
    // en el partido cronológico 1 (Impares por la regla de paridad) y
    // recomiendan $1.000 cada una ($2.000 en total); Pares no
    // participa en ese primer partido, pero también arranca en Nivel
    // 1, lista para cuando le corresponda. Antes esta constante traía
    // niveles de demostración heredados (General 8, Pares 6), lo que
    // hacía que una operación real recién creada mostrara $129.000 en
    // vez de $2.000 — ese era el error a corregir.
    SEED_NIVELES_REAL: { general: 1, pares: 1, impares: 1 },
    // Punto de partida del CENTRO DE PRUEBAS (dato de ejemplo para que
    // la demostración no arranque en blanco): General en nivel 8
    // ($128.000) y Pares en nivel 6 ($32.000), tal como pidió el
    // Director en su momento. Vive en su propio almacenamiento (ver
    // crearAlmacenEstrategias más abajo) y nunca puede llegar a
    // afectar una operación real.
    SEED_NIVELES_DEMO: { general: 8, pares: 6, impares: 1 }
  };

  const LS_KEYS = {
    MODO: 'm11Modo',                       // 'auto' (por tiempo) | 'flujo' (fijado manualmente)
    ESTADO: 'm11EstadoActual',             // último EST-0X manual, aplica si modo = 'flujo'
    UMBRAL_PROXIMO: 'm11UmbralProximoMin',
    UMBRAL_APOSTAR: 'm11UmbralApostarMin',
    DECISION: 'm11DecisionPartido',        // JSON: {matchId, tipo, casaDeApuestas, estrategias} — Operación real
    DECISION_DEMO: 'm11DecisionPartidoDemo', // mismo formato, exclusivo del Centro de Pruebas
    ESTRATEGIAS: 'm11EstrategiasEngine',   // JSON: {general:{nivel,disponible,comprometido}, ...} — Operación real
    ESTRATEGIAS_DEMO: 'm11EstrategiasEngineDemo', // mismo formato, exclusivo del Centro de Pruebas
    ALERTAS_VISUALES: 'm11AlertasVisuales', // 'on' | 'off'
    CONFIRMACION_PARTIDO: 'm11PartidoEnConfirmacion'
  };

  function leerNumero(key, def) {
    const v = localStorage.getItem(key);
    const n = v !== null ? Number(v) : NaN;
    return Number.isFinite(n) ? n : def;
  }

  // Sprint V1.0.5 — separación real/demo de estrategias (capital y
  // niveles), con el mismo espíritu que ya existía para el calendario
  // (M11.Calendario vs M11.CalendarioDemo, Sprint 019): dos
  // almacenamientos completamente independientes, para que "Reiniciar
  // demostración" o cualquier ciclo del Centro de Pruebas nunca pueda
  // tocar el capital de una operación real, y viceversa.
  function crearAlmacenEstrategias(lsKey, semillaNiveles) {
    function estadoInicial() {
      const conNivel = (n) => { const e = M11.Engine.nuevoEstadoEstrategia(); e.nivel = n; return e; };
      return { general: conNivel(semillaNiveles.general), pares: conNivel(semillaNiveles.pares), impares: conNivel(semillaNiveles.impares) };
    }
    function cargar() {
      try {
        const raw = localStorage.getItem(lsKey);
        if (raw) return JSON.parse(raw);
      } catch (e) { /* datos corruptos: usar semilla */ }
      const semilla = estadoInicial();
      localStorage.setItem(lsKey, JSON.stringify(semilla));
      return semilla;
    }
    let estado = cargar();
    function persistir() { localStorage.setItem(lsKey, JSON.stringify(estado)); }
    return {
      get() { return estado; },
      set(nombre, nuevoEstado) { estado[nombre] = nuevoEstado; persistir(); },
      reiniciar() { estado = estadoInicial(); persistir(); }
    };
  }

  // Sprint V1.0.5 — cada OPERACIÓN (torneo) tiene su propio almacén de
  // estrategias, creado bajo demanda la primera vez que se usa y luego
  // reutilizado (caché en memoria) — así una operación con muchos
  // partidos no relee su propio localStorage en cada llamada. La
  // operación migrada desde la versión anterior a esta ('op-migrada-1')
  // sigue usando las claves clásicas de siempre (m11EstrategiasEngine,
  // m11DecisionPartido) para no copiar ni renombrar nada de lo que el
  // operador ya tenía guardado; cualquier operación nueva usa una clave
  // propia derivada de su id.
  function claveEstrategiasReal(operacionId) {
    if (!operacionId || operacionId === 'op-migrada-1') return LS_KEYS.ESTRATEGIAS;
    return LS_KEYS.ESTRATEGIAS + '__' + operacionId;
  }
  function claveDecisionReal(operacionId) {
    if (!operacionId || operacionId === 'op-migrada-1') return LS_KEYS.DECISION;
    return LS_KEYS.DECISION + '__' + operacionId;
  }
  function claveConfirmacionReal(operacionId) {
    return LS_KEYS.CONFIRMACION_PARTIDO + '__' + (operacionId || 'op-migrada-1');
  }

  const cacheAlmacenesEstrategiasReales = {};
  function almacenEstrategiasRealDe(operacionId) {
    const clave = claveEstrategiasReal(operacionId);
    if (!cacheAlmacenesEstrategiasReales[clave]) {
      cacheAlmacenesEstrategiasReales[clave] = crearAlmacenEstrategias(clave, M11.CONFIG.SEED_NIVELES_REAL);
    }
    return cacheAlmacenesEstrategiasReales[clave];
  }

  const almacenEstrategiasDemo = crearAlmacenEstrategias(LS_KEYS.ESTRATEGIAS_DEMO, M11.CONFIG.SEED_NIVELES_DEMO);

  // Único punto que decide cuál almacén de estrategias está activo: el
  // del Centro de Pruebas, o el de la operación (torneo) actualmente
  // activa. Coincide siempre con M11.calendarioActivo() en cuanto a
  // Centro de Pruebas vs Operación real — la separación por TORNEO
  // dentro de "Operación real" es exclusiva de las estrategias/decisión/
  // Libro (un calendario de partidos, en cambio, ya está atado a una
  // liga específica desde Sprint 019, así que no necesita este nivel
  // adicional).
  function almacenEstrategiasActivo() {
    if (M11.Store.getCentroPruebas()) return almacenEstrategiasDemo;
    const opId = M11.Operaciones ? M11.Operaciones.getActivaId() : null;
    return almacenEstrategiasRealDe(opId);
  }

  // Sprint V1.0.5 — misma separación real/demo que las estrategias
  // (arriba) y el calendario (calendar.js, Sprint 019), ahora para la
  // decisión pendiente ("¿apostó? ¿cuánto? ¿a qué le apostó?"). Sin
  // esto, una apuesta real pendiente de resultado podía perderse si el
  // operador activaba el Centro de Pruebas o pulsaba "Reiniciar
  // demostración" mientras esperaba ese resultado.
  function crearAlmacenDecision(lsKey) {
    let actual;
    try {
      const raw = localStorage.getItem(lsKey);
      actual = raw ? JSON.parse(raw) : null;
    } catch (e) { actual = null; }
    function persistir() {
      if (actual) localStorage.setItem(lsKey, JSON.stringify(actual));
      else localStorage.removeItem(lsKey);
    }
    return {
      get() { return actual; },
      set(d) { actual = d; persistir(); },
      limpiar() { actual = null; persistir(); }
    };
  }
  const cacheAlmacenesDecisionReales = {};
  function almacenDecisionRealDe(operacionId) {
    const clave = claveDecisionReal(operacionId);
    if (!cacheAlmacenesDecisionReales[clave]) {
      cacheAlmacenesDecisionReales[clave] = crearAlmacenDecision(clave);
    }
    return cacheAlmacenesDecisionReales[clave];
  }
  const almacenDecisionDemo = crearAlmacenDecision(LS_KEYS.DECISION_DEMO);
  function almacenDecisionActivo() {
    if (M11.Store.getCentroPruebas()) return almacenDecisionDemo;
    const opId = M11.Operaciones ? M11.Operaciones.getActivaId() : null;
    return almacenDecisionRealDe(opId);
  }

  const store = {
    modo: localStorage.getItem(LS_KEYS.MODO) || 'auto',
    estado: localStorage.getItem(LS_KEYS.ESTADO) || M11.ESTADOS.LISTO
  };

  M11.Store = {
    getModo() { return store.modo; },
    setModo(m) { store.modo = m; localStorage.setItem(LS_KEYS.MODO, m); },
    getEstadoManual() { return store.estado; },
    setEstadoManual(e) { store.estado = e; localStorage.setItem(LS_KEYS.ESTADO, e); },

    getUmbralProximoMin() { return leerNumero(LS_KEYS.UMBRAL_PROXIMO, M11.CONFIG.UMBRAL_PROXIMO_MIN_DEFAULT); },
    setUmbralProximoMin(n) { localStorage.setItem(LS_KEYS.UMBRAL_PROXIMO, String(n)); },
    getUmbralApostarMin() { return leerNumero(LS_KEYS.UMBRAL_APOSTAR, M11.CONFIG.UMBRAL_APOSTAR_MIN_DEFAULT); },
    setUmbralApostarMin(n) { localStorage.setItem(LS_KEYS.UMBRAL_APOSTAR, String(n)); },

    getEstrategias() { return almacenEstrategiasActivo().get(); },
    setEstrategia(nombre, nuevoEstado) { almacenEstrategiasActivo().set(nombre, nuevoEstado); },
    // Sustituye el estado de una operación concreta tanto en localStorage
    // como en la caché viva. Las reparaciones históricas no pueden limitarse
    // a escribir el disco: la pantalla y la liquidación usan esta memoria.
    setEstrategiasDeOperacion(operacionId, estados) {
      const almacen = almacenEstrategiasRealDe(operacionId);
      ['general', 'pares', 'impares'].forEach(nombre => {
        if (estados && estados[nombre]) almacen.set(nombre, { ...estados[nombre] });
      });
      return almacen.get();
    },
    reiniciarEstrategias() { almacenEstrategiasActivo().reiniciar(); },
    // Explícito, NUNCA enrutado por el interruptor del Centro de Pruebas:
    // "Reiniciar demostración" (Configuración → Modo de demostración) es
    // un botón que existe SIEMPRE, esté o no activo el Centro de Pruebas
    // — si reiniciarEstrategias() (la de arriba) se usara ahí, alguien
    // podría reiniciar el capital de una operación real con ese botón
    // mientras el interruptor está apagado. Ver M11.Transiciones.reiniciarDemostracion.
    reiniciarEstrategiasDemo() { almacenEstrategiasDemo.reiniciar(); },

    getDecision() { return almacenDecisionActivo().get(); },
    setDecision(d) { almacenDecisionActivo().set(d); },
    limpiarDecision() { almacenDecisionActivo().limpiar(); },
    getPartidoEnConfirmacion(operacionId) {
      const opId = operacionId || (M11.Operaciones ? M11.Operaciones.getActivaId() : null);
      try { return JSON.parse(localStorage.getItem(claveConfirmacionReal(opId)) || 'null'); }
      catch (_) { return null; }
    },
    setPartidoEnConfirmacion(p) {
      const opId = M11.Operaciones ? M11.Operaciones.getActivaId() : null;
      const key = claveConfirmacionReal(opId);
      if (p) localStorage.setItem(key, JSON.stringify({ ...p, operationId: opId || p.operationId || null }));
      else localStorage.removeItem(key);
    },
    limpiarPartidoEnConfirmacion() {
      const opId = M11.Operaciones ? M11.Operaciones.getActivaId() : null;
      localStorage.removeItem(claveConfirmacionReal(opId));
    },
    getDecisionDeOperacion(operacionId) { return almacenDecisionRealDe(operacionId).get(); },
    // Explícito, para "Reiniciar demostración" — ver la nota junto a
    // reiniciarEstrategiasDemo(), mismo motivo exacto.
    limpiarDecisionDemo() { almacenDecisionDemo.limpiar(); },

    getAlertasVisuales() { return (localStorage.getItem(LS_KEYS.ALERTAS_VISUALES) || 'on') === 'on'; },
    setAlertasVisuales(on) { localStorage.setItem(LS_KEYS.ALERTAS_VISUALES, on ? 'on' : 'off'); },

    // Centro de Pruebas M11: efecto inmediato (no pasa por "Guardar
    // cambios", es un interruptor de uso, no una preferencia a confirmar).
    // Sección 5 (Primer ingreso — configuración guiada). Se guarda una
    // sola vez y no se vuelve a mostrar el asistente salvo reinicio
    // autorizado. capitalDeclarado queda null si el operador no registró
    // más que el mínimo — así el Libro sigue derivando capitalInicial del
    // motor como siempre, sin un valor redundante que pueda desalinearse.
    getConfiguracionInicial() {
      const raw = localStorage.getItem('m11ConfiguracionInicial');
      return raw ? JSON.parse(raw) : null;
    },
    guardarConfiguracionInicial({ base, capitalDeclarado, pais, casaApuestas, torneo }) {
      localStorage.setItem('m11ConfiguracionInicial', JSON.stringify({
        base, capitalDeclarado: capitalDeclarado || null, pais: pais || null,
        casaApuestas: casaApuestas || null, torneo: torneo || 'Liga demostrativa',
        fecha: new Date().toISOString()
      }));
    },
    getCapitalInicialDeclarado() {
      const c = M11.Store.getConfiguracionInicial();
      return c && c.capitalDeclarado ? c.capitalDeclarado : null;
    },
    // Reinicio autorizado del asistente de bienvenida (Configuración ->
    // Datos de demostración). No toca historial ni estrategias por sí
    // solo — eso lo hace reiniciarTorneoDemo(), que el operador dispara
    // aparte con su propia confirmación.
    reiniciarConfiguracionInicial() { localStorage.removeItem('m11ConfiguracionInicial'); },

    getCentroPruebas() { return localStorage.getItem('m11CentroPruebas') === 'on'; },
    setCentroPruebas(on) { localStorage.setItem('m11CentroPruebas', on ? 'on' : 'off'); },

    // Sección 14 (Salud de la operación): el operador puede decidir dar
    // por finalizada la operación (por ejemplo, tras asegurar utilidades
    // en un objetivo alcanzado). Es una decisión explícita del operador,
    // no algo que el sistema infiera — por eso queda persistida aparte y
    // nunca se activa sola.
    getOperacionFinalizadaPorOperador() { return localStorage.getItem('m11OperacionFinalizada') === 'on'; },
    finalizarOperacionPorOperador() { localStorage.setItem('m11OperacionFinalizada', 'on'); },
    reanudarOperacion() { localStorage.removeItem('m11OperacionFinalizada'); },

    // Estado de presentación del panel (independiente de si está
    // activado): minimizado a barra, oculto por completo (pero sigue
    // activado), y la posición si el operador lo arrastró.
    getCentroPruebasMinimizado() { return localStorage.getItem('m11CentroPruebasMin') === 'on'; },
    setCentroPruebasMinimizado(on) { localStorage.setItem('m11CentroPruebasMin', on ? 'on' : 'off'); },
    getCentroPruebasOculto() { return localStorage.getItem('m11CentroPruebasOculto') === 'on'; },
    setCentroPruebasOculto(on) { localStorage.setItem('m11CentroPruebasOculto', on ? 'on' : 'off'); },
    getCentroPruebasPosicion() {
      try { return JSON.parse(localStorage.getItem('m11CentroPruebasPos')); }
      catch (e) { return null; }
    },
    setCentroPruebasPosicion(pos) { localStorage.setItem('m11CentroPruebasPos', JSON.stringify(pos)); },

    // Ayuda del Centro de Pruebas M11 (Sprint 007): se muestra cada vez
    // que se activa, salvo que el operador haya marcado "No volver a
    // mostrar este mensaje" — nunca cambia el comportamiento del panel,
    // solo evita confusión entre modo demostración y uso normal.
    getCentroPruebasAyudaOcultar() { return localStorage.getItem('m11CentroPruebasAyudaOcultar') === 'on'; },
    setCentroPruebasAyudaOcultar(on) { localStorage.setItem('m11CentroPruebasAyudaOcultar', on ? 'on' : 'off'); }
  };

  // ---- Calendario activo (Sprint 019) ------------------------------------
  // Único punto que decide, en TODO el Centro de Operaciones, si se está
  // trabajando con la Operación real (M11.Calendario: TheSportsDB + carga
  // manual de emergencia) o con el Centro de Pruebas M11 (M11.CalendarioDemo:
  // partidos ficticios). Nunca se mezclan. La pestaña Partidos, en cambio,
  // siempre muestra la Operación real (ver M11.LigaUI), sin importar este
  // interruptor — el Centro de Pruebas tiene su propio panel flotante.
  M11.calendarioActivo = function () {
    return M11.Store.getCentroPruebas() ? M11.CalendarioDemo : M11.Calendario;
  };

  M11.inicioPartidoMs = function (p) {
    return p ? new Date(p.timestampUTC || `${p.fecha}T${p.hora}:00`).getTime() : NaN;
  };

  // ---- Partido actual: el primer 'programado' del calendario activo -----
  // Se mantiene estable durante todo el ciclo EST-02..EST-06 porque su
  // estado no cambia a 'finalizado'/'cancelado'/'suspendido' hasta que
  // se registra el resultado en EST-06.
  M11.getPartidoActual = function () {
    // Si ya existe una decisión, se conserva su partido aunque haya empezado:
    // el operador todavía necesita registrar el resultado. Solo la búsqueda
    // de una NUEVA oportunidad excluye partidos cuya hora ya pasó.
    const decision = M11.Store.getDecision();
    if (decision && decision.partidoId) {
      const fijado = M11.calendarioActivo().obtener(decision.partidoId);
      if (fijado) return fijado;
      if (decision.partidoSnapshot) return { ...decision.partidoSnapshot };
    }
    // Al abrir la casa se fija el partido exacto hasta que el operador
    // confirme qué hizo. Esto no reabre una oportunidad vencida.
    const confirmacion = M11.Store.getPartidoEnConfirmacion();
    if (confirmacion && confirmacion.id) {
      const fijado = M11.calendarioActivo().obtener(confirmacion.id) || confirmacion;
      // Una versión anterior podía dejar esta confirmación abierta después
      // de que el partido ya hubiera sido archivado. En ese caso no se debe
      // devolver como oportunidad actual: se libera la confirmación y se
      // continúa inmediatamente con el siguiente partido. La validación
      // final contra duplicados se conserva en confirmarApostada().
      const yaArchivado = M11.Libro && M11.Libro.obtenerRegistroPartido
        ? M11.Libro.obtenerRegistroPartido(fijado)
        : null;
      if (!yaArchivado) return fijado;
      M11.Store.limpiarPartidoEnConfirmacion();
      M11.Store.setModo('auto');
    }
    const calendario = M11.calendarioActivo();
    const referencia = Date.now() - M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000;

    // Reparación de arranque para instalaciones que ya recibieron el fallo:
    // si el calendario local dejó cerrado un encuentro que todavía es futuro
    // y el único registro asociado es la omisión automática "sin acción",
    // se rehabilita sin esperar otra descarga del proveedor.
    if (M11.Libro && M11.Libro.repararSinAccionFutura) {
      calendario.listar().forEach(candidato => {
        if (candidato.estado === 'programado') return;
        if (M11.Libro.repararSinAccionFutura(candidato, Date.now())) {
          calendario.marcarEstado(candidato.id, 'programado');
        }
      });
    }
    let proximo = calendario.proximoPartido(referencia);

    // Una versión anterior pudo registrar anticipadamente el próximo
    // encuentro como "sin acción". Si aún no comienza, esa omisión es
    // cronológicamente imposible y se retira antes de comprobar duplicados.
    // Apuestas y decisiones manuales permanecen intocables.
    if (proximo && M11.Libro && M11.Libro.repararSinAccionFutura) {
      M11.Libro.repararSinAccionFutura(proximo, Date.now());
    }

    // Una fuente externa puede conservar como "programado" un encuentro
    // viejo o devolverlo otra vez en una sincronizacion posterior. Si el
    // Libro ya lo contiene, no es una oportunidad: se retira de la cola
    // antes de calcular niveles, monto o mostrar el boton de apuesta. Esto
    // evita el recorrido contradictorio "apostar" -> "ya estaba registrado"
    // y deja visible el siguiente partido realmente pendiente.
    // Límite defensivo: aun con un dato externo defectuoso, esta limpieza no
    // puede monopolizar el hilo principal ni congelar la pantalla de acceso.
    let depurados = 0;
    while (proximo && M11.Libro && M11.Libro.obtenerRegistroPartido && depurados < 100) {
      const registro = M11.Libro.obtenerRegistroPartido(proximo);
      if (!registro) break;
      const estadoCerrado = registro.resultado === 'cancelado' ? 'cancelado' :
        (registro.resultado === 'suspendido' ? 'suspendido' : 'finalizado');
      calendario.marcarEstado(proximo.id, estadoCerrado);
      depurados += 1;
      proximo = calendario.proximoPartido(referencia);
    }
    return proximo;
  };

  // Estrategias que aplican a este partido por la regla de paridad,
  // SIN importar si están bloqueadas. Es la única función que decide
  // paridad (General siempre; Pares en apuesta M11 par; Impares en
  // apuesta M11 impar). El calendario NO decide la paridad: un encuentro
  // no apostado no consume turno.
  M11.getEstrategiasPorParidad = function () {
    const decision = M11.Store.getDecision();
    const numero = decision && Number(decision.numeroApuestaM11)
      ? Number(decision.numeroApuestaM11)
      : (M11.Libro && M11.Libro.siguienteNumeroApuestaM11
        ? M11.Libro.siguienteNumeroApuestaM11()
        : 1);
    return M11.Engine.estrategiasParticipantes(numero);
  };

  // Estrategias realmente operables para este partido: las que aplican
  // por paridad Y no están bloqueadas por haber cerrado su secuencia en
  // nivel 11. Esta es la lista que debe usarse para TODO lo que mueve
  // dinero o niveles: mostrar la recomendación, guardar la apuesta,
  // registrar el resultado, actualizar niveles y capital, e historial.
  // Nunca se recalcula distinto en cada pantalla — todas llaman aquí.
  M11.getEstrategiasParticipantesActual = function () {
    const porParidad = M11.getEstrategiasPorParidad();
    const est = M11.Store.getEstrategias();
    return porParidad.filter(nombre => !est[nombre].bloqueada);
  };

  // ---- Estado calculado por tiempo (modo 'auto') ------------------------
  M11.calcularEstadoPorTiempo = function () {
    const p = M11.getPartidoActual();
    if (!p) return M11.ESTADOS.LISTO;
    const minsLeft = (M11.inicioPartidoMs(p) - Date.now()) / 60000;
    // V2.1.0: el operador puede organizar y registrar la apuesta desde el
    // comienzo del día del partido. La alarma de 15 minutos deja de ser una
    // puerta obligatoria y pasa a ser el último recordatorio. La tolerancia
    // posterior al inicio continúa cerrando estrictamente la oportunidad.
    const bogotaKey = value => new Intl.DateTimeFormat('en-CA', {
      timeZone:'America/Bogota', year:'numeric', month:'2-digit', day:'2-digit'
    }).format(new Date(value));
    const inicio = M11.inicioPartidoMs(p);
    if (Number.isFinite(inicio) && bogotaKey(inicio) === bogotaKey(Date.now()) &&
        Date.now() <= inicio + M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000) {
      return M11.ESTADOS.APOSTAR;
    }
    if (minsLeft > M11.Store.getUmbralProximoMin()) return M11.ESTADOS.LISTO;
    if (minsLeft > M11.Store.getUmbralApostarMin()) return M11.ESTADOS.PROXIMO;
    return M11.ESTADOS.APOSTAR;
  };

  M11.getEstadoActivo = function () {
    const decisionActiva = M11.Store.getDecision();
    // Una decision "No apostada" no tiene dinero comprometido ni niveles
    // por liquidar. Versiones anteriores la dejaban esperando el marcador
    // y bloqueaban incluso la alarma del partido siguiente. Se cierra aqui
    // tambien para reparar automaticamente esos residuos al actualizar.
    if (decisionActiva && decisionActiva.estado === 'NO_APOSTADA' &&
        M11.Transiciones && M11.Transiciones.cerrarNoApostadaPendiente) {
      M11.Transiciones.cerrarNoApostadaPendiente();
      return M11.calcularEstadoPorTiempo();
    }
    if (decisionActiva && ['PENDIENTE_RESULTADO','NO_APOSTADA'].includes(decisionActiva.estado)) {
      // Una apuesta pendiente conserva normalmente EST-05. Sin embargo,
      // cuando el operador pulsa INGRESAR RESULTADO MANUAL, abrirCierre()
      // fija explícitamente EST-06 y esa orden debe tener prioridad para
      // mostrar Empate / No empate / Cancelado / Suspendido.
      if (store.modo === 'flujo' && store.estado === M11.ESTADOS.FINALIZADO) return M11.ESTADOS.FINALIZADO;
      return M11.ESTADOS.ESPERANDO_RESULTADO;
    }
    if (M11.Store.getPartidoEnConfirmacion()) return M11.ESTADOS.ESPERANDO_CONFIRMACION;
    // Recuperación automática de estados antiguos/incompletos: esperar un
    // resultado sin una decisión persistida no es una operación válida y
    // nunca debe bloquear una nueva oportunidad.
    if (store.modo === 'flujo' &&
        (store.estado === M11.ESTADOS.ESPERANDO_RESULTADO || store.estado === M11.ESTADOS.FINALIZADO) &&
        !M11.Store.getDecision()) {
      M11.Store.setModo('auto');
    }
    // Si el usuario regresó tarde de la casa, EST-04 no puede quedar
    // congelado ni aplicarse a otro partido. getPartidoActual elimina la
    // selección vencida; sin ella volvemos al reloj normal.
    if (store.modo === 'flujo' && store.estado === M11.ESTADOS.ESPERANDO_CONFIRMACION &&
        !M11.Store.getPartidoEnConfirmacion()) {
      M11.Store.setModo('auto');
    }
    // Una decisión inexistente nunca puede dejar dinero comprometido. Las
    // versiones anteriores podían conservar ese residuo y sumarlo a la
    // apuesta siguiente, duplicando el valor al liquidar.
    if (!M11.Store.getDecision()) {
      const estrategias = M11.Store.getEstrategias();
      ['general', 'pares', 'impares'].forEach(nombre => {
        const e = estrategias[nombre];
        if (e && Number(e.comprometido) > 0) {
          M11.Store.setEstrategia(nombre, M11.Engine.liberarSinCambios(e).estado);
        }
      });
    }
    return store.modo === 'auto' ? M11.calcularEstadoPorTiempo() : store.estado;
  };

  // ---- Transiciones ------------------------------------------------------
  M11.Transiciones = {
    irACasaDeApuestas() {
      const p = M11.getPartidoActual();
      if (!p) return false;
      // Última barrera antes de abandonar el WebView: un partido ya
      // archivado nunca puede volver a abrir la casa ni presentarse como
      // una apuesta nueva, incluso si la fuente acaba de repetirlo.
      if (M11.Libro && M11.Libro.existePartido && M11.Libro.existePartido(p)) {
        M11.calendarioActivo().marcarEstado(p.id, 'finalizado');
        M11.Store.limpiarPartidoEnConfirmacion();
        M11.Store.setModo('auto');
        return false;
      }
      const inicio = M11.inicioPartidoMs(p), ahora = Date.now();
      if (Number.isFinite(inicio) && ahora > inicio + M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000) return false;
      M11.Store.setPartidoEnConfirmacion({ ...p, abiertaEn: new Date(ahora).toISOString(), limiteRegistro: Number.isFinite(inicio) ? new Date(inicio + M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000).toISOString() : null });
      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(M11.ESTADOS.ESPERANDO_CONFIRMACION);
      return true;
    },

    // datos: { montoApostado, cuota, casaDeApuestas }
    // El usuario confirma UNA apuesta real (un solo monto, una sola
    // cuota — así se apuesta de verdad en una casa de apuestas). Cada
    // estrategia participante se compromete igual por su propio monto
    // recomendado (montoPorNivel de su nivel actual: eso es lo que
    // prescribe el modelo), usando la cuota real confirmada — la misma
    // para todas porque es la misma apuesta. "montoApostado" queda
    // guardado como el registro real de lo apostado, aunque difiera del
    // recomendado.
    // datos: { montoApostado, cuota, casaDeApuestas }
    // El usuario confirma UNA apuesta real (un solo monto, una sola
    // cuota — así se apuesta de verdad en una casa de apuestas). El
    // monto RECOMENDADO por el modelo se calcula para mostrarlo y para
    // auditoría, pero el capital que se compromete de verdad es el que
    // el operador escribió — nunca el recomendado, aunque difieran.
    // Como el formulario pide un solo total para varias estrategias
    // independientes, ese total real se reparte proporcionalmente al
    // peso que cada una tenía en la recomendación (no se inventa otra
    // regla de reparto; solo se escala la misma distribución del modelo
    // al monto que realmente se apostó).
    confirmarApostada(datos) {
      const p = M11.getPartidoActual();
      if (!p) throw new Error('No existe un partido seleccionado para esta apuesta. Actualice el calendario.');
      if (datos.partidoIdEsperado && String(datos.partidoIdEsperado) !== String(p.id)) throw new Error('El partido cambió antes de guardar. Revise nuevamente equipos y hora.');
      const decisionExistente = M11.Store.getDecision();
      if (decisionExistente && ['PENDIENTE_RESULTADO','NO_APOSTADA'].includes(decisionExistente.estado)) throw new Error('Ya existe una decisión guardada para un partido. Debe cerrarla antes de registrar otra.');
      if (M11.Libro && M11.Libro.existePartido && M11.Libro.existePartido(p)) throw new Error('Este partido ya está registrado en el historial. No puede apostarse dos veces.');
      const inicioMs = M11.inicioPartidoMs(p);
      const confirmacion = M11.Store.getPartidoEnConfirmacion();
      const iniciadaATiempo = confirmacion && String(confirmacion.id) === String(p.id) &&
        (!confirmacion.limiteRegistro || new Date(confirmacion.abiertaEn || 0).getTime() <= new Date(confirmacion.limiteRegistro).getTime());
      if (Number.isFinite(inicioMs) && Date.now() > inicioMs + M11.CONFIG.GRACIA_APUESTA_EN_VIVO_MIN * 60000 && !iniciadaATiempo) {
        throw new Error('La oportunidad de este partido ya cerró. No se registró ninguna apuesta ni se modificó el capital.');
      }
      const numeroApuestaM11 = M11.Libro && M11.Libro.siguienteNumeroApuestaM11
        ? M11.Libro.siguienteNumeroApuestaM11()
        : 1;
      const estDisponibles = M11.Store.getEstrategias();
      const activas = M11.Engine.estrategiasParticipantes(numeroApuestaM11)
        .filter(nombre => !estDisponibles[nombre].bloqueada);
      const estAntes = M11.Store.getEstrategias();
      // Instantánea "antes" para el Libro de Operaciones: se guarda en el
      // momento real, nunca se reconstruye después con datos actuales.
      const snapshotAntes = {};
      let capitalTotalAntes = 0;
      ['general', 'pares', 'impares'].forEach(n => {
        snapshotAntes[n] = { nivelAntes: estAntes[n].nivel, saldoAntes: estAntes[n].disponible, bloqueadaAntes: !!estAntes[n].bloqueada };
        capitalTotalAntes += estAntes[n].disponible;
      });

      const recomendadoPorEstrategia = {};
      let montoRecomendadoTotal = 0;
      activas.forEach(nombre => {
        const recomendado = M11.Engine.montoPorNivel(estAntes[nombre].nivel);
        recomendadoPorEstrategia[nombre] = recomendado;
        montoRecomendadoTotal += recomendado;
      });

      // Monto real a comprometer: el confirmado por el operador. Si no
      // escribió un número válido, se usa el recomendado como única
      // alternativa razonable (nunca se inventa otra cifra distinta).
      const montoRealTotal = (typeof datos.montoApostado === 'number' && !Number.isNaN(datos.montoApostado) && datos.montoApostado >= 0)
        ? datos.montoApostado
        : montoRecomendadoTotal;

      const montosPorEstrategia = {};
      let asignado = 0;
      activas.forEach((nombre, indice) => {
        const peso = montoRecomendadoTotal > 0 ? recomendadoPorEstrategia[nombre] / montoRecomendadoTotal : 1 / activas.length;
        const montoReal = indice === activas.length - 1 ? montoRealTotal - asignado : Math.round(montoRealTotal * peso);
        asignado += montoReal;
        montosPorEstrategia[nombre] = montoReal;
        M11.Store.setEstrategia(nombre, M11.Engine.comprometer(estAntes[nombre], montoReal));
      });

      M11.Store.setDecision({
        id: 'op-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        partidoId: p ? p.id : null,
        numeroApuestaM11,
        partidoSnapshot: { id:p.id,externalId:p.externalId||null,leagueId:p.leagueId||null,operationId:p.operationId||null,torneo:p.torneo||'',numeroCronologico:p.numeroCronologico,numeroApuestaM11,fecha:p.fecha,hora:p.hora,timestampUTC:p.timestampUTC||null,equipoLocal:p.equipoLocal,equipoVisitante:p.equipoVisitante,provider:p.provider||null },
        montoRecomendado: montoRecomendadoTotal,
        montoApostado: montoRealTotal,
        cuota: typeof datos.cuota === 'number' ? datos.cuota : null,
        casaApuestas: datos.casaDeApuestas || null,
        estrategias: activas,
        montosPorEstrategia,
        estado: 'PENDIENTE_RESULTADO',
        fechaRegistroApuesta: new Date().toISOString(),
        resultado: null,
        capitalTotalAntes,
        snapshotAntes
      });
      M11.Store.limpiarPartidoEnConfirmacion();
      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(M11.ESTADOS.ESPERANDO_RESULTADO);
    },

    // "No apostada" cierra la decisión de este partido (no vuelve al
    // motor automático, que podría recomendar de nuevo la misma
    // apuesta). No compromete ni modifica ninguna estrategia: sin monto,
    // sin cuota.
    declararNoApostada() {
      const p = M11.getPartidoActual();
      const existente = M11.Store.getDecision();
      if (existente) throw new Error('Este partido ya tiene una decisión registrada. No puede reemplazarse por “No apostada”.');
      const confirmacion = M11.Store.getPartidoEnConfirmacion();
      if (!confirmacion || !p || String(confirmacion.id) !== String(p.id)) throw new Error('No existe una confirmación abierta para este partido. No se registró “No apostada”.');
      const estAntes = M11.Store.getEstrategias();
      const snapshotAntes = {};
      let capitalTotalAntes = 0;
      ['general', 'pares', 'impares'].forEach(n => {
        snapshotAntes[n] = { nivelAntes: estAntes[n].nivel, saldoAntes: estAntes[n].disponible, bloqueadaAntes: !!estAntes[n].bloqueada };
        capitalTotalAntes += estAntes[n].disponible;
      });
      M11.Store.setDecision({
        id: 'op-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        partidoId: p ? p.id : null,
        montoRecomendado: null,
        montoApostado: null,
        cuota: null,
        casaApuestas: null,
        estrategias: M11.getEstrategiasParticipantesActual(),
        estado: 'NO_APOSTADA',
        fechaRegistroApuesta: new Date().toISOString(),
        resultado: null,
        capitalTotalAntes,
        snapshotAntes
      });
      M11.Store.limpiarPartidoEnConfirmacion();
      // No existe nada por liquidar: se archiva inmediatamente y se libera
      // la siguiente oportunidad del campeonato.
      return M11.Transiciones.cerrarNoApostadaPendiente();
    },

    cerrarNoApostadaPendiente() {
      const op = M11.Store.getDecision();
      if (!op || op.estado !== 'NO_APOSTADA') return false;
      M11.Transiciones.registrarResultado(null);
      M11.Transiciones.continuarDespuesDeFinalizado();
      return true;
    },

    // Abre EST-06 (muestra el selector de resultado) sin resolver
    // todavía ninguna estrategia. La resolución real ocurre en
    // registrarResultado, cuando el usuario elige el resultado.
    abrirCierre() {
      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(M11.ESTADOS.FINALIZADO);
    },

    // resultado: 'empate' | 'no_empate' | 'cancelado' | 'suspendido'.
    // Devuelve el detalle contable por estrategia para mostrarlo y
    // auditarlo. Si no hubo apuesta pendiente para este partido, no
    // toca ninguna estrategia — nunca inventa un compromiso que no
    // existió. También construye y guarda el registro completo del
    // Libro de Operaciones M11 (única fuente de verdad por partido).
    registrarResultado(resultado) {
      const op = M11.Store.getDecision();
      const p = M11.getPartidoActual();
      const detallePorEstrategia = {};

      const huboApuestaVálida = op && op.estado === 'PENDIENTE_RESULTADO' && op.partidoId === (p ? p.id : null);
      if (huboApuestaVálida) {
        op.estrategias.forEach(nombre => {
          const actual = M11.Store.getEstrategias()[nombre];
          const exactoGuardado = op.montosPorEstrategia && Number(op.montosPorEstrategia[nombre]);
          const exacto = Number.isFinite(exactoGuardado)
            ? exactoGuardado
            : Math.max(0, Number(actual.comprometido) || 0);
          // Liquida exclusivamente el monto de ESTA decisión. Primero
          // devuelve cualquier compromiso residual y luego compromete el
          // valor exacto persistido para el partido actual.
          const baseDisponible = Number(actual.disponible) + (Number(actual.comprometido) || 0);
          const estadoExacto = { ...actual, disponible: baseDisponible - exacto, comprometido: exacto };
          let r;
          if (resultado === 'empate') {
            r = M11.Engine.resolver(estadoExacto, true, op.cuota);
          } else if (resultado === 'no_empate') {
            r = M11.Engine.resolver(estadoExacto, false, null);
          } else {
            r = M11.Engine.liberarSinCambios(estadoExacto); // cancelado o suspendido
          }
          detallePorEstrategia[nombre] = r.detalle;
          M11.Store.setEstrategia(nombre, r.estado);
        });
      }

      if (p) {
        const estadoPartido = (resultado === 'empate' || resultado === 'no_empate') ? 'finalizado' : resultado;
        M11.calendarioActivo().marcarEstado(p.id, estadoPartido);
      }

      if (op) {
        op.resultado = resultado;
        op.estado = 'RESUELTO';
        M11.Store.setDecision(op);
      }

      // --- Libro de Operaciones M11: registro único por partido -----------
      if (M11.Libro && op) {
        const estFinal = M11.Store.getEstrategias();
        const capitalTotalDespues = estFinal.general.disponible + estFinal.pares.disponible + estFinal.impares.disponible;
        const tipoOriginal = (op.montoApostado === null) ? 'no_apostada' : 'apostada';
        let totalApostado = 0, retornoTotal = 0, gananciaNetaTotal = 0;
        const estrategiasRegistro = {};
        ['general', 'pares', 'impares'].forEach(nombre => {
          const snap = (op.snapshotAntes && op.snapshotAntes[nombre]) || null;
          const participa = huboApuestaVálida && op.estrategias.includes(nombre);
          const d = detallePorEstrategia[nombre] || null;
          if (d) { totalApostado += d.montoApostado; retornoTotal += d.retorno; gananciaNetaTotal += d.gananciaNeta; }
          estrategiasRegistro[nombre] = {
            participa,
            nivelAntes: snap ? snap.nivelAntes : null,
            bloqueadaAntes: snap ? snap.bloqueadaAntes : null,
            montoRecomendado: (participa && snap) ? M11.Engine.montoPorNivel(snap.nivelAntes) : null,
            montoApostado: d ? d.montoApostado : null,
            cuota: d ? d.cuota : null,
            retorno: d ? d.retorno : null,
            gananciaNeta: d ? d.gananciaNeta : null,
            nivelDespues: d ? d.nivelNuevo : (snap ? snap.nivelAntes : null),
            saldoAntes: snap ? snap.saldoAntes : null,
            saldoDespues: d ? d.saldoDespues : (snap ? snap.saldoAntes : null),
            secuenciaFinalizada: d ? !!d.secuenciaFinalizada : false
          };
        });
        M11.Libro.registrarPartido({
          partido: p,
          numeroApuestaM11: op.numeroApuestaM11,
          tipoOriginal,
          resultado,
          casaApuestas: op.casaApuestas,
          cuotaConfirmada: op.cuota,
          montoApostadoConfirmado: op.montoApostado,
          capitalTotalAntes: (typeof op.capitalTotalAntes === 'number') ? op.capitalTotalAntes : null,
          capitalTotalDespues,
          totalApostado,
          retornoTotal,
          gananciaNetaTotal,
          estrategias: estrategiasRegistro,
          fechaRegistro: op.fechaRegistroApuesta || new Date().toISOString()
        });
      }

      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(M11.ESTADOS.FINALIZADO);
      return { detallePorEstrategia, huboApuestaVálida };
    },

    // En el Centro de Pruebas reprograma la semilla como siempre. En la
    // Operación real NUNCA inventa un partido: si no hay uno próximo, el
    // Asistente simplemente vuelve a "Todo está listo" (EST-01) hasta que
    // la sincronización con TheSportsDB traiga el siguiente o el operador
    // cargue uno manualmente (Sprint 019, "no inventar partidos").
    continuarDespuesDeFinalizado() {
      M11.Store.limpiarDecision();
      M11.Store.limpiarPartidoEnConfirmacion();
      if (M11.Store.getCentroPruebas() && !M11.CalendarioDemo.proximoPartido()) {
        M11.CalendarioDemo.reprogramarSemilla(M11.CONFIG.DEFAULT_ADELANTO_MIN);
      }
      M11.Store.setModo('auto');
    },

    // Modo de demostración: usa el MISMO mecanismo que las
    // transiciones normales (no un sistema aparte), así que después
    // de saltar a un estado el flujo puede seguir con los botones
    // normales sin quedar "atascado" en el estado fijado.
    irAEstadoDemo(destino) {
      if (destino === 'automatico') { M11.Store.setModo('auto'); return; }
      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(destino);
    },

    // Reinicia toda la demostración: estrategias a su punto de partida,
    // calendario DEMO al único partido de ejemplo (nunca toca la Operación
    // real ni su calendario de TheSportsDB), decisión y modo limpios. Este
    // botón existe siempre en Configuración, esté o no activo el Centro de
    // Pruebas — por eso usa reiniciarEstrategiasDemo() explícito en vez del
    // reiniciarEstrategias() enrutado por el interruptor.
    reiniciarDemostracion() {
      M11.Store.limpiarDecisionDemo();
      M11.Store.reiniciarEstrategiasDemo();
      M11.CalendarioDemo.reiniciar();
      M11.Store.setModo('auto');
    },

    // Sprint V1.0.5: se eliminó M11.Transiciones.reiniciarSecuencia(nombre)
    // — era el único camino que permitía recargar una estrategia agotada
    // en Nivel 11 dentro del mismo torneo, violando la prohibición de
    // recargar una estrategia agotada. M11.Engine.reiniciarSecuencia()
    // (m11-engine.js) no se tocó — es solo un constructor de estado
    // inerte; ya no lo llama nadie desde esta capa.

    // Centro de Pruebas M11 — "Reiniciar torneo demo": reinicio completo
    // y más agresivo que "Reiniciar demostración" (esa vuelve a la
    // semilla 8/6/1 y conserva el historial; esta vuelve las tres
    // estrategias a Nivel 1 con presupuesto completo y SÍ borra el
    // historial), pensado para poder repetir pruebas de punta a punta
    // muchas veces seguidas.
    reiniciarTorneoDemo() {
      M11.Store.limpiarDecision();
      ['general', 'pares', 'impares'].forEach(nombre => M11.Store.setEstrategia(nombre, M11.Engine.nuevoEstadoEstrategia()));
      M11.CalendarioDemo.reiniciar();
      M11.Audit.limpiar();
      if (M11.Libro) M11.Libro.reiniciar();
      if (M11.Evaluacion) M11.Evaluacion.reiniciar();
      M11.Store.setModo('auto');
    },

    // Sprint V1.0.5 — "Reiniciar Liga demostrativa": una versión anterior
    // (antes de que existiera el sistema de Operaciones) dejó niveles de
    // prueba guardados en las claves clásicas; al migrar a Operaciones
    // esos datos se conservaron tal cual, como si fueran una operación
    // real más (para no perder nada sin que el operador lo decidiera) —
    // pero en la práctica eran datos de demostración, no una operación
    // real genuina. Esta función reinicia SOLO esa operación puntual
    // (estrategias a Nivel 1, decisión pendiente, Libro, diagnóstico y
    // capital inicial declarado) — nunca ninguna otra operación, real o
    // no. Se verifica dos veces que en verdad sea una operación marcada
    // como "migrada" (acá y en el botón que la llama, ver
    // operaciones-ui.js/events.js) para que jamás pueda usarse por error
    // sobre una operación real genuina.
    reiniciarOperacionMigrada(operacionId) {
      const op = M11.Operaciones.obtener(operacionId);
      if (!op || !op.migrada) return false;
      almacenEstrategiasRealDe(operacionId).reiniciar();
      almacenDecisionRealDe(operacionId).limpiar();
      if (M11.Libro) M11.Libro.reiniciarOperacion(operacionId);
      if (M11.Evaluacion) M11.Evaluacion.reiniciarOperacion(operacionId);
      M11.Operaciones.limpiarCapitalInicial(operacionId);
      return true;
    },

    // Centro de Pruebas M11 — "Siguiente estado": avanza manualmente
    // EST-01→02→03→04→05→06. Al pasar de EST-04, confirma automáticamente
    // con los valores recomendados (para poder probar decenas de veces
    // sin llenar el formulario cada vez); al pasar de EST-05, abre el
    // cierre. No hace nada si ya está en EST-06 (para eso está "Siguiente
    // partido").
    centroPruebasSiguienteEstado() {
      const E = M11.ESTADOS;
      const orden = [E.LISTO, E.PROXIMO, E.APOSTAR, E.ESPERANDO_CONFIRMACION, E.ESPERANDO_RESULTADO, E.FINALIZADO];
      const actual = M11.getEstadoActivo();
      const idx = orden.indexOf(actual);
      if (idx === -1 || idx >= orden.length - 1) return;
      if (actual === E.ESPERANDO_CONFIRMACION) {
        const p = M11.getPartidoActual();
        const activas = M11.getEstrategiasParticipantesActual();
        const est = M11.Store.getEstrategias();
        const montoRecomendado = activas.reduce((s, n) => s + M11.Engine.montoPorNivel(est[n].nivel), 0);
        const cuota = (p && p.cuotaReferencia) ? p.cuotaReferencia : 2;
        M11.Transiciones.confirmarApostada({ montoApostado: montoRecomendado, cuota, casaDeApuestas: null });
        return;
      }
      if (actual === E.ESPERANDO_RESULTADO) { M11.Transiciones.abrirCierre(); return; }
      M11.Store.setModo('flujo');
      M11.Store.setEstadoManual(orden[idx + 1]);
    },

    // Centro de Pruebas M11 — "Siguiente partido": cierra el partido
    // actual y selecciona el siguiente por orden cronológico. Se guía por
    // el estado de la propia decisión (no por comparar contra "el próximo
    // partido", que ya puede estar en null justo después de cerrar el
    // anterior): si hay una decisión sin resolver, se cierra como
    // cancelada; si no hay ninguna, se registra como "No apostada" +
    // "Cancelado" para que el partido saltado también quede en el Libro
    // de Operaciones. Si ya se resolvió desde el panel (Empate/No
    // empate/Cancelado), no se toca de nuevo — ya quedó registrado.
    centroPruebasSiguientePartido() {
      const op = M11.Store.getDecision();
      if (op && op.estado !== 'RESUELTO') {
        M11.Transiciones.registrarResultado('cancelado');
      } else if (!op && M11.getPartidoActual()) {
        M11.Transiciones.declararNoApostada();
        M11.Transiciones.registrarResultado('cancelado');
      }
      M11.Store.limpiarDecision();
      if (!M11.CalendarioDemo.proximoPartido()) {
        M11.CalendarioDemo.reprogramarSemilla(1);
      }
      M11.Store.setModo('auto');
    }
  };

})(window.M11);
