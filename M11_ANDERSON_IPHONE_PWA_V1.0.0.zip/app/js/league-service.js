/* =========================================================
   M11 · league-service.js  (Sprint 019)
   -----------------------------------------------------------
   Capa de aplicación sobre sports-api.js: decide qué liga está
   activa, mantiene la numeración cronológica estable de los
   partidos (para que Pares/Impares nunca cambien de partido ya
   mostrado), gestiona la caché de 30 minutos y traduce cualquier
   falla en uno de los "Estados de conexión" que la interfaz debe
   mostrar siempre (nunca deja la pantalla vacía).

   El calendario sigue sin decidir cuota, monto ni nivel. La capa
   real-sync.js consume sus marcadores definitivos para conciliar la
   operación automáticamente y deja revisión manual solo ante datos
   ausentes o contradictorios.
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const LS_LIGA = 'm11_active_league_v1';
  const LS_CACHE = 'm11_sports_api_cache_v1';
  const LS_CRONOLOGICOS = 'm11_numeros_cronologicos_v1';
  const CACHE_MS = 30 * 60000;

  // Lista inicial sugerida (sección 5 del encargo). No limita
  // internamente el sistema: "Otro país" permite escribir cualquier
  // nombre compatible con TheSportsDB.
  const PAISES_SUGERIDOS = [
    { label: 'Colombia', valorApi: 'Colombia' },
    { label: 'Argentina', valorApi: 'Argentina' },
    { label: 'Brasil', valorApi: 'Brazil' },
    { label: 'España', valorApi: 'Spain' },
    { label: 'Inglaterra', valorApi: 'England' },
    { label: 'Italia', valorApi: 'Italy' },
    { label: 'Alemania', valorApi: 'Germany' },
    { label: 'Francia', valorApi: 'France' },
    { label: 'Portugal', valorApi: 'Portugal' },
    { label: 'México', valorApi: 'Mexico' },
    { label: 'Estados Unidos', valorApi: 'USA' }
  ];

  // ---- Estado de conexión (sección 16) -----------------------------------
  // Nunca se deja la pantalla vacía: siempre hay uno de estos valores.
  let estadoConexion = 'INFORMACION_GUARDADA';
  let ultimoError = null;
  let sincronizando = false;
  function setEstadoConexion(valor, error) { estadoConexion = valor; ultimoError = error || null; }

  // ---- Persistencia -------------------------------------------------------
  function leerJSON(key, porDefecto) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : porDefecto;
    } catch (e) { return porDefecto; }
  }
  function escribirJSON(key, valor) { localStorage.setItem(key, JSON.stringify(valor)); }

  function getLigaActiva() { return leerJSON(LS_LIGA, null); }
  function guardarLigaActiva(config) {
    const operacion=M11.Operaciones&&M11.Operaciones.getActiva?M11.Operaciones.getActiva():null;
    const actual = {
      provider: 'TheSportsDB',
      country: config.country,
      leagueId: String(config.leagueId),
      leagueName: config.leagueName,
      season: config.season || '',
      displayName: config.displayName || config.leagueName,
      operationId: operacion ? operacion.id : null,
      trackingStartedAt: operacion ? operacion.fechaInicio : new Date().toISOString(),
      selectedAt: new Date().toISOString(),
      lastSyncAt: null
    };
    escribirJSON(LS_LIGA, actual);
    return actual;
  }
  function limpiarLigaActiva() {
    localStorage.removeItem(LS_LIGA);
    localStorage.removeItem(LS_CACHE);
    // La numeración cronológica NO se borra: si el operador vuelve a
    // elegir la misma liga más adelante, los partidos que ya vio
    // conservan su mismo número (nunca se reordena Pares/Impares que
    // el operador ya haya visto en pantalla).
    // Los partidos de la liga anterior que seguían sin resolver también
    // se retiran (ver calendar.js, retirarProgramadosApi): si no se
    // retiraran, el Centro de Operaciones seguiría mostrando el próximo
    // partido de una liga que el operador ya abandonó. Quien llama a esta
    // función debe comprobar antes que no haya una decisión pendiente
    // (events.js, confirmarCambioLiga) — aquí no se vuelve a comprobar.
    M11.Calendario.retirarProgramadosApi();
    setEstadoConexion('INFORMACION_GUARDADA');
  }
  function actualizarLigaActiva(cambios) {
    const actual = getLigaActiva();
    if (!actual) return null;
    const nueva = { ...actual, ...cambios };
    escribirJSON(LS_LIGA, nueva);
    return nueva;
  }

  function getCache() { return leerJSON(LS_CACHE, null); }
  function cacheVigente() {
    const c = getCache();
    if (!c || !c.fetchedAt) return false;
    return (Date.now() - new Date(c.fetchedAt).getTime()) < CACHE_MS;
  }

  // ---- Numeración cronológica estable --------------------------------------
  // Una vez asignado, el número cronológico de un partido (por su
  // externalId) nunca cambia entre sincronizaciones — de lo contrario
  // Pares/Impares podría "voltearse" para un partido que el operador ya
  // vio en pantalla. Los partidos nuevos siguen la cuenta hacia adelante,
  // ordenados por fecha entre sí.
  function asignarNumerosCronologicos(leagueId, eventosNormalizados, operationId) {
    const todos = leerJSON(LS_CRONOLOGICOS, {});
    const scope=`${leagueId}__${operationId||'global'}`;
    const registro = todos[scope] || { siguiente: 1, asignados: {} };
    const pendientesDeNumero = eventosNormalizados
      .filter(e => !(e.externalId in registro.asignados))
      .sort((a, b) => new Date(a.timestampUTC || 0) - new Date(b.timestampUTC || 0));
    pendientesDeNumero.forEach(e => {
      registro.asignados[e.externalId] = registro.siguiente;
      registro.siguiente += 1;
    });
    todos[scope] = registro;
    escribirJSON(LS_CRONOLOGICOS, todos);
    return eventosNormalizados.map(e => ({ ...e, numeroCronologico: registro.asignados[e.externalId] }));
  }

  // ---- Conversión evento normalizado -> forma de calendar.js ---------------
  function eventoAPartidoDeCalendario(evento, ligaActiva) {
    return {
      id: 'sdb-' + evento.externalId,
      torneo: (ligaActiva && ligaActiva.displayName) || evento.leagueName || 'Liga sin nombre',
      numeroCronologico: evento.numeroCronologico,
      fecha: evento.fecha,
      hora: evento.hora,
      equipoLocal: evento.homeTeam || 'Local',
      equipoVisitante: evento.awayTeam || 'Visitante',
      // La API nunca determina la cuota (sección 12): queda pendiente de
      // registro manual, tal como ya lo permite calendar.js.
      cuotaReferencia: null,
      estado: 'programado',
      provider: 'TheSportsDB',
      externalId: evento.externalId,
      leagueId: evento.leagueId,
      sourceMode: 'real',
      operationId: ligaActiva&&ligaActiva.operationId||null,
      // Campos informativos adicionales (Partidos, cierre EST-06):
      venue: evento.venue || '',
      timestampUTC: evento.timestampUTC,
      resultadoSugerido: evento.resultadoSugerido,
      marcadorDetectado: (evento.homeScore !== null && evento.awayScore !== null) ? { home: evento.homeScore, away: evento.awayScore } : null,
      resultadoContradictorio: !!evento.resultadoContradictorio,
      estadoApi: evento.status
    };
  }

  // ---- Búsqueda de ligas ----------------------------------------------------
  async function buscarLigas(pais) {
    return M11.SportsApi.buscarLigasPorPais(pais);
  }

  async function buscarInternacionales() {
    return M11.SportsApi.buscarCompeticionesInternacionales();
  }

  function textoFase(evento) {
    return [evento&&evento.strGroup,evento&&evento.strRound,evento&&evento.strDescription,
      evento&&evento.strLeagueAlternate,evento&&evento.strStage,evento&&evento.strDivision]
      .filter(Boolean).join(' ').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  }
  function filtrarFaseConfigurada(liga,eventos) {
    const lista=Array.isArray(eventos)?eventos:[];
    if(String(liga&&liga.leagueId)!=='4957')return lista;
    const hayFases=lista.some(e=>/ascenso|promotion|descenso|relegation/.test(textoFase(e)));
    if(!hayFases)return lista;
    return lista.filter(e=>/ascenso|promotion/.test(textoFase(e)));
  }

  // Descarga próximos + anteriores de una liga candidata SOLO para detectar
  // temporadas antes de guardarla (sección 5, "Temporada"). No escribe nada
  // en el calendario todavía — eso ocurre recién al pulsar "GUARDAR LIGA Y
  // CALENDARIO" (guardarLigaYSincronizar).
  async function detectarTemporadas(leagueId) {
    const [proximos, anteriores] = await Promise.all([
      M11.SportsApi.proximosPartidosLiga(leagueId).catch(() => []),
      M11.SportsApi.partidosAnterioresLiga(leagueId).catch(() => [])
    ]);
    const todos = [...proximos, ...anteriores];
    const temporadas = Array.from(new Set(todos.map(e => e.strSeason).filter(Boolean)));
    return temporadas;
  }

  // ---- Sincronización (núcleo del Sprint 019) ------------------------------
  // Descarga próximos + anteriores de la liga activa, normaliza, asigna
  // numeración cronológica estable y fusiona con M11.Calendario sin perder
  // partidos con decisión pendiente ni cargados manualmente. Nunca toca
  // capital, niveles ni estrategias.
  async function sincronizar(opciones) {
    const forzar = !!(opciones && opciones.forzar);
    const liga = getLigaActiva();
    if (!liga) { setEstadoConexion('LIGA_SIN_CALENDARIO'); return { ok: false, motivo: 'SIN_LIGA' }; }

    if (!forzar && cacheVigente()) {
      setEstadoConexion('INFORMACION_GUARDADA');
      return { ok: true, motivo: 'CACHE_VIGENTE' };
    }

    sincronizando = true;
    setEstadoConexion('ACTUALIZANDO');
    try {
      let proximosRaw=[],anterioresRaw=[],errorPrincipal=null;
      try{[proximosRaw,anterioresRaw]=await Promise.all([
        M11.SportsApi.proximosPartidosLiga(liga.leagueId),
        M11.SportsApi.partidosAnterioresLiga(liga.leagueId)
      ]);}catch(error){errorPrincipal=error;}
      // Segunda ruta NORMAL, sin IA y sin costo: tablero diario del proveedor.
      // Se utiliza cuando los listados de próximos/anteriores están vacíos o
      // fallan. Los once campeonatos reutilizan la misma respuesta en caché.
      let diariosRaw=[];
      if(errorPrincipal||(!proximosRaw.length&&!anterioresRaw.length)){
        diariosRaw=(await M11.SportsApi.partidosVentanaDiaria()).filter(e=>String(e.idLeague||'')===String(liga.leagueId));
      }
      if(errorPrincipal&&!diariosRaw.length)throw errorPrincipal;
      const inicioSeguimiento=new Date(liga.trackingStartedAt||0).getTime();
      const eventosFiltrados=filtrarFaseConfigurada(liga,[...proximosRaw,...anterioresRaw,...diariosRaw]);
      const normalizados = eventosFiltrados
        .map(ev => M11.SportsApi.normalizeSportsDbEvent(ev, { leagueId: liga.leagueId, leagueName: liga.leagueName, season: liga.season }))
        .filter(ev => ev.externalId && ev.timestampUTC && (!Number.isFinite(inicioSeguimiento)||new Date(ev.timestampUTC).getTime()>=inicioSeguimiento));

      const conNumero = asignarNumerosCronologicos(liga.leagueId, normalizados, liga.operationId);

      // Solo los partidos todavía SIN resultado definitivo entran como
      // "programado" al calendario operativo: un partido con marcador
      // definitivo permanece disponible para que el operador lo confirme
      // manualmente (sección 13) mientras siga siendo, por fecha, el
      // partido vigente; los que la propia API marca aplazado/cancelado/
      // suspendido y sobre los que el operador nunca llegó a decidir se
      // omiten en vez de inventarles un estado — no hay ninguna regla de
      // este sprint para tratarlos automáticamente.
      const utilizables = conNumero.filter(ev => ev.status !== 'aplazado');
      const partidosCalendario = utilizables.map(ev => eventoAPartidoDeCalendario(ev, liga));

      const decision = M11.Store.getDecision();
      const idDecisionPendiente = (decision && decision.estado === 'PENDIENTE_RESULTADO') ? decision.partidoId : null;
      M11.Calendario.fusionarPartidosApi(partidosCalendario, { idDecisionPendiente });

      const cache = { leagueId: liga.leagueId, fetchedAt: new Date().toISOString(), nextEvents: proximosRaw, previousEvents: anterioresRaw, dailyEvents:diariosRaw, source:diariosRaw.length?'calendario_diario':'proximos_y_anteriores' };
      escribirJSON(LS_CACHE, cache);
      actualizarLigaActiva({ lastSyncAt: cache.fetchedAt });
      setEstadoConexion(partidosCalendario.length ? 'CONECTADO' : 'LIGA_SIN_CALENDARIO');
      return { ok: true };
    } catch (err) {
      const codigo = err && err.codigoM11;
      if (codigo === 'SIN_CONEXION' || codigo === 'TIEMPO_AGOTADO') setEstadoConexion('SIN_CONEXION', err);
      else if (codigo === 'LIMITE_LOCAL' || codigo === 'LIMITE_PROVEEDOR') setEstadoConexion('SERVICIO_NO_DISPONIBLE', err);
      else setEstadoConexion('SERVICIO_NO_DISPONIBLE', err);
      // No se pierde la última información guardada: M11.Calendario
      // conserva lo que ya tenía (fusionarPartidosApi nunca se llamó).
      return { ok: false, error: err };
    } finally {
      sincronizando = false;
    }
  }

  async function sincronizarSiHaceFalta() {
    if (!getLigaActiva()) { setEstadoConexion('LIGA_SIN_CALENDARIO'); return; }
    if (sincronizando) return;
    if (cacheVigente()) { setEstadoConexion('INFORMACION_GUARDADA'); return; }
    await sincronizar({ forzar: false });
  }

  // ---- Guardar liga y disparar la primera sincronización -------------------
  async function guardarLigaYSincronizar({ country, leagueId, leagueName, season, displayName }) {
    const anterior=getLigaActiva(),op=M11.Operaciones&&M11.Operaciones.getActiva?M11.Operaciones.getActiva():null;
    if(!anterior||String(anterior.leagueId)!==String(leagueId)||String(anterior.operationId||'')!==String(op&&op.id||''))M11.Calendario.reiniciar();
    guardarLigaActiva({ country, leagueId, leagueName, season, displayName });
    return sincronizar({ forzar: true });
  }

  M11.LeagueService = {
    PAISES_SUGERIDOS,
    getLigaActiva,
    limpiarLigaActiva,
    buscarLigas,
    buscarInternacionales,
    filtrarFaseConfigurada,
    detectarTemporadas,
    guardarLigaYSincronizar,
    sincronizar,
    sincronizarSiHaceFalta,
    getEstadoConexion() { return estadoConexion; },
    getUltimoError() { return ultimoError; },
    estaSincronizando() { return sincronizando; },
    getCache
  };

})(window.M11);
