/* =========================================================
   M11 · calendar.js
   -----------------------------------------------------------
   Dos calendarios INDEPENDIENTES, nunca mezclados (Sprint 019,
   sección 17 del encargo: "Operación real vs Centro de Pruebas"):

   - M11.Calendario      -> OPERACIÓN REAL. Se alimenta de dos
     fuentes únicamente: la sincronización con TheSportsDB
     (league-service.js) y la carga manual de emergencia
     (Configuración -> Operación real -> Herramientas avanzadas).
     No trae ningún partido de ejemplo: si no hay liga configurada
     ni partidos cargados manualmente, empieza vacío.

   - M11.CalendarioDemo  -> CENTRO DE PRUEBAS M11. Exactamente el
     mismo calendario de ejemplo que existía antes de este sprint
     (semilla automática, reprogramarSemilla, reiniciar), ahora en
     su propio almacenamiento para que la API nunca lo toque y él
     nunca contamine la operación real.

   Ambos comparten la misma implementación (crearCalendario, más
   abajo) para no duplicar reglas ni arriesgar que diverjan.

   Cada partido: { id, torneo, numeroCronologico, fecha ('YYYY-MM-DD'),
   hora ('HH:MM'), equipoLocal, equipoVisitante, cuotaReferencia,
   estado: 'programado' | 'finalizado' | 'cancelado' | 'suspendido' |
   'descartado_simultaneidad', provider: 'TheSportsDB' | 'manual' |
   'demo', externalId, leagueId, sourceMode: 'real' | 'demo' }.
   provider/externalId/leagueId/sourceMode son nuevos en este
   sprint; el resto de los campos no cambia — nada de lo que ya
   dependía de ellos (m11-engine.js, state.js, libro.js, ui.js)
   necesita saber de dónde vino el partido.

   Simultaneidad (Sprint 006): dos partidos se consideran simultáneos
   cuando la diferencia entre sus horas de inicio es MENOR a 120
   minutos (120 exactos ya NO cuentan como simultáneos). Esta sigue
   siendo la única función de toda la aplicación que decide esa
   condición — nadie más debe reimplementarla. Cuando el partido
   "próximo" tiene uno o más simultáneos pendientes, el sistema NO
   elige automático: debe preguntarle al operador (ver
   grupoSimultaneoPendiente y el modal correspondiente en
   ui.js/events.js).
   ========================================================= */
window.M11 = window.M11 || {};

(function (M11) {
  'use strict';

  const VENTANA_SIMULTANEIDAD_MIN = 120;

  function fechaHoraMs(p) {
    return new Date(p.timestampUTC || `${p.fecha}T${p.hora}:00`).getTime();
  }

  // Única función de toda la app que decide si dos partidos son
  // simultáneos: diferencia MENOR a 120 minutos (120 exactos no
  // cuentan). 18:00 y 19:59 -> simultáneos. 18:00 y 20:00 -> no.
  // No depende de qué calendario (real o demo) vengan los partidos.
  function sonSimultaneos(a, b) {
    const diffMin = Math.abs(fechaHoraMs(a) - fechaHoraMs(b)) / 60000;
    return diffMin < VENTANA_SIMULTANEIDAD_MIN;
  }

  // Único partido de ejemplo para que el Centro de Pruebas M11 no
  // arranque vacío. Es un dato de demostración (equipos, cuota de
  // referencia), no una regla del modelo. Arranca en cronológico
  // impar (1) para que el primer partido de toda simulación sea
  // General + Impares, y el segundo General + Pares, alternando desde
  // ahí — corrección explícita del Director: "Partido 1: General +
  // Impares; Partido 2: General + Pares". La regla de paridad en sí
  // (par->Pares, impar->Impares) vive únicamente en
  // M11.Engine.estrategiasParticipantes.
  function partidoSemillaDemo() {
    const d = new Date(Date.now() + 10 * 60000);
    const pad = n => String(n).padStart(2, '0');
    return {
      id: 'demo-1',
      torneo: 'Liga demostrativa',
      numeroCronologico: 1,
      fecha: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
      hora: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      equipoLocal: 'Junior',
      equipoVisitante: 'Nacional',
      cuotaReferencia: 3.60,
      estado: 'programado',
      provider: 'demo',
      externalId: null,
      leagueId: null,
      sourceMode: 'demo'
    };
  }

  // Fábrica: crea un calendario independiente (su propio arreglo en
  // memoria y su propia clave de localStorage). `autoSemilla` decide
  // si arranca con el partido de ejemplo (Centro de Pruebas) o vacío
  // (Operación real, que nunca debe mostrar un partido inventado).
  function crearCalendario(lsKey, opciones) {
    const autoSemilla = !!(opciones && opciones.autoSemilla);

    function load() {
      try {
        const raw = localStorage.getItem(lsKey);
        if (raw) {
          const arr = JSON.parse(raw);
          if (Array.isArray(arr)) return arr;
        }
      } catch (e) { /* datos corruptos: se recrea abajo */ }
      // Importante: se guarda de inmediato. Si no se persistiera aquí, el
      // estado inicial existiría solo en memoria hasta la primera acción
      // que tocara el calendario, y una recarga de página lo regeneraría
      // con una hora nueva (en el caso de la semilla), perdiendo el
      // partido real sobre el que el usuario ya estaba operando.
      const inicial = autoSemilla ? [partidoSemillaDemo()] : [];
      localStorage.setItem(lsKey, JSON.stringify(inicial));
      return inicial;
    }

    let partidos = load();
    function persist() { localStorage.setItem(lsKey, JSON.stringify(partidos)); }

    const api = {
      listar() { return partidos.slice(); },

      agregar(datos) {
        const id = 'p-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
        partidos.push({
          id,
          torneo: datos.torneo || 'Sin especificar',
          numeroCronologico: Number(datos.numeroCronologico),
          fecha: datos.fecha,
          hora: datos.hora,
          equipoLocal: datos.equipoLocal,
          equipoVisitante: datos.equipoVisitante,
          cuotaReferencia: (datos.cuotaReferencia !== undefined && datos.cuotaReferencia !== '') ? Number(datos.cuotaReferencia) : null,
          estado: 'programado',
          provider: datos.provider || 'manual',
          externalId: datos.externalId || null,
          leagueId: datos.leagueId || null,
          sourceMode: datos.sourceMode || (autoSemilla ? 'demo' : 'real')
        });
        persist();
        return id;
      },

      sonSimultaneos,

      // Primer partido 'programado', ordenado por fecha+hora; en caso
      // de empate exacto de fecha+hora, decide el número cronológico
      // (desempate determinista de orden, no reemplaza la pregunta al
      // operador cuando hay simultaneidad real — ver grupoSimultaneoPendiente).
      proximoPartido(referenciaMs) {
        const ahora = Number.isFinite(Number(referenciaMs)) ? Number(referenciaMs) : Date.now();
        // Un registro puede continuar marcado como "programado" cuando la
        // fuente todavía no publicó su resultado. Eso no lo convierte en un
        // partido futuro: nunca debe volver a invitar al usuario a apostar.
        const pendientes = partidos.filter(p => p.estado === 'programado' && Number.isFinite(fechaHoraMs(p)) && fechaHoraMs(p) > ahora);
        if (!pendientes.length) return null;
        pendientes.sort((a, b) => {
          const diff = fechaHoraMs(a) - fechaHoraMs(b);
          if (diff !== 0) return diff;
          return a.numeroCronologico - b.numeroCronologico;
        });
        return pendientes[0];
      },

      // Próxima oportunidad distinta de un partido que todavía está
      // pendiente de resultado. Se usa únicamente para informar al
      // operador de encuentros encadenados; no altera niveles ni permite
      // saltarse la liquidación del partido anterior.
      proximoPartidoDespuesDe(partidoId, referenciaMs) {
        const ahora = Number.isFinite(Number(referenciaMs)) ? Number(referenciaMs) : Date.now();
        const pendientes = partidos.filter(p =>
          p.id !== partidoId && p.estado === 'programado' &&
          Number.isFinite(fechaHoraMs(p)) && fechaHoraMs(p) > ahora
        ).slice().sort((a, b) => fechaHoraMs(a) - fechaHoraMs(b));
        return pendientes[0] || null;
      },

      // Si el partido "próximo" tiene otro(s) partido(s) programado(s)
      // dentro de la ventana de simultaneidad (120 min), los devuelve a
      // todos juntos (2 o más) para que el operador elija uno. Si no hay
      // ninguno así, devuelve null y el flujo sigue normal.
      grupoSimultaneoPendiente() {
        const ahora = Date.now();
        const pendientes = partidos.filter(p => p.estado === 'programado' && Number.isFinite(fechaHoraMs(p)) && fechaHoraMs(p) > ahora).slice()
          .sort((a, b) => fechaHoraMs(a) - fechaHoraMs(b));
        if (pendientes.length < 2) return null;
        const primero = pendientes[0];
        const grupo = pendientes.filter(p => sonSimultaneos(p, primero));
        return grupo.length > 1 ? grupo : null;
      },

      obtener(id) { return partidos.find(p => p.id === id) || null; },

      obtenerPorExternalId(provider, externalId) {
        return partidos.find(p => p.provider === provider && String(p.externalId) === String(externalId)) || null;
      },

      marcarEstado(id, estado) {
        let cambio = false;
        partidos.forEach(p => { if (p.id === id) { p.estado = estado; cambio = true; } });
        if (cambio) persist();
      },

      // Reprograma el partido semilla hacia adelante (para repetir el
      // ciclo de demostración) y lo vuelve a poner 'programado'. Incrementa
      // el número cronológico en cada reprogramación: si no lo hiciera, el
      // ciclo automático repetiría siempre el mismo número (y por lo tanto
      // siempre la misma estrategia secundaria, en vez de alternar entre
      // Pares e Impares como exige el modelo). Solo tiene sentido en el
      // Centro de Pruebas: la Operación real nunca reprograma un partido
      // inventado.
      reprogramarSemilla(minutosAdelante) {
        const idx = partidos.findIndex(p => p.id === 'demo-1');
        const d = new Date(Date.now() + minutosAdelante * 60000);
        const pad = n => String(n).padStart(2, '0');
        const fecha = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        const hora = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
        if (idx >= 0) {
          const numeroCronologico = partidos[idx].numeroCronologico + 1;
          partidos[idx] = { ...partidos[idx], fecha, hora, estado: 'programado', numeroCronologico };
        } else {
          partidos.unshift({ ...partidoSemillaDemo(), fecha, hora, estado: 'programado' });
        }
        persist();
      },

      // Reinicia el calendario completo al único partido de ejemplo
      // (Centro de Pruebas) o a vacío (Operación real).
      reiniciar() {
        partidos = autoSemilla ? [partidoSemillaDemo()] : [];
        persist();
      },

      // ---- Exclusivo de la Operación real (Sprint 019) --------------
      // Fusiona el resultado de una sincronización con TheSportsDB sin
      // perder nada importante:
      //  - conserva el partido con la decisión pendiente de resultado
      //    (si el operador ya apostó y está esperando el cierre, un
      //    refresco de calendario nunca puede hacerle perder ese partido);
      //  - conserva los partidos cargados manualmente (carga de emergencia,
      //    provider:'manual');
      //  - conserva los partidos ya resueltos (para que sigan visibles un
      //    tiempo en "Resultados recientes"), hasta un tope razonable;
      //  - reemplaza el resto de los partidos 'programado' de origen API
      //    por los recién descargados.
      // No es responsabilidad de esta función asignar numeroCronologico
      // (eso lo hace league-service.js, de forma estable entre
      // sincronizaciones) ni decidir reglas del modelo.
      fusionarPartidosApi(partidosNuevosApi, opcionesFusion) {
        const idDecisionPendiente = (opcionesFusion && opcionesFusion.idDecisionPendiente) || null;
        const TOPE_RESUELTOS = 40;
        const conservarManualOPendiente = partidos.filter(p =>
          p.id === idDecisionPendiente || p.provider === 'manual'
        ).map(p => {
          if (p.id !== idDecisionPendiente) return p;
          const actualizado = partidosNuevosApi.find(n => n.id === p.id);
          // El partido comprometido se conserva, pero recibe el marcador y
          // estado más recientes. Antes se conservaba una copia vieja y se
          // descartaba precisamente la actualización que permitía cerrarlo.
          return actualizado ? { ...p, ...actualizado, estado: p.estado } : p;
        });
        const idsFuturosVigentes = new Set(partidosNuevosApi
          .filter(p => fechaHoraMs(p) > Date.now() && p.estadoApi === 'programado')
          .map(p => String(p.id)));
        const resueltosRecientes = partidos
          .filter(p => p.estado !== 'programado' && p.id !== idDecisionPendiente && p.provider !== 'manual' && !idsFuturosVigentes.has(String(p.id)))
          .sort((a, b) => fechaHoraMs(b) - fechaHoraMs(a))
          .slice(0, TOPE_RESUELTOS);
        const idsConservados = new Set([...conservarManualOPendiente, ...resueltosRecientes].map(p => String(p.id)));
        const nuevosProgramados = partidosNuevosApi.filter(p => p.id !== idDecisionPendiente && !idsConservados.has(String(p.id)));
        partidos = [...conservarManualOPendiente, ...resueltosRecientes, ...nuevosProgramados];
        persist();
      },

      // ---- Exclusivo de la Operación real (Sprint 019, "Cambiar liga") --
      // Retira los partidos 'programado' que vinieron de TheSportsDB (nunca
      // toca los cargados manualmente ni los ya resueltos). Se usa al
      // cambiar de liga, para que el Centro de Operaciones no siga
      // mostrando el próximo partido de una liga que el operador ya
      // abandonó — mezclar así dos ligas es justo lo que este sprint
      // prohíbe. Quien llama a esto debe comprobar antes que no haya una
      // decisión pendiente sobre ese partido (ver events.js,
      // confirmarCambioLiga).
      retirarProgramadosApi() {
        partidos = partidos.filter(p => !(p.provider === 'TheSportsDB' && p.estado === 'programado'));
        persist();
      }
    };

    return api;
  }

  M11.crearCalendario = crearCalendario;
  M11.Calendario = crearCalendario('m11Calendario', { autoSemilla: false });
  M11.CalendarioDemo = crearCalendario('m11CalendarioDemo', { autoSemilla: true });

})(window.M11);
