/* Operación Sombra M11 — motor aislado, sin DOM ni dinero real. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.M11 = root.M11 || {};
  root.M11.ShadowEngine = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  // M11 Laboratorio: hasta once campeonatos ficticios independientes.
  const MAX_TOURNAMENTS = 11;
  const MAX_LEVEL = 11;
  const STRATEGIES = ['general', 'pares', 'impares'];

  const COUNTRY_ALIASES = Object.freeze({
    colombia: 'Colombia', argentina: 'Argentina', brasil: 'Brazil', brazil: 'Brazil',
    espana: 'Spain', spain: 'Spain', inglaterra: 'England', england: 'England',
    italia: 'Italy', italy: 'Italy', alemania: 'Germany', germany: 'Germany',
    francia: 'France', france: 'France', portugal: 'Portugal', mexico: 'Mexico',
    europa: 'Europe', europe: 'Europe', sudamerica: 'South America',
    'america del sur': 'South America', 'south america': 'South America',
    'estados unidos': 'USA', 'ee uu': 'USA', eeuu: 'USA', usa: 'USA'
  });

  const FEATURED_COMPETITIONS = Object.freeze([
    { id:'4480', name:'UEFA Champions League', country:'Europe' },
    { id:'4501', name:'Copa Libertadores', country:'South America' },
    { id:'4328', name:'English Premier League', country:'England' }
  ]);

  const COMPETITION_CALENDARS = Object.freeze([
    { key:'copa-colombia', names:['copa colombia','copa betplay'], season:'2026', start:'2026-05-01', end:'2026-12-31', startLabel:'Mayo de 2026', endLabel:'Diciembre de 2026', estimatedEnd:true },
    { key:'champions', leagueIds:['4480'], names:['uefa champions league','champions league'], season:'2026/27', start:'2026-07-07', end:'2027-06-05', startLabel:'7 de julio de 2026', endLabel:'5 de junio de 2027', phaseLabel:'Fase de liga: 8 de septiembre de 2026' },
    { key:'laliga', names:['spanish la liga','la liga espana','laliga','la liga'], season:'2026/27', start:'2026-08-15', end:'2027-05-30', startLabel:'15 de agosto de 2026', endLabel:'30 de mayo de 2027' },
    { key:'libertadores', leagueIds:['4501'], names:['copa libertadores','conmebol libertadores','libertadores'], season:'2026', start:'2026-02-18', end:'2026-11-28', startLabel:'18 de febrero de 2026', endLabel:'28 de noviembre de 2026' },
    { key:'premier', leagueIds:['4328'], names:['english premier league','premier league','liga premier'], season:'2026/27', start:'2026-08-21', end:'2027-05-30', startLabel:'21 de agosto de 2026', endLabel:'30 de mayo de 2027' },
    { key:'serie-a', names:['italian serie a','italia serie a','serie a'], season:'2026/27', start:'2026-08-22', end:'2027-05-30', startLabel:'22 de agosto de 2026', endLabel:'30 de mayo de 2027' },
    { key:'liga-dimayor', names:['liga betplay dimayor','liga dimayor','colombia primera a','liga betplay'], season:'2026-II', start:'2026-07-24', end:'2026-12-13', startLabel:'24 de julio de 2026', endLabel:'13 de diciembre de 2026' }
  ]);

  function normalizeCompetitionName(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  }

  function competitionCalendar(tournament, now) {
    const leagueId=String((tournament&&tournament.leagueId)||'');
    const name=normalizeCompetitionName(tournament&&tournament.name);
    const calendar=COMPETITION_CALENDARS.find(c=>(c.leagueIds||[]).includes(leagueId)||(c.names||[]).some(alias=>name.includes(alias)));
    if(!calendar)return null;
    const today=now instanceof Date?now:new Date(now||Date.now());
    const start=new Date(`${calendar.start}T00:00:00Z`), end=new Date(`${calendar.end}T23:59:59Z`);
    const status=today<start?'upcoming':today>end?'finished':'active';
    const daysRemaining=status==='active'?Math.max(0,Math.ceil((end-today)/86400000)):status==='upcoming'?Math.max(0,Math.ceil((start-today)/86400000)):0;
    return Object.assign({},calendar,{status,daysRemaining});
  }

  function countryForApi(value) {
    const original=String(value||'').trim();
    const key=original.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\./g,'').replace(/\s+/g,' ');
    return COUNTRY_ALIASES[key] || original;
  }

  function amountForLevel(base, level) {
    return base * Math.pow(2, level - 1);
  }

  function strategyBudget(base) {
    return base * (Math.pow(2, MAX_LEVEL) - 1);
  }

  function newStrategy(base) {
    return { level: 1, balance: strategyBudget(base), closed: false };
  }

  function createTournament(input) {
    const base = Number(input.base || 1000);
    const quota = Number(input.experimentalQuota || 3.6);
    if (!input.id || !input.name) throw new Error('El campeonato requiere id y nombre.');
    if (!(base > 0)) throw new Error('La base debe ser mayor que cero.');
    if (!(quota > 1)) throw new Error('La cuota experimental debe ser mayor que uno.');
    const studyMode = input.studyMode === 'retrospective' ? 'retrospective' : 'prospective';
    if (studyMode === 'retrospective' && !String(input.season || '').trim()) throw new Error('El laboratorio retrospectivo requiere indicar la temporada.');
    const initialCapital = strategyBudget(base) * STRATEGIES.length;
    return {
      id: String(input.id),
      name: String(input.name),
      leagueId: input.leagueId ? String(input.leagueId) : null,
      country: input.country || '',
      season: input.season || '',
      base,
      experimentalQuota: quota,
      targetPercent: Number(input.targetPercent || 40),
      studyMode,
      initialCapital,
      status: 'active',
      strategies: {
        general: newStrategy(base),
        pares: newStrategy(base),
        impares: newStrategy(base)
      },
      processedEventIds: [],
      history: [],
      createdAt: input.createdAt || new Date().toISOString()
    };
  }

  function createExperiment(input) {
    return {
      version: 1,
      mode: 'shadow',
      label: 'Simulación — no realizada',
      tournaments: (input && input.tournaments) || [],
      createdAt: new Date().toISOString()
    };
  }

  function addTournament(experiment, tournamentInput) {
    if (experiment.tournaments.length >= MAX_TOURNAMENTS) throw new Error('La Operación Ficticia admite máximo once campeonatos.');
    if (experiment.tournaments.some(t => t.id === String(tournamentInput.id))) throw new Error('El campeonato ya existe.');
    experiment.tournaments.push(createTournament(tournamentInput));
    return experiment;
  }

  function participants(number) {
    return ['general', number % 2 === 0 ? 'pares' : 'impares'];
  }

  function totalCapital(tournament) {
    return STRATEGIES.reduce((sum, name) => sum + tournament.strategies[name].balance, 0);
  }

  function capitalUsage(tournament) {
    const ordered=(tournament.history||[]).slice().sort((a,b)=>Number(a.chronologicalNumber)-Number(b.chronologicalNumber));
    const historyAmounts=ordered.map(record=>Object.values(record.details||{}).reduce((sum,d)=>sum+(d&&d.participated?Number(d.amount||0):0),0));
    const currentCommitted=Object.values((((tournament.tracking||{}).openPlan||{}).amounts)||{}).reduce((sum,d)=>sum+Number(d.amount||0),0);
    const patrimonioActual=totalCapital(tournament);
    let sequenceUsed=0,maximumSequenceRequired=0;
    ordered.forEach((record,index)=>{
      sequenceUsed+=historyAmounts[index];
      maximumSequenceRequired=Math.max(maximumSequenceRequired,sequenceUsed);
      if(record.result==='draw')sequenceUsed=0;
    });
    maximumSequenceRequired=Math.max(maximumSequenceRequired,sequenceUsed+currentCommitted);
    const assigned=Number(tournament.initialCapital||0),totalUsed=historyAmounts.reduce((sum,n)=>sum+n,0),netProfit=patrimonioActual-assigned;
    return {assigned,totalUsed,maximumUsed:Math.max(0,currentCommitted,...historyAmounts),maximumSequenceRequired,currentCommitted,patrimonioActual,withdrawableNow:Math.max(0,patrimonioActual-currentCommitted),netProfit,capitalUsedPercent:assigned?maximumSequenceRequired/assigned*100:null,returnOnMovementPercent:totalUsed?netProfit/totalUsed*100:null};
  }

  function portfolioCapitalUsage(experiment) {
    const tournaments=(experiment&&experiment.tournaments)||[];
    const usages=tournaments.map(capitalUsage);
    return {
      tournaments:tournaments.length,
      records:tournaments.reduce((sum,t)=>sum+(t.history||[]).length,0),
      assigned:usages.reduce((sum,u)=>sum+u.assigned,0),
      totalUsed:usages.reduce((sum,u)=>sum+u.totalUsed,0),
      maximumSingleMatch:Math.max(0,...usages.map(u=>u.maximumUsed)),
      maximumSequenceRequired:Math.max(0,...usages.map(u=>u.maximumSequenceRequired)),
      maximumPortfolioRequired:usages.reduce((sum,u)=>sum+u.maximumSequenceRequired,0),
      currentCommitted:usages.reduce((sum,u)=>sum+u.currentCommitted,0),
      patrimonioActual:usages.reduce((sum,u)=>sum+u.patrimonioActual,0),
      withdrawableNow:usages.reduce((sum,u)=>sum+u.withdrawableNow,0),
      netProfit:usages.reduce((sum,u)=>sum+u.netProfit,0)
    };
  }

  function processResult(tournament, event) {
    const eventId = String(event.externalId || event.id || '');
    if (!eventId) throw new Error('El partido requiere identificador externo.');
    if (tournament.processedEventIds.includes(eventId)) return { applied: false, reason: 'duplicate', tournament };
    if (tournament.status !== 'active') return { applied: false, reason: 'tournament_closed', tournament };
    const number = Number(event.chronologicalNumber);
    if (!Number.isInteger(number) || number < 1) throw new Error('El partido requiere número cronológico válido.');
    const result = event.result;
    if (!['draw', 'not_draw', 'cancelled', 'suspended'].includes(result)) throw new Error('Resultado sombra inválido.');

    const quota = Number(event.experimentalQuota || tournament.experimentalQuota);
    const participating = participants(number);
    const details = {};
    participating.forEach(name => {
      const strategy = tournament.strategies[name];
      if (strategy.closed) {
        details[name] = { participated: false, reason: 'strategy_closed' };
        return;
      }
      if (result === 'cancelled' || result === 'suspended') {
        details[name] = { participated: true, amount: 0, net: 0, levelBefore: strategy.level, levelAfter: strategy.level };
        return;
      }
      const amount = amountForLevel(tournament.base, strategy.level);
      const levelBefore = strategy.level;
      if (result === 'draw') {
        const grossReturn = amount * quota;
        const net = grossReturn - amount;
        strategy.balance += net;
        strategy.level = 1;
        details[name] = { participated: true, amount, quota, grossReturn, net, levelBefore, levelAfter: 1, sequenceClosed: false };
      } else {
        strategy.balance -= amount;
        const closes = levelBefore === MAX_LEVEL;
        strategy.level = closes ? MAX_LEVEL : levelBefore + 1;
        strategy.closed = closes;
        details[name] = { participated: true, amount, quota: null, grossReturn: 0, net: -amount, levelBefore, levelAfter: strategy.level, sequenceClosed: closes };
      }
    });

    tournament.processedEventIds.push(eventId);
    const capitalAfter = totalCapital(tournament);
    const profitabilityPercent = ((capitalAfter - tournament.initialCapital) / tournament.initialCapital) * 100;
    // La operación ficticia sigue observando toda la temporada. Alcanzar
    // una meta o agotar estrategias queda registrado, pero no cierra el
    // campeonato ni recarga una estrategia agotada.
    tournament.targetReached = profitabilityPercent >= tournament.targetPercent;
    tournament.allStrategiesClosed = STRATEGIES.every(name => tournament.strategies[name].closed);
    tournament.history.push({
      externalId: eventId,
      chronologicalNumber: number,
      homeTeam: event.homeTeam || '',
      awayTeam: event.awayTeam || '',
      result,
      quotaType: 'experimental',
      experimentalQuota: quota,
      label: 'Simulada — no realizada',
      resolutionSource: event.resolutionSource || 'automatic',
      sourceStatus: event.sourceStatus || '',
      sourceScore: event.sourceScore || '',
      plannedAt: event.plannedAt || null,
      eligibilityLockedAt: event.eligibilityLockedAt || null,
      kickoffUTC: event.kickoffUTC || null,
      plannedAmounts: event.plannedAmounts || null,
      details,
      capitalAfter,
      profitabilityPercent,
      processedAt: event.processedAt || new Date().toISOString()
    });
    return { applied: true, tournament, record: tournament.history[tournament.history.length - 1] };
  }

  function recordNoBet(tournament, event) {
    const eventId=String(event.externalId||'');
    if(!eventId)throw new Error('El partido requiere identificador externo.');
    if(tournament.processedEventIds.includes(eventId))return {applied:false,reason:'duplicate',tournament};
    tournament.processedEventIds.push(eventId);
    const capitalAfter=totalCapital(tournament), profitabilityPercent=((capitalAfter-tournament.initialCapital)/tournament.initialCapital)*100;
    tournament.history.push({externalId:eventId,chronologicalNumber:Number(event.chronologicalNumber),homeTeam:event.homeTeam||'',awayTeam:event.awayTeam||'',result:event.result,quotaType:'experimental',experimentalQuota:tournament.experimentalQuota,label:'No registrada antes del inicio',resolutionSource:event.resolutionSource||'unplanned_observation',sourceStatus:event.sourceStatus||'',sourceScore:event.sourceScore||'',plannedAt:null,kickoffUTC:event.kickoffUTC||null,plannedAmounts:null,details:{general:{participated:false,reason:'not_planned'},pares:{participated:false,reason:'not_planned'},impares:{participated:false,reason:'not_planned'}},capitalAfter,profitabilityPercent,processedAt:event.processedAt||new Date().toISOString()});
    return {applied:true,tournament,record:tournament.history[tournament.history.length-1]};
  }

  return {
    MAX_TOURNAMENTS,
    MAX_LEVEL,
    STRATEGIES,
    countryForApi,
    FEATURED_COMPETITIONS,
    COMPETITION_CALENDARS,
    competitionCalendar,
    amountForLevel,
    strategyBudget,
    createExperiment,
    createTournament,
    addTournament,
    processResult,
    recordNoBet,
    totalCapital,
    capitalUsage,
    portfolioCapitalUsage
  };
});
